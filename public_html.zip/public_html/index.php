<?php

// 纯净版 index.php (前台 v3)

?>

<!DOCTYPE html>

<html lang="zh-CN">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>学生邮箱自助开通</title>

    <link rel="stylesheet" href="assets/css/style.css">

    <script defer src="assets/js/app.js"></script>

</head>

<body>

    <div class="container">

        <header class="header">

            <h1>学生邮箱自助开通</h1>

        </header>



        <div id="step1" class="step-card active">

            <h2>🔐 第一步: 验证您的卡密</h2>

            <p>请输入您获取的卡密，以开通您的专属学生邮箱。</p>

            <form id="verifyKeyForm">

                <div class="input-group">

                    <label for="card_key_input">请输入卡密</label>

                    <input type="text" id="card_key_input" name="card_key" placeholder="例如: EA73DD-063E5C-FE6287" required>

                </div>

                <button type="submit" class="btn">验证卡密</button>

            </form>

        </div>



        <div id="step2" class="step-card">

            <h2>✨ 第二步: 设置您的邮箱前缀</h2>

            <p>您的卡密 <strong id="verifiedKeyDisplay"></strong> 验证通过！</p>

            <p>现在，请设置您心仪的邮箱前缀。</p>

            <form id="createAccountForm">

                <div class="input-group addon">

                    <input type="text" id="username_input" name="username" placeholder="邮箱前缀" required pattern="[a-z0-9._\-]{3,20}" title="3-20位, 仅限小写字母/数字/._-">

                    <span id="domainAddon" class="input-addon">@...</span>

                </div>

                <div id="usernameCheckResult" class="validation-message"></div>

                <button type="submit" class="btn" disabled>立即开通</button>

            </form>

        </div>



        <div id="step3" class="step-card">

            <h2>🎉 兑换成功！</h2>

            <p>您的专属学生邮箱已成功开通，请妥善保管以下信息：</p>

            <div id="successInfo" class="success-info">

                <div class="info-item"><span>📧 邮箱账号:</span> <strong id="infoEmail"></strong></div>

                <div class="info-item"><span>🔑 初始密码:</span> <strong id="infoPassword"></strong></div>

                <div class="info-item"><span>🌐 登录地址:</span> <a id="infoLoginUrl" href="#" target="_blank"></a></div>

                <div class="info-item"><span>🎁 优惠平台:</span> <a id="infoPromoUrl" href="#" target="_blank"></a></div>

                <div class="info-item"><span>⚙️ 邮箱配置:</span> <code id="infoServerConfig"></code></div>

            </div>

            <p class="warning">⚠️ 为了您的账户安全，请立即登录并修改您的初始密码！</p>

            <div class="actions">

                <button id="copyAllBtn" class="btn">📋 一键复制全部信息</button>

                <a id="loginNowBtn" href="#" class="btn btn-secondary" target="_blank">🚀 立即登录邮箱</a>

            </div>

        </div>



        <div id="messageArea" class="message-area"></div>



        <footer id="footer" class="footer" style="display: none;">
            <div class="footer-content">
                <h3 class="footer-title">📞 联系 & 🌐 推荐</h3>

                <div class="footer-section contact-info-grid">
                    <a href="#" class="footer-item contact-item"
                        id="contactItem1"
                        data-action="copy"
                        data-value="">
                        <span class="icon"></span>
                        <span id="contact1Label"></span>: <strong id="contact1Value"></strong>
                    </a>

                    <a href="#" class="footer-item contact-item"
                        id="contactItem2"
                        data-action="copy"
                        data-value="">
                        <span class="icon"></span>
                        <span id="contact2Label"></span>: <strong id="contact2Value"></strong>
                    </a>
                </div>

                <div class="footer-section promo-links">
                    <a href="#" target="_blank" id="footerLink1" class="footer-link"></a>
                    <a href="#" target="_blank" id="footerLink2" class="footer-link"></a>
                </div>

                <p class="copyright">Copyright © <?php echo date('Y'); ?> <?php echo htmlspecialchars($_SERVER['HTTP_HOST'] ?? 'YourDomain'); ?></p>
            </div>
        </footer>

        <script src="assets/js/app.js"></script>
</body>

</html>