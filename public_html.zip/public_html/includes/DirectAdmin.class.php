<?php
// 文件includes\DirectAdmin.class.php
declare(strict_types=1);

// 🎯 升级 v1.1：定义缓存文件路径
// 确保项目根目录下的 /cache/ 目录已创建且可写
define('DA_CACHE_PATH', __DIR__ . '/../cache/da_usage.json');

class DirectAdmin
{
    private string $host;
    private int $port;
    private string $username; 
    private string $password; 
    private string $targetDomain; 

    public function __construct(PDO $pdo)
    {
        $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'da_%' OR setting_key = 'target_domain'");
        $stmt->execute();
        $da_settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        $this->host = $da_settings['da_host'] ?? '';
        $this->port = (int)($da_settings['da_port'] ?? 2222);
        $this->username = $da_settings['da_username'] ?? ''; 
        $this->password = $da_settings['da_password'] ?? '';
        $this->targetDomain = $da_settings['target_domain'] ?? ''; 
    }
    
    public function getTargetDomain(): string
    {
        return $this->targetDomain;
    }

    private function sendRequest(string $command, array $params = []): ?array
    {
        if (empty($this->host) || empty($this->username) || empty($this->password)) {
            return ['error' => '1', 'details' => 'DirectAdmin API credentials not configured.'];
        }
        
        $final_params = array_merge(['json' => 'yes'], $params);
        
        if (!isset($final_params['user'])) {
            $final_params['user'] = $this->username; 
        }

        $queryString = http_build_query($final_params);
        $url = "https://{$this->host}:{$this->port}/{$command}?{$queryString}";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60); 
        curl_setopt($ch, CURLOPT_USERPWD, "{$this->username}:{$this->password}"); 
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        
        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
            curl_close($ch);
            return ['error' => '1', 'details' => 'cURL Error: ' . $error_msg];
        }
        curl_close($ch);
        
        if (strpos((string)$response, '<html>') !== false) {
             return ['error' => '1', 'details' => 'DA returned a non-JSON (HTML) error page.'];
        }
        
        return json_decode((string)$response, true);
    }
    
    private function executeApiCommand(string $command, array $params): array
    {
        $response = $this->sendRequest($command, $params);
        
        if (isset($response['error']) && $response['error'] === '1') {
             return ['success' => false, 'message' => $response['details'] ?? 'Internal Connection Error.'];
        }
        
        if (isset($response['error']) && $response['error'] != '0') {
            $error_message = $response['result'] ?? $response['details'] ?? ($response['text'] ?? 'Unknown API error.') ;
            return ['success' => false, 'message' => "DA API 错误: {$error_message}", 'raw_response' => $response];
        }
        
        return ['success' => true, 'data' => $response];
    }
    
    // --- 邮箱管理核心功能 ---
    public function emailExists(string $localPart, string $domain): bool
    {
        $result = $this->executeApiCommand('CMD_API_POP', ['domain' => $domain, 'action' => 'exists', 'user' => $localPart]);
        return $result['success'] && isset($result['data']['exists']) && $result['data']['exists'] === 'yes';
    }

    public function createEmail(string $localPart, string $domain, string $password, int $quota = 0, int $limit = 200): array
    {
        if ($this->emailExists($localPart, $domain)) {
            return ['success' => false, 'message' => 'Email account already exists.'];
        }
        $params = ['action' => 'create', 'domain' => $domain, 'user' => $localPart, 'passwd' => $password, 'passwd2' => $password, 'quota' => $quota, 'limit' => $limit];
        return $this->executeApiCommand('CMD_API_POP', $params);
    }
    
    public function changeEmailPassword(string $localPart, string $newPassword, string $domain = null): array
    {
        $domain = $domain ?? $this->targetDomain;
        if (empty($domain)) {
             return ['success' => false, 'message' => 'Target domain is not configured.'];
        }
        $params = [
            'action' => 'modify', 'domain' => $domain, 'user' => $localPart,
            'passwd' => $newPassword, 'passwd2' => $newPassword,
        ];
        return $this->executeApiCommand('CMD_API_POP', $params);
    }


    public function getEmailsList(string $domain): array
    {
        $listResult = $this->executeApiCommand('CMD_API_POP', ['action' => 'list', 'domain' => $domain]);
        
        if (!$listResult['success']) {
            return ['success' => false, 'data' => [], 'message' => $listResult['message'], 'raw' => $listResult['raw_response'] ?? null];
        }
        
        $usernames = [];
        $raw_data = $listResult['data'];
        
        if (is_array($raw_data) && !empty($raw_data)) {
            // DA API V2 返回 {'list': {'user1': '', 'user2': ''}}
            if (isset($raw_data['list'])) {
                $usernames = array_keys($raw_data['list']);
            } elseif (array_is_list($raw_data)) {
            // DA API V1 返回 ['user1', 'user2']
                $usernames = $raw_data;
            }
        }
        
        $emails = array_map(function($username) use ($domain) {
            return $username . '@' . $domain;
        }, $usernames);

        return ['success' => true, 'data' => $emails];
    }

    /**
     * 🎯 升级 v1.1：获取邮箱列表和使用情况 (带缓存)
     *
     * @param string $domain 目标域名
     * @return array
     */
    public function getEmailsAndUsage(string $domain): array
    {
        // 步骤 1: 检查缓存文件是否存在
        if (file_exists(DA_CACHE_PATH)) {
            try {
                $cached_data = file_get_contents(DA_CACHE_PATH);
                $decoded_data = json_decode($cached_data, true);
                
                // 确保 JSON 解码成功且是我们期望的格式
                if (json_last_error() === JSON_ERROR_NONE && isset($decoded_data['success']) && $decoded_data['success'] === true) {
                    // 缓存命中！立即返回数据，跳过所有 API 调用
                    return $decoded_data; 
                }
            } catch (Exception $e) {
                // 读取或解码失败，将继续执行 API 调用
            }
        }
        
        // --- 缓存未命中 (Cache Miss) ---
        // 步骤 2: 缓存不存在或无效，执行原始的 N+1 API 调用

        $listResult = $this->executeApiCommand('CMD_API_POP', ['action' => 'list', 'domain' => $domain]);
        
        if (!$listResult['success']) {
            return ['success' => false, 'data' => [], 'message' => $listResult['message'], 'raw' => $listResult['raw_response'] ?? null];
        }
        
        $usernames = [];
        $raw_data = $listResult['data'];
        
        if (is_array($raw_data) && !empty($raw_data)) {
            if (isset($raw_data['list'])) {
                $usernames = array_keys($raw_data['list']);
            } elseif (array_is_list($raw_data)) {
                $usernames = $raw_data;
            }
        }
        
        $resultData = [];

        foreach ($usernames as $username) {
            $usageResult = $this->executeApiCommand('CMD_API_POP', ['domain' => $domain, 'user' => $username, 'u' => 'yes']);
            
            if (!$usageResult['success']) {
                $resultData[] = [
                    'email' => $username . '@' . $domain,
                    'username' => $username,
                    'usage' => 0.0,
                    'quota' => 0.0,
                    'suspended' => false,
                    'message' => '❌ 无法获取容量信息'
                ];
                continue; 
            }
            
            $usageResponse = $usageResult['data'];
            
            $quotaStr = $usageResponse['quota'] ?? '0';
            $quota = ($quotaStr === 'unlimited') ? 0.0 : (float)$quotaStr;
            
            $resultData[] = [
                'email' => $username . '@' . $domain,
                'username' => $username,
                'usage' => (float)($usageResponse['usage'] ?? 0), 
                'quota' => $quota, 
                // 🎯 修正：'suspended' 状态现在也由 API 直接返回
                'suspended' => ($usageResponse['suspended'] ?? 'no') === 'yes'
            ];
        }
        
        $final_result = ['success' => true, 'data' => $resultData];
        
        // 步骤 3: 将新获取的数据写入缓存文件
        try {
            file_put_contents(DA_CACHE_PATH, json_encode($final_result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        } catch (Exception $e) {
            // 写入缓存失败，但这不应阻止向用户返回数据
            // (可以在此处添加日志记录)
        }
        
        return $final_result;
    }
    
    /**
     * 🎯 升级 v1.1：清除邮箱使用情况缓存
     *
     * @return bool
     */
    public function clearUsageCache(): bool
    {
        if (file_exists(DA_CACHE_PATH)) {
            return unlink(DA_CACHE_PATH);
        }
        return true;
    }


    private function performUserAction(string $action, array $users, string $domain): array
    {
        if (empty($users)) {
            return ['success' => false, 'message' => 'No users selected for the action.'];
        }
        
        $params = ['action' => $action, 'domain' => $domain];
        
        // 🎯 修正：DA API 要求 select[N] 格式
        $i = 0;
        foreach ($users as $user) {
            $params['select' . $i] = $user;
            $i++;
        }
        
        return $this->executeApiCommand('CMD_API_POP', $params);
    }
    
  
    
    public function deleteEmails(array $users, string $domain): array
    {
        return $this->performUserAction('delete', $users, $domain);
    }
}