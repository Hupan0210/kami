<?php
// =================================================================
// 学生邮箱自助开通 - 交互式安装向导 
// v1.2 更新：
// - 在数据库结构中添加了 dictionary 表
// =================================================================
declare(strict_types=1);
session_start();

$db_dir = __DIR__ . '/database';
$db_file = $db_dir . '/main.db';
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create_db' && $step === 1) {
        if (!is_dir($db_dir)) mkdir($db_dir, 0755);
        try {
            $pdo = new PDO('sqlite:' . $db_file);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // -----------------------------------------------------------
            // 🛡️ 数据库表结构定义
            // -----------------------------------------------------------
            $sql = "
                CREATE TABLE IF NOT EXISTS keys (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    card_key TEXT NOT NULL UNIQUE,
                    status TEXT NOT NULL DEFAULT 'pristine',
                    used_by_email TEXT,
                    used_at TEXT,
                    used_ip TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    distributed_at TEXT NULL
                );
                CREATE TABLE IF NOT EXISTS settings (setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, log_level TEXT NOT NULL, message TEXT NOT NULL, context TEXT, timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
                
                
                CREATE TABLE IF NOT EXISTS mail_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    recipient_email TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    body TEXT NOT NULL,
                    sender TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending', -- pending, sending, sent, failed
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    sent_at TEXT NULL,
                    error_message TEXT NULL
                );

                -- 🎯 升级 v1.2：添加 dictionary 表 --
                CREATE TABLE IF NOT EXISTS dictionary (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    term TEXT NOT NULL UNIQUE,          -- 术语或字符，确保唯一性
                    explanation TEXT NOT NULL,          -- 中文解释
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP -- 添加时间
                );
                CREATE INDEX IF NOT EXISTS idx_dictionary_term ON dictionary (term);
                -- 字典表定义结束 --
            ";
            // -----------------------------------------------------------

            $pdo->exec($sql);
            header('Location: setup.php?step=2');
            exit;
        } catch (Exception $e) {
            $_SESSION['error'] = '数据库创建失败: ' . $e->getMessage();
        }
    }

    if ($_POST['action'] === 'save_config' && $step === 2) {
        try {
            $pdo = new PDO('sqlite:' . $db_file);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $pdo->prepare("INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES (?, ?)");
            $pdo->beginTransaction();

            if (empty(trim($_POST['admin_user'])) || empty($_POST['admin_pass'])) throw new Exception('管理员用户名和密码不能为空。');
            $stmt->execute(['admin_username', trim($_POST['admin_user'])]);
            $stmt->execute(['admin_password_hash', password_hash($_POST['admin_pass'], PASSWORD_DEFAULT)]);

            if (empty(trim($_POST['da_host'])) || empty(trim($_POST['da_user'])) || empty($_POST['da_pass'])) throw new Exception('DirectAdmin 连接信息不能为空。');
            $stmt->execute(['da_host', trim($_POST['da_host'])]);
            $stmt->execute(['da_port', trim($_POST['da_port'])]);
            $stmt->execute(['da_username', trim($_POST['da_user'])]);
            $stmt->execute(['da_password', trim($_POST['da_pass'])]);

            $target_domain = trim($_POST['target_domain']);
            if (empty($target_domain)) throw new Exception('目标邮箱域名不能为空。');
            $stmt->execute(['target_domain', $target_domain]);

            // --- 写入所有可配置的默认站点信息 ---
            $default_settings = [
                'default_email_password' => 'Abc123',
                'login_url' => 'https://mail.' . $target_domain,
                'promo_url' => '',
                'server_config' => '服务器 mail.' . $target_domain . ' | SMTP 465 | IMAP 993',
                'show_footer_info' => '1',
                'contact_1_label' => '微信',
                'contact_1_value' => 'QQ19155653456',
                'contact_2_label' => '邮箱',
                'contact_2_value' => 'hupanxg@gmail.com',
                'footer_link_1_text' => 'BTC',
                'footer_link_1_url' => 'https://090110.xyz/',
                'footer_link_2_text' => '趣网',
                'footer_link_2_url' => 'https://112583.xyz/',
                // 🎯 升级 v1.2：添加邮件传输的默认设置
                'mail_transport' => 'php_mail' // 默认为 PHP mail()
            ];
            foreach ($default_settings as $key => $value) {
                $stmt->execute([$key, $value]);
            }

            $pdo->commit();
            header('Location: setup.php?step=3');
            exit;
        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
            $_SESSION['error'] = '配置保存失败: ' . $e->getMessage();
        }
    }
    header('Location: ' . $_SERVER['PHP_SELF'] . '?step=' . $step);
    exit;
}
function check_environment()
{
    return [['name' => 'PHP 版本 >= 7.4', 'status' => version_compare(PHP_VERSION, '7.4.0', '>='), 'msg' => '当前: ' . PHP_VERSION], ['name' => 'PDO SQLite 扩展', 'status' => extension_loaded('pdo_sqlite'), 'msg' => '检查 pdo_sqlite'], ['name' => '目录可写', 'status' => is_writable(__DIR__), 'msg' => '检查 /public_html 权限']];
}
$error = $_SESSION['error'] ?? null;
unset($_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>安装向导</title>
    <style>
        :root {
            --primary-color: #007bff;
            --success-color: #28a745;
            --error-color: #dc3545;
            --background-color: #f4f7f6;
            --card-background: #ffffff;
            --text-color: #333;
            --light-text-color: #777;
            --border-color: #e0e0e0;
            --font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif
        }

        body {
            font-family: var(--font-family);
            background-color: var(--background-color);
            color: var(--text-color);
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh
        }

        .container {
            width: 100%;
            max-width: 600px
        }

        .card {
            background-color: var(--card-background);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, .08);
            margin-top: 2rem
        }

        .card h2 {
            margin-top: 0
        }

        .btn {
            display: inline-block;
            background-color: var(--primary-color);
            color: #fff;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            text-decoration: none;
            text-align: center;
            cursor: pointer
        }

        .btn:disabled {
            background-color: #a0c7ff;
            cursor: not-allowed
        }

        .form-group {
            margin-bottom: 1.5rem
        }

        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: .5rem
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 1rem;
            box-sizing: border-box
        }

        .form-group small {
            color: var(--light-text-color)
        }

        .alert {
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem
        }

        .alert.error {
            background-color: #f8d7da;
            color: #721c24
        }

        .check-list li {
            list-style: none;
            padding: .5rem 0;
            display: flex;
            align-items: center
        }

        .check-list span {
            margin-left: .5rem
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>学生邮箱自助开通 - 安装向导</h1>
        <?php if ($error): ?><div class="alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
        <?php if ($step === 1): ?><div class="card">
                <h2>步骤 1: 环境检查 & 数据库</h2>
                <ul class="check-list">
                    <?php $all_ok = true;
                    $checks = check_environment();
                    foreach ($checks as $check): $all_ok = $all_ok && $check['status']; ?>
                        <li><?php echo $check['status'] ? '✅' : '❌'; ?><span><?php echo $check['name']; ?> <small>(<?php echo $check['msg']; ?>)</small></span></li>
                    <?php endforeach; ?>
                </ul>
                <hr>
                <?php if (file_exists($db_file)): ?><p style="color:var(--warning-color)">⚠️ 检测到已存在的数据库文件。继续将更新表结构但不会删除现有数据。</p><?php endif; ?>
                <form method="POST"><input type="hidden" name="action" value="create_db"><button type="submit" class="btn" <?php echo !$all_ok ? 'disabled' : ''; ?>><?php echo $all_ok ? '创建/更新数据库并继续' : '环境检查未通过'; ?></button></form>
            </div>
        <?php elseif ($step === 2): ?><div class="card">
                <h2>步骤 2: 核心配置</h2>
                <p>请输入系统的核心参数。这些信息将被安全地存储在数据库中。</p>
                <form method="POST"><input type="hidden" name="action" value="save_config">
                    <h4>后台管理员账户</h4>
                    <div class="form-group"><label for="admin_user">管理员用户名</label><input type="text" id="admin_user" name="admin_user" value="admin" required></div>
                    <div class="form-group"><label for="admin_pass">管理员密码</label><input type="password" id="admin_pass" name="admin_pass" required></div>
                    <h4>DirectAdmin API 配置</h4>
                    <div class="form-group"><label for="da_host">DA 服务器地址</label><input type="text" id="da_host" name="da_host" value="uk10.neodns.info" required><small>无需填写 https:// 或端口号</small></div>
                    <div class="form-group"><label for="da_port">DA 端口</label><input type="number" id="da_port" name="da_port" value="2222" required></div>
                    <div class="form-group"><label for="da_user">DA 用户名</label><input type="text" id="da_user" name="da_user" value="eebu" required></div>
                    <div class="form-group"><label for="da_pass">DA 登录密钥 (Login Key)</label><input type="text" id="da_pass" name="da_pass" required><small>强烈建议使用专用的、仅有 `CMD_API_POP` 权限的登录密钥</small></div>
                    <h4>邮箱域名配置</h4>
                    <div class="form-group"><label for="target_domain">目标邮箱域名</label><input type="text" id="target_domain" name="target_domain" value="eebu.edu.pl" required><small>例如: eebu.edu.pl</small></div><button type="submit" class="btn">保存配置并完成安装</button>
                </form>
            </div>
        <?php elseif ($step === 3): ?><div class="card">
                <h2>🎉 安装完成！</h2>
                <p>恭喜！您的学生邮箱自助开通平台已成功安装并配置完毕。</p>
                <a href="admin/reset_admin_pass.php" class="btn" style="background-color:#ffc107; color:#333; margin-right: 1rem;">请先点击此按钮 (安全加固)</a>
                <a href="index.php" class="btn">访问前台页面</a>
                <a href="admin/" class="btn" style="background-color:var(--success-color)">访问后台登录</a>
            </div><?php endif; ?>
    </div>
</body>

</html>