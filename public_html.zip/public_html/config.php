<?php

// config.php

declare(strict_types=1);

// 它指向由 setup.php 创建的数据库文件。
define('DB_PATH', __DIR__ . '/database/main.db');

// 🎯 升级 v1.2：Cron Job 安全密钥
// -----------------------------------------------------------------
// 请将 'YOUR_STRONG_SECRET_KEY_HERE' 替换为一个长且随机的字符串！
// 这是为了保护您的 cron/process_queue.php 脚本不被公开访问。
// 您的 Cron Job URL 必须是： https://.../cron/process_queue.php?key=YOUR_STRONG_SECRET_KEY_HERE
// -----------------------------------------------------------------
define('CRON_SECRET_KEY', 'Jh7#k&!pQ9z$R@LwN*sXy2^fG8bT5mE');


// 开发期间开启错误报告
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);


// 设置默认时区，确保时间记录准确
date_default_timezone_set('Asia/Shanghai');