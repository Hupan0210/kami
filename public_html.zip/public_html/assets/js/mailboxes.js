// mailboxes.js (assets\js\mailboxes.js)
// v1.1 更新：
// - 实现了缓存刷新机制
// - 移除了“封禁”功能
// - 新增了“模拟登录”功能
document.addEventListener('DOMContentLoaded', function () {
    const DA_API_URL = 'manage_mailbox.php';
    let currentPage = 1;
    let currentSearch = '';

    // 🎯 升级 v1.1：用于存储 Webmail 登录地址
    let currentLoginUrl = '';

    let isInitialLoadComplete = false;

    // --- DOM 元素缓存 ---
    const $list = document.getElementById('mailbox-list');
    const $searchButton = document.getElementById('search-button');
    const $searchInput = document.getElementById('search-input');
    const $refreshButton = document.getElementById('refresh-button');
    const $paginationControls = document.getElementById('pagination-controls');
    const $messageContainer = document.getElementById('message-container');

    // 模态框元素
    const $modal = document.getElementById('password-modal');
    const $modalEmail = document.getElementById('modal-email');
    const $newPasswordInput = document.getElementById('new-password-input');
    const $modalConfirm = document.getElementById('modal-confirm');
    const $modalCancel = document.getElementById('modal-cancel');
    let currentUsernameForPassword = null;

    // --------------------------------------------------
    // 辅助函数 
    // --------------------------------------------------

    function displayMessage(message, type = 'success') {
        if (type === 'error') {
            console.error('Frontend Message:', message);
        }
        const isSuccess = type === 'success';
        // 🎯 修正：简化了消息提示样式，使用 admin_style.css 的内置类
        const alertClass = isSuccess ? 'badge-success' : 'alert-danger';
        const style = isSuccess ? 'color: white;' : ''; // 错误样式由 alert-danger 定义

        $messageContainer.innerHTML = `<div class"alert ${alertClass}" 
            style="${style} padding: 1rem; border-radius: 6px; margin-bottom: 1rem;">
            ${message}
        </div>`;
        setTimeout(() => { $messageContainer.innerHTML = ''; }, 5000);
    }

    // --------------------------------------------------
    // 主要数据获取和渲染
    // --------------------------------------------------

    /**
     * 从服务器获取邮箱列表并渲染 (此函数现在使用缓存)。
     * @param {number} page - 当前页码
     * @param {string} search - 搜索关键词
     * @param {boolean} forceLoad - 是否强制显示加载提示
     */
    async function fetchMailboxes(page = 1, search = '', forceLoad = true) {
        if (forceLoad || !isInitialLoadComplete) {
            $list.innerHTML = '<tr><td colspan="3" style="text-align: center;">加载中 (正在读取缓存或 API)...</td></tr>';
        }

        currentPage = page;
        currentSearch = search;

        // 🎯 v1.1：此 GET 请求现在将命中缓存（如果存在）
        const url = `${DA_API_URL}?action=list&page=${page}&limit=20&search=${encodeURIComponent(search)}`;

        try {
            const response = await fetch(url);

            if (!response.ok) {
                throw new Error(`HTTP Error: ${response.status}`);
            }

            const result = await response.json();

            if (!result.success) {
                $list.innerHTML = `<tr><td colspan="3" style="text-align: center; color: var(--error-color);">
                                    ❌ API 错误: ${result.message}
                                  </td></tr>`;
                $paginationControls.innerHTML = '';
                displayMessage(`API 调用失败: ${result.message}`, 'error');
                return;
            }

            // 🎯 升级 v1.1：存储登录 URL
            currentLoginUrl = result.login_url || '';

            renderList(result.data);
            renderPagination(result.pagination);

            isInitialLoadComplete = true;

        } catch (error) {
            console.error('Fetch error:', error);
            if (!isInitialLoadComplete) {
                $list.innerHTML = `<tr><td colspan="3" style="text-align: center; color: var(--error-color);">
                                    ❌ 网络错误或服务器异常。
                                  </td></tr>`;
                $paginationControls.innerHTML = '';
            }
        }
    }

    /**
     * 渲染邮箱账户列表 
     */
    function renderList(data) {
        if (!Array.isArray(data) || data.length === 0) {
            $list.innerHTML = '<tr><td colspan="3" style="text-align: center;">未找到匹配的邮箱账户。</td></tr>';
            return;
        }

        $list.innerHTML = data.map(item => {
            // 🎯 升级 v1.1：现在 suspended 状态也来自缓存
            const statusBadge = item.suspended
                ? '<span class="badge badge-warning">🚫 已封禁</span>'
                : '<span class="badge badge-success">✅ 正常</span>';

            // 🎯 升级 v1.1：移除了“封禁”按钮，新增了“登录”按钮
            const actionButtonContainer = `
                <div style="display: flex; gap: 5px; flex-wrap: wrap;">
                    <button class="action-btn btn-login" 
                            data-email="${item.email}">
                        登录
                    </button>
                    <button class="action-btn btn-change-pass" data-user="${item.username}">
                        改密
                    </button>
                    <button class="action-btn btn-delete" data-user="${item.username}">
                        删除
                    </button>
                </div>
            `;

            const usageInfo = item.quota > 0 ? `${(item.usage / 1024 / 1024).toFixed(2)} MB / ${item.quota} MB` : '无限制';

            return `
                <tr>
                    <td>
                        <strong>${item.email}</strong>
                        <div style="font-size: 0.85rem; color: var(--secondary-text-color);">
                            容量: ${usageInfo}
                        </div>
                    </td>
                    <td>${statusBadge}</td>
                    <td style="white-space: nowrap;"> 
                        ${actionButtonContainer}
                    </td>
                </tr>
            `;
        }).join('');
    }

    /**
     * 渲染分页控件 
     */
    function renderPagination(pagination) {
        $paginationControls.innerHTML = '';
        const { total_pages, current_page } = pagination;

        if (total_pages <= 1) return;

        const createPageLink = (page, text, isCurrent = false, isDisabled = false) => {
            const link = document.createElement(isDisabled ? 'span' : 'a');
            link.textContent = text;
            if (isCurrent) {
                link.className = 'current';
            } else if (isDisabled) {
                link.className = 'disabled';
            } else {
                link.href = '#';
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    // 🎯 分页跳转时强制加载（读取缓存）
                    fetchMailboxes(page, currentSearch, true);
                });
            }
            return link;
        };

        const prevPage = current_page - 1;
        $paginationControls.appendChild(createPageLink(prevPage, '« 上一页', false, prevPage < 1));

        const statusSpan = document.createElement('span');
        statusSpan.className = 'current';
        statusSpan.textContent = `第 ${current_page} / ${total_pages} 页`;
        $paginationControls.appendChild(statusSpan);

        const nextPage = current_page + 1;
        $paginationControls.appendChild(createPageLink(nextPage, '下一页 »', false, nextPage > total_pages));
    }

    /**
     * 执行远程 API 操作（删除/改密）。
     */
    async function handleAction(username, action, newPassword = null) {
        let confirmMessage = '';
        let apiData = new URLSearchParams();
        apiData.append('action', action);
        apiData.append('username', username);

        if (action === 'delete') {
            if (!confirm(`⚠️ 确认删除邮箱 ${username}@... 吗？此操作不可逆！`)) return;
            confirmMessage = '邮箱已删除';
        }
        // 🎯 升级 v1.1：移除了 suspend/unsuspend 逻辑
        else if (action === 'change_password') {
            apiData.append('new_password', newPassword);
            confirmMessage = '密码已重置';
        } else {
            return; // 未知操作
        }

        try {
            const response = await fetch(DA_API_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: apiData
            });
            const result = await response.json();

            if (result.success) {
                displayMessage(`✅ ${username}@... ${confirmMessage}。`, 'success');

                // 🎯 升级 v1.1：操作成功后，调用 fetchMailboxes()。
                // 后端已清除缓存，此调用将触发缓存重建。
                fetchMailboxes(currentPage, currentSearch, true);
            } else {
                displayMessage(`❌ 操作失败: ${result.message}`, 'error');
            }

        } catch (error) {
            console.error('Action error:', error);
            displayMessage('网络或服务器错误，请重试。', 'error');
        }
    }

    // --------------------------------------------------
    // 事件绑定
    // --------------------------------------------------

    // 搜索按钮
    $searchButton.addEventListener('click', () => { fetchMailboxes(1, $searchInput.value, true); });
    $searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            fetchMailboxes(1, $searchInput.value, true);
        }
    });

    // 🎯 升级 v1.1：“刷新列表”按钮现在强制重建缓存
    $refreshButton.addEventListener('click', async () => {
        displayMessage(`🔄 正在强制刷新缓存并从 DA 获取最新数据...`, 'loading');
        $refreshButton.disabled = true;

        try {
            const apiData = new URLSearchParams();
            apiData.append('action', 'refresh_cache');
            apiData.append('search', $searchInput.value);
            apiData.append('page', 1); // 刷新总是返回第一页

            const response = await fetch(DA_API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: apiData
            });

            const result = await response.json();

            if (result.success) {
                // 使用返回的新数据重新渲染
                currentLoginUrl = result.login_url || '';
                renderList(result.data);
                renderPagination(result.pagination);
                displayMessage('✅ 缓存已重建，列表已刷新！', 'success');
            } else {
                displayMessage(`❌ 刷新失败: ${result.message}`, 'error');
            }
        } catch (error) {
            displayMessage(`❌ 刷新时网络错误: ${error.message}`, 'error');
        } finally {
            $refreshButton.disabled = false;
        }
    });

    // 列表操作事件代理 
    $list.addEventListener('click', (e) => {
        const target = e.target.closest('.action-btn');
        if (!target) return;

        const username = target.dataset.user;

        // 🎯 升级 v1.1：移除了 suspend/unsuspend 逻辑

        if (target.classList.contains('btn-delete')) {
            if (username) handleAction(username, 'delete');
        } else if (target.classList.contains('btn-change-pass')) {
            if (username) {
                currentUsernameForPassword = username;
                $modalEmail.textContent = username + '@...';
                $newPasswordInput.value = '';
                $modal.style.display = 'block';
            }
        }
        // 🎯 升级 v1.1：新增“登录”按钮逻辑
        else if (target.classList.contains('btn-login')) {
            const email = target.dataset.email;
            if (!email) return;

            if (!currentLoginUrl || currentLoginUrl === '#') {
                alert('错误：系统未配置 Webmail 登录地址 (login_url)，无法模拟登录。');
                return;
            }

            // 假设 login_url 指向 RoundCube，构建模拟登录 URL
            const impersonateUrl = currentLoginUrl + '?_task=login&_action=impersonate&_user=' + encodeURIComponent(email);
            window.open(impersonateUrl, '_blank');
        }
    });

    // 模态框事件 
    $modalCancel.addEventListener('click', () => { $modal.style.display = 'none'; });
    $modalConfirm.addEventListener('click', () => {
        const newPassword = $newPasswordInput.value.trim();
        if (newPassword.length < 6) {
            alert('密码长度至少需要6位。');
            return;
        }
        if (currentUsernameForPassword) {
            $modal.style.display = 'none';
            handleAction(currentUsernameForPassword, 'change_password', newPassword);
        }
    });

    // --- 应用启动：自动加载数据 ---
    fetchMailboxes(1, '', true);
});