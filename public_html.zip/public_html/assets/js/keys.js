// 纯净版 keys.js (v1.0 - 从 keys.php 中剥离的逻辑)
document.addEventListener('DOMContentLoaded', function() {
    
    // --- 辅助函数：API 请求 ---
    async function updateKeyStatus(keyId, action) {
        try {
            const response = await fetch('../api/update_key_status.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key_id: keyId, action: action }),
            });
            return await response.json();
        } catch (error) {
            return { success: false, message: '网络请求失败。' };
        }
    }

    // --- 事件绑定：一键复制 (Status: pristine -> distributed) ---
    document.querySelectorAll('.copy-btn').forEach(button => {
        button.addEventListener('click', async function() {
            const keyId = this.dataset.keyId;
            const keyValue = this.dataset.keyValue;
            const originalText = this.textContent;
            
            // 获取当前页面的基础 URL，用于构建完整的使用说明链接
            const openUrl = window.location.protocol + '//' + window.location.host;

            const textToCopy = `您好！您的卡密如下：\n【卡密】: ${keyValue}\n【使用方法】:\n1. 请访问自助开通网址：${openUrl}/index.php\n2. 输入您的卡密并验证。\n3. 验证通过后，设置您喜欢的邮箱前缀即可。\n祝您使用愉快！`;
            
            try {
                // 1. 复制到剪贴板
                await navigator.clipboard.writeText(textToCopy);
                this.textContent = '✅ 已复制!';
                this.disabled = true;

                // 2. 调用 API 更新状态
                const result = await updateKeyStatus(keyId, 'distribute');
                
                if (result.success) {
                    // 3. 成功后，淡出该行并刷新页面以更新计数和视图
                    const row = document.getElementById(`key-row-${keyId}`);
                    if (row) {
                        row.style.opacity = '0';
                        setTimeout(() => window.location.reload(), 500);
                    } else {
                         // 如果找不到行，直接刷新
                         setTimeout(() => window.location.reload(), 500);
                    }
                } else {
                    alert('复制成功，但更新状态失败: ' + result.message);
                    this.textContent = originalText;
                    this.disabled = false;
                }
            } catch (err) {
                alert('复制到剪贴板失败，您的浏览器可能不支持此功能。');
                this.textContent = originalText;
                this.disabled = false;
            }
        });
    });

    // --- 事件绑定：收回 (Status: distributed -> pristine) ---
    document.querySelectorAll('.reclaim-btn').forEach(button => {
        button.addEventListener('click', async function() {
            if (!confirm('您确定要将此卡密收回至“未使用”状态吗？')) return;
            
            const keyId = this.dataset.keyId;
            this.textContent = '处理中...';
            this.disabled = true;

            const result = await updateKeyStatus(keyId, 'reclaim');
            
            if (result.success) {
                // 成功后，淡出该行并刷新页面以更新计数和视图
                const row = document.getElementById(`key-row-${keyId}`);
                if (row) {
                    row.style.opacity = '0';
                    setTimeout(() => window.location.reload(), 500);
                } else {
                     setTimeout(() => window.location.reload(), 500);
                }
            } else {
                alert('收回失败: ' + result.message);
                this.textContent = '🔄 收回';
                this.disabled = false;
            }
        });
    });
});