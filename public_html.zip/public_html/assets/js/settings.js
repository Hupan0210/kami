//  settings.js (assets\js\settings.js)
//  v1.2 更新：
//  - 将 'transportSettingsForm' 和 'smtpSettingsForm' 加入安全提交（密码验证）范围
document.addEventListener('DOMContentLoaded', function () {

    // --- DOM 元素缓存 ---
    const systemSettingsForm = document.getElementById('systemSettingsForm');
    const passwordSettingsForm = document.getElementById('passwordSettingsForm');

    // 🎯 升级 v1.2.1：缓存新增的邮件设置表单
    const transportSettingsForm = document.getElementById('transportSettingsForm');
    const smtpSettingsForm = document.getElementById('smtpSettingsForm');

    const testBtn = document.getElementById('testDaConnectionBtn');

    /**
     * 弹出密码提示框，并通过隐藏域传递密码后提交表单。
     * @param {HTMLFormElement} form - 需要提交的表单
     */
    function requirePasswordAndSubmit(form) {
        const password = prompt('为安全起见，请输入您当前的管理员密码以确认操作:', '');
        if (password === null) return; // 用户点击了取消
        if (password === '') {
            alert('密码不能为空！');
            return;
        }
        // 创建隐藏的输入域，用于传递当前密码进行后端验证
        const hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = 'current_admin_password';
        hiddenInput.value = password;
        form.appendChild(hiddenInput);
        form.submit();
    }

    // --- 事件绑定：核心系统和密码修改需要二次验证 ---
    if (systemSettingsForm) {
        systemSettingsForm.addEventListener('submit', function (e) {
            e.preventDefault();
            requirePasswordAndSubmit(this);
        });
    }

    if (passwordSettingsForm) {
        passwordSettingsForm.addEventListener('submit', function (e) {
            e.preventDefault();
            requirePasswordAndSubmit(this);
        });
    }

    // 🎯 升级 v1.2.1：为新表单绑定安全提交
    if (transportSettingsForm) {
        transportSettingsForm.addEventListener('submit', function (e) {
            e.preventDefault();
            requirePasswordAndSubmit(this);
        });
    }

    if (smtpSettingsForm) {
        smtpSettingsForm.addEventListener('submit', function (e) {
            e.preventDefault();
            requirePasswordAndSubmit(this);
        });
    }


    // --- 事件绑定：测试 DA 连接 ---
    if (testBtn) {
        testBtn.addEventListener('click', async function () {
            const originalText = this.textContent;
            this.textContent = '测试中...';
            this.disabled = true;

            // 收集表单数据
            const data = {
                host: document.getElementById('da_host').value,
                port: document.getElementById('da_port').value,
                username: document.getElementById('da_username').value,
                password: document.getElementById('da_password').value
            };

            // 缓存原始样式
            const originalBg = this.style.backgroundColor;

            try {
                // 🎯 注意：此 API 调用应在 "任务组 5: CSRF" 中更新以发送 Token
                const response = await fetch('../api/test_da_connection.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                const result = await response.json();

                if (result.success) {
                    this.textContent = '✅ 连接成功!';
                    this.style.backgroundColor = 'var(--success-color)';
                } else {
                    this.textContent = '❌ 连接失败';
                    this.style.backgroundColor = 'var(--error-color)';
                    alert('连接失败详情: ' + result.message);
                }
            } catch (error) {
                this.textContent = '❌ 请求错误';
                this.style.backgroundColor = 'var(--error-color)';
                alert('前端请求错误: ' + error);
            }


            setTimeout(() => {
                this.textContent = originalText;
                this.disabled = false;
                this.style.backgroundColor = originalBg;
            }, 4000);
        });
    }
});