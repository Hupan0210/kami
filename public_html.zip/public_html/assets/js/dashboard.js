// 纯净版 dashboard.js (v1.0 - 从 dashboard.php 剥离的统计逻辑)
document.addEventListener('DOMContentLoaded', function() {
    const statElements = {
        redeemed_today: document.getElementById('stat-redeemed-today'),
        pristine: document.getElementById('stat-pristine'),
        distributed: document.getElementById('stat-distributed'),
        redeemed: document.getElementById('stat-redeemed')
    };
    const systemElements = {
        target_domain: document.getElementById('system-target-domain')
    };

    /**
     * 更新仪表盘UI并触发高亮动画
     * @param {object} data - 从 API 获取的统计数据
     */
    function updateDashboardUI(data) {
        // 更新统计数据
        for (const key in statElements) {
            if (statElements.hasOwnProperty(key) && data.stats[key] !== undefined) {
                // 只有数据发生变化时才触发高亮
                if (statElements[key].textContent != data.stats[key]) {
                    statElements[key].textContent = data.stats[key];
                    statElements[key].parentElement.classList.add('highlight-update');
                }
            }
        }
        // 更新系统信息
        if (systemElements.target_domain.textContent != data.system.target_domain) {
            systemElements.target_domain.textContent = data.system.target_domain;
        }

        // 动画结束后移除高亮类
        setTimeout(() => {
            document.querySelectorAll('.highlight-update').forEach(el => el.classList.remove('highlight-update'));
        }, 1500);
    }

    /**
     * 异步获取最新的统计数据
     */
    async function fetchStats() {
        try {
            // API 路径与 dashboard.php 处于同一目录
            const response = await fetch('dashboard.php?json=true'); 
            if (!response.ok) return;
            const data = await response.json();
            if (data.success) {
                updateDashboardUI(data);
            }
        } catch (error) {
            console.error("无法获取最新统计数据:", error);
        }
    }

    fetchStats(); 
    // 每 5 秒自动刷新
    setInterval(fetchStats, 5000);
});