// 纯净版 app.js (v5.0 - 最终稳定版：页脚模块化与复制逻辑)
document.addEventListener('DOMContentLoaded', () => {

    // --- 状态管理 ---
    const state = {
        cardKey: null,
        targetDomain: '...',
        usernameDebounceTimer: null,
    };

    // --- DOM 元素获取 ---
    const steps = {
        step1: document.getElementById('step1'),
        step2: document.getElementById('step2'),
        step3: document.getElementById('step3'),
    };
    const forms = {
        verifyKey: document.getElementById('verifyKeyForm'),
        createAccount: document.getElementById('createAccountForm'),
    };
    const inputs = {
        cardKey: document.getElementById('card_key_input'),
        username: document.getElementById('username_input'),
    };
    const buttons = {
        createAccount: forms.createAccount.querySelector('button'),
    };
    const displays = {
        message: document.getElementById('messageArea'),
        verifiedKey: document.getElementById('verifiedKeyDisplay'),
        usernameCheck: document.getElementById('usernameCheckResult'),
        domainAddon: document.getElementById('domainAddon'),
        footer: document.getElementById('footer'),
    };
    const successInfoElements = {
        email: document.getElementById('infoEmail'),
        password: document.getElementById('infoPassword'),
        loginUrl: document.getElementById('infoLoginUrl'),
        promoUrl: document.getElementById('infoPromoUrl'),
        serverConfig: document.getElementById('infoServerConfig'),
    };

    // 🎯 新增的页脚元素引用
    const footerElements = {
        contactItem1: document.getElementById('contactItem1'),
        contactItem2: document.getElementById('contactItem2'),
        contact1Label: document.getElementById('contact1Label'),
        contact1Value: document.getElementById('contact1Value'),
        contact2Label: document.getElementById('contact2Label'),
        contact2Value: document.getElementById('contact2Value'),
        link1: document.getElementById('footerLink1'),
        link2: document.getElementById('footerLink2'),
        contactGrid: document.querySelector('.contact-info-grid'),
        promoLinks: document.querySelector('.promo-links'),
    };


    // --- 核心函数 ---

    /**
     * 在页面顶部显示通知消息。
     * @param {string} text - 消息内容
     * @param {string} type - 消息类型 ('error', 'loading', 'success')
     */
    function showMessage(text, type = 'error') {
        displays.message.textContent = text;
        displays.message.className = `message-area show ${type}`;
    }

    /**
     * 隐藏通知消息。
     */
    function hideMessage() {
        displays.message.className = 'message-area';
    }

    /**
     * 切换到指定的步骤。
     * @param {number} stepNumber - 目标步骤编号 (1, 2, 3)
     */
    function goToStep(stepNumber) {
        Object.values(steps).forEach(step => step.classList.remove('active'));
        steps[`step${stepNumber}`]?.classList.add('active');
        hideMessage();
    }

    /**
     * 统一的 API 请求封装。
     * @param {string} endpoint - API 路径 (例如: 'verify_key.php')
     * @param {Object} body - 请求体数据
     * @returns {Promise<Object>} - API 响应数据
     */
    async function apiRequest(endpoint, body) {
        try {
            // 注意：前台 API 路径是 /api/xxx.php
            const response = await fetch(`api/${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            // 确保处理非 200 状态码
            if (!response.ok) {
                return { success: false, message: `服务器错误：HTTP ${response.status}` };
            }
            return await response.json();
        } catch (error) {
            console.error('API Request Error:', error);
            return { success: false, message: '网络请求失败，请检查您的网络连接。' };
        }
    }

    /**
     * 辅助函数：将文本复制到剪贴板并显示消息
     * @param {string} text - 要复制的文本
     * @param {string} type - 复制内容的类型 (例如: '微信号')
     */
    async function copyToClipboard(text, type) {
        try {
            await navigator.clipboard.writeText(text);
            showMessage(`${type} 已成功复制到剪贴板！`, 'success');
            setTimeout(hideMessage, 3000);
        } catch (err) {
            showMessage('复制失败，您的浏览器可能不支持此功能。', 'error');
        }
    }

    // --- 事件处理函数 ---

    /**
     * 处理卡密验证提交。
     */
    async function handleVerifyKey(event) {
        event.preventDefault();
        const cardKey = inputs.cardKey.value.trim();
        if (!cardKey) return;

        showMessage('正在验证...', 'loading');

        const data = await apiRequest('verify_key.php', { card_key: cardKey });

        if (data.success) {
            state.cardKey = data.data.card_key;
            displays.verifiedKey.textContent = state.cardKey;
            goToStep(2);
        } else {
            showMessage(data.message || '验证失败，请重试。', 'error');
        }
    }

    /**
     * 处理邮箱前缀输入和可用性检查（防抖）。
     */
    function handleUsernameCheck() {
        clearTimeout(state.usernameDebounceTimer);
        const username = inputs.username.value.trim();
        const resultEl = displays.usernameCheck;
        buttons.createAccount.disabled = true;

        if (username.length === 0) {
            resultEl.textContent = '';
            resultEl.className = 'validation-message';
            return;
        }

        // 前端格式校验
        if (!/^[a-z0-9._\-]{3,20}$/.test(username)) {
            resultEl.textContent = '格式错误 (3-20位, 仅限小写字母/数字/._-)';
            resultEl.className = 'validation-message error';
            return;
        }

        resultEl.textContent = '正在检查...';
        resultEl.className = 'validation-message checking';

        // 500ms 防抖
        state.usernameDebounceTimer = setTimeout(async () => {
            const data = await apiRequest('check_username.php', { username });

            resultEl.textContent = data.message;
            resultEl.className = `validation-message ${data.available ? 'success' : 'error'}`;
            buttons.createAccount.disabled = !data.available;
        }, 500);
    }

    /**
     * 处理账户创建提交。
     */
    async function handleCreateAccount(event) {
        event.preventDefault();
        const username = inputs.username.value.trim();

        // 确保卡密已验证且用户名已通过初步检查
        if (!state.cardKey || !username || buttons.createAccount.disabled) return;

        showMessage('正在为您开通邮箱，请稍候...', 'loading');
        buttons.createAccount.disabled = true;

        const data = await apiRequest('create_account.php', { card_key: state.cardKey, username: username });

        if (data.success) {
            const info = data.data;
            successInfoElements.email.textContent = info.email;
            successInfoElements.password.textContent = info.password;
            successInfoElements.loginUrl.textContent = info.login_url;
            successInfoElements.loginUrl.href = info.login_url;
            successInfoElements.promoUrl.textContent = info.promo_url;
            successInfoElements.promoUrl.href = info.promo_url;
            successInfoElements.serverConfig.textContent = info.server_config;
            document.getElementById('loginNowBtn').href = info.login_url;

            goToStep(3);
        } else {
            showMessage(data.message || '账户创建失败，请重试。', 'error');

            // 如果是“刚刚被注册”的竞争性错误，则返回步骤 2 重新检查
            if (data.message && data.message.includes('刚刚被注册')) {
                goToStep(2);
                handleUsernameCheck(); // 重新触发检查
            } else {
                buttons.createAccount.disabled = false;
            }
        }
    }

    /**
     * 优化：将所有成功信息复制到剪贴板。
     */
    async function handleCopyAll() {
        const textToCopy = `邮箱账号: ${successInfoElements.email.textContent}\n初始密码: ${successInfoElements.password.textContent}\n登录地址: ${successInfoElements.loginUrl.textContent}\n优惠平台: ${successInfoElements.promoUrl.textContent}\n邮箱配置: ${successInfoElements.serverConfig.textContent}\n\n⚠️ 为了您的账户安全，请立即登录并修改您的初始密码！`.trim();
        try {
            await navigator.clipboard.writeText(textToCopy);
            showMessage('所有信息已成功复制到剪贴板！', 'success');
            setTimeout(hideMessage, 3000); // 3秒后自动隐藏成功消息
        } catch (err) {
            showMessage('复制失败，您的浏览器可能不支持此功能。', 'error');
        }
    }

    /** * 初始化应用: 获取配置并绑定事件 
     */
    async function initApp() {
        try {
            const response = await fetch('api/get_settings.php');
            const data = await response.json();

            if (data.success && data.data) {
                const settings = data.data;
                state.targetDomain = settings.target_domain || '...';
                displays.domainAddon.textContent = `@${state.targetDomain}`;

                // --- 动态加载页脚 ---
                const footerEl = displays.footer;

                // 只有当 show_footer_info 为 '1' 时才处理并显示页脚
                if (settings.show_footer_info === '1') {

                    // --- 处理联系方式 #1 ---
                    if (settings.contact_1_label && settings.contact_1_value) {
                        const label = settings.contact_1_label;
                        const value = settings.contact_1_value;

                        footerElements.contact1Label.textContent = label;
                        footerElements.contact1Value.textContent = value;
                        // 动态设置图标：例如 📞, 📧, 📱
                        footerElements.contactItem1.querySelector('.icon').textContent = (label.includes('微信') || label.includes('QQ')) ? '📱' : (label.includes('邮箱') ? '📧' : '📞');

                        // 🎯 核心交互：绑定点击复制事件
                        footerElements.contactItem1.addEventListener('click', (e) => {
                            e.preventDefault();
                            copyToClipboard(value, label);
                        });
                        footerElements.contactItem1.style.display = 'flex';
                    } else { footerElements.contactItem1.style.display = 'none'; }

                    // --- 处理联系方式 #2 ---
                    if (settings.contact_2_label && settings.contact_2_value) {
                        const label = settings.contact_2_label;
                        const value = settings.contact_2_value;

                        footerElements.contact2Label.textContent = label;
                        footerElements.contact2Value.textContent = value;
                        footerElements.contactItem2.querySelector('.icon').textContent = (label.includes('微信') || label.includes('QQ')) ? '📱' : (label.includes('邮箱') ? '📧' : '📞');

                        // 🎯 核心交互：绑定点击复制事件
                        footerElements.contactItem2.addEventListener('click', (e) => {
                            e.preventDefault();
                            copyToClipboard(value, label);
                        });
                        footerElements.contactItem2.style.display = 'flex';
                    } else { footerElements.contactItem2.style.display = 'none'; }


                    // --- 处理友情链接 #1 ---
                    footerElements.link1.textContent = settings.footer_link_1_text || '';
                    footerElements.link1.href = settings.footer_link_1_url || '#';
                    if (!settings.footer_link_1_text) footerElements.link1.style.display = 'none'; else footerElements.link1.style.display = 'inline-flex';

                    // --- 处理友情链接 #2 ---
                    footerElements.link2.textContent = settings.footer_link_2_text || '';
                    footerElements.link2.href = settings.footer_link_2_url || '#';
                    if (!settings.footer_link_2_text) footerElements.link2.style.display = 'none'; else footerElements.link2.style.display = 'inline-flex';

                    // 🎯 优化：如果两个链接都没有，隐藏链接容器
                    if (!settings.footer_link_1_text && !settings.footer_link_2_text) {
                        footerElements.promoLinks.style.display = 'none';
                    } else {
                        footerElements.promoLinks.style.display = 'flex';
                    }

                    // 🎯 优化：如果两个联系方式都没有，隐藏联系方式容器
                    if (!settings.contact_1_label && !settings.contact_2_label) {
                        footerElements.contactGrid.style.display = 'none';
                    } else {
                        footerElements.contactGrid.style.display = 'grid';
                    }

                    footerEl.style.display = 'block';
                } else {
                    footerEl.style.display = 'none';
                }
            }
        } catch (error) {
            console.error('Failed to load initial settings:', error);
        }

        // 绑定所有事件监听器
        forms.verifyKey.addEventListener('submit', handleVerifyKey);
        forms.createAccount.addEventListener('submit', handleCreateAccount);
        inputs.username.addEventListener('input', handleUsernameCheck);
        document.getElementById('copyAllBtn').addEventListener('click', handleCopyAll);

        goToStep(1);
    }

    // --- 应用启动 ---
    initApp();
});