// 纯净版 admin_app.js (v1.1 - 增加 PWA 一键安装逻辑)
///public_html/assets/js/admin_app.js
// ----------------------------------------------------------------------
// ⚡ PWA 安装逻辑
// 必须在 DOMContentLoaded 外部监听 'beforeinstallprompt'，以确保捕获到事件
// ----------------------------------------------------------------------
let deferredPrompt;
const installButton = document.getElementById('install-button');
const installMessage = document.getElementById('install-message');

if (installButton) {
    // 1. 监听 PWA 安装事件
    window.addEventListener('beforeinstallprompt', (e) => {
        // 阻止默认的迷你信息栏/浏览器自动提示
        e.preventDefault();
        // 储存事件对象，以便后续触发
        deferredPrompt = e;
        
        // 仅在 install.php 页面且支持 PWA 时显示一键安装按钮
        if (window.location.pathname.includes('install.php')) {
             installButton.style.display = 'block';
             if (installMessage) {
                installMessage.textContent = '点击按钮，将管理后台像原生应用一样安装到主屏幕。';
             }
        }
    });

    // 2. 监听按钮点击事件
    installButton.addEventListener('click', (e) => {
        if (deferredPrompt) {
            // 隐藏按钮
            installButton.style.display = 'none';
            if (installMessage) {
                installMessage.textContent = '正在等待您的确认...';
            }

            // 触发安装提示
            deferredPrompt.prompt();

            // 监听用户对提示的响应
            deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === 'accepted') {
                    console.log('User accepted the install prompt');
                    if (installMessage) {
                        installMessage.textContent = '安装成功！您可以从主屏幕打开应用。';
                        installMessage.style.color = 'var(--success-color)';
                    }
                } else {
                    console.log('User dismissed the install prompt');
                    if (installMessage) {
                        installMessage.textContent = '已取消安装。您可以稍后重试，或通过下方指南手动添加。';
                        installMessage.style.color = 'var(--error-color)';
                    }
                    // 如果用户取消，重新显示按钮以便重试
                    installButton.style.display = 'block';
                }
                deferredPrompt = null; // 释放事件对象
            });
        }
    });
}


// ----------------------------------------------------------------------
// 📜 后台公共交互 (v1.0 原有逻辑)
// ----------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
    // --- DOM 元素缓存 ---
    const sidebar = document.querySelector('.sidebar');
    const toggleButton = document.getElementById('sidebar-toggle');
    const mainContent = document.querySelector('.main-content'); // 包含了侧边栏的父容器

    if (toggleButton && sidebar && mainContent) {
        /**
         * 切换侧边栏状态
         */
        function toggleSidebar() {
            // 切换侧边栏的 visible 类
            sidebar.classList.toggle('visible');
            
            // 在主内容区域添加或移除 overlay，防止点击
            if (sidebar.classList.contains('visible')) {
                mainContent.classList.add('sidebar-active');
            } else {
                mainContent.classList.remove('sidebar-active');
            }
        }

        toggleButton.addEventListener('click', toggleSidebar);

        // 监听主内容区域的点击事件，如果侧边栏打开，则点击关闭它
        mainContent.addEventListener('click', (event) => {
            // 只有在点击到 main-content 容器本身（即遮罩层）时才关闭
            if (sidebar.classList.contains('visible') && event.target === mainContent) {
                toggleSidebar();
            }
        });

        // 🎯 优化：监听窗口尺寸变化，在桌面端自动移除 mobile-only 状态
        let isMobileLayout = window.innerWidth < 768;
        
        window.addEventListener('resize', () => {
            const newIsMobileLayout = window.innerWidth < 768;
            if (isMobileLayout !== newIsMobileLayout) {
                isMobileLayout = newIsMobileLayout;
                if (!isMobileLayout) {
                    // 从移动端切换到桌面端时，确保移除所有移动端强制样式
                    sidebar.classList.remove('visible');
                    mainContent.classList.remove('sidebar-active');
                }
            }
        });
    }

});