<?php
// 文件路径: /public_html/cron/process_queue.php
//
// 这是一个由服务器 Cron Job 调用的脚本，用于异步处理邮件队列。
// 
// -----------------------------------------------------------------
// ❗️ Cron Job 设置指南
// -----------------------------------------------------------------
// 请在您的 DirectAdmin 面板设置一个定时任务 (Cron Job)，
// 每 5 分钟执行一次 (*/5 * * * *)。
// 
// 命令 (Command) 示例:
// wget -q -O- "https://your.domain.com/cron/process_queue.php?key=YOUR_STRONG_SECRET_KEY_HERE" > /dev/null 2>&1
//
// (请将 'YOUR_STRONG_SECRET_KEY_HERE' 替换为您在 config.php 中设置的密钥)
// -----------------------------------------------------------------

declare(strict_types=1);

// 1. 引入 PHPMailer 和 核心配置
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

require_once __DIR__ . '/../includes/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../includes/PHPMailer/SMTP.php';
require_once __DIR__ . '/../includes/PHPMailer/Exception.php';

require_once __DIR__ . '/../config.php';

// --- 2. 关键安全验证 ---
// 检查 config.php 中定义的密钥是否与 URL 参数匹配
if (PHP_SAPI !== 'cli' && (!isset($_GET['key']) || $_GET['key'] !== CRON_SECRET_KEY)) {
    http_response_code(403);
    die('Forbidden: Invalid or missing security key.');
}

// 设置执行限制
set_time_limit(240); // 4 分钟执行时间
ignore_user_abort(true); // 允许脚本在后台继续运行
header('Content-Type: text/plain; charset=utf-8');
echo "========= 邮件队列处理器 v1.2 =========\n";
echo "开始时间: " . date('Y-m-d H:i:s') . "\n";

// 定义处理批次大小
define('BATCH_SIZE', 5); // 每次 Cron Job 运行时最多发送 5 封邮件

try {
    // --- 3. 连接数据库并获取配置 ---
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 获取邮件发送配置
    $settings_stmt = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'smtp_%' OR setting_key = 'mail_transport'");
    $settings = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    $mail_transport = $settings['mail_transport'] ?? 'php_mail';
    
    // --- 4. 配置 PHPMailer 实例 ---
    $mail = new PHPMailer(true); // 启用异常
    $mail->CharSet = PHPMailer::CHARSET_UTF8;

    if ($mail_transport === 'smtp') {
        echo "模式: SMTP\n";
        // 使用 SMTP 配置
        $mail->isSMTP();
        $mail->Host = $settings['smtp_host'] ?? '';
        $mail->Port = (int)($settings['smtp_port'] ?? 465);
        $mail->SMTPSecure = $settings['smtp_secure'] ?? PHPMailer::ENCRYPTION_SMTPS;
        
        if (!empty($settings['smtp_user']) && !empty($settings['smtp_pass'])) {
            $mail->SMTPAuth = true;
            $mail->Username = $settings['smtp_user'];
            $mail->Password = $settings['smtp_pass'];
        }
        
        $mail->SMTPDebug = 0; 
        
    } else {
        echo "模式: PHP mail()\n";
        // 🎯 升级 v1.2.1：修正错误 - PHPMailer 默认使用 mail()，无需调用 isMail()
        // $mail->isMail(); // <--- 删除或注释掉这一行
        // 如果需要显式设置（虽然非必需），可以使用：
        // $mail->Mailer = 'mail'; 
    }

    // --- 5. 抓取并锁定待处理任务 ---
    $pdo->beginTransaction();
    
    // 从 mail_queue 表抓取 'pending' 任务
    $tasks_stmt = $pdo->query("SELECT id, recipient_email, subject, body, sender FROM mail_queue WHERE status = 'pending' ORDER BY id ASC LIMIT " . BATCH_SIZE);
    $tasks = $tasks_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($tasks)) {
        $pdo->rollBack();
        echo "队列中没有待处理的任务。\n";
        echo "========= 处理完成 =========\n";
        exit;
    }
    
    // 锁定这些任务，防止被其他进程重复抓取
    $task_ids = array_map(function($t) { return $t['id']; }, $tasks);
    $id_placeholders = implode(',', array_fill(0, count($task_ids), '?'));
    
    $lock_stmt = $pdo->prepare("UPDATE mail_queue SET status = 'sending' WHERE id IN ($id_placeholders)");
    $lock_stmt->execute($task_ids);
    $pdo->commit();

    echo "已锁定 " . count($tasks) . " 个任务，开始发送...\n\n";
    
    // --- 6. 循环处理任务 ---
    $sent_count = 0;
    $failed_count = 0;

    foreach ($tasks as $task) {
        try {
            // 清理上一封邮件的收件人
            $mail->clearAllRecipients();
            
            // 设置邮件内容 (从数据库读取)
            $mail->setFrom($task['sender'], $task['sender']); // (发件人名称使用邮箱本身)
            $mail->addAddress($task['recipient_email']);
            $mail->Subject = $task['subject'];
            $mail->isHTML(true); // 假设内容都是 HTML
            $mail->Body = $task['body'];
            // 备用纯文本内容
            $mail->AltBody = strip_tags($task['body']); 

            // 发送！
            $mail->send();
            
            // 成功：更新状态为 'sent'
            $update_stmt = $pdo->prepare("UPDATE mail_queue SET status = 'sent', sent_at = datetime('now', 'localtime'), error_message = NULL WHERE id = ?");
            $update_stmt->execute([$task['id']]);
            
            echo "  [OK] 成功发送至: " . $task['recipient_email'] . "\n";
            $sent_count++;

        } catch (PHPMailerException $e) {
            // 失败：更新状态为 'failed' 并记录错误
            $error_msg = $e->errorMessage(); // PHPMailer 错误
            
            $update_stmt = $pdo->prepare("UPDATE mail_queue SET status = 'failed', sent_at = datetime('now', 'localtime'), error_message = ? WHERE id = ?");
            $update_stmt->execute([$error_msg, $task['id']]);
            
            echo "  [!!] 发送失败至: " . $task['recipient_email'] . " | 错误: " . $error_msg . "\n";
            $failed_count++;
        }
    }

    echo "\n--- 批次总结 ---\n";
    echo "成功: $sent_count\n";
    echo "失败: $failed_count\n";

} catch (Exception $e) {
    // 捕获数据库连接错误或 PHPMailer 致命配置错误
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "[FATAL ERROR] 脚本执行中断: " . $e->getMessage() . "\n";
}

echo "========= 处理完成 =========\n";