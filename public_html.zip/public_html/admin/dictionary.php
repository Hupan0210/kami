<?php
// admin/dictionary.php - 更名为: Settings 表编辑器
require_once __DIR__ . '/../config.php';
$page_title = '⚙️ Settings 表编辑器'; // 更改页面标题
require_once __DIR__ . '/partials/header.php'; // 包含 auth.php 和 session_start()

$message = '';
$message_type = '';
$settings_entries = []; // 用于存储从 settings 表获取的数据

// 处理 Flash 消息
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message']['text'];
    $message_type = $_SESSION['flash_message']['type'];
    unset($_SESSION['flash_message']);
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // --- 处理 POST 请求 (添加, 更新, 删除) ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        
        // --- 添加新设置 ---
        if ($_POST['action'] === 'add_setting') {
            $setting_key = trim($_POST['setting_key'] ?? '');
            $setting_value = trim($_POST['setting_value'] ?? '');

            if (empty($setting_key)) { // 值允许为空
                $_SESSION['flash_message'] = ['text' => '错误：设置键 (Key) 不能为空。', 'type' => 'error'];
            } else {
                try {
                    // 使用 INSERT OR REPLACE 简化逻辑：如果键存在则更新，不存在则插入
                    $stmt_upsert = $pdo->prepare("INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES (?, ?)");
                    $stmt_upsert->execute([$setting_key, $setting_value]);
                    $_SESSION['flash_message'] = ['text' => "✅ 成功添加/更新设置项 “{$setting_key}”！", 'type' => 'success'];
                } catch (PDOException $e) {
                    $_SESSION['flash_message'] = ['text' => '数据库错误: ' . $e->getMessage(), 'type' => 'error'];
                }
            }
            header('Location: dictionary.php'); // 重定向回当前页面
            exit;
        }
        
        // --- 删除设置 ---
        elseif ($_POST['action'] === 'delete_setting') {
            $key_to_delete = $_POST['setting_key'] ?? '';
            // 增加一层保护，防止误删核心配置（可以根据需要调整这个列表）
            $protected_keys = ['admin_username', 'admin_password_hash', 'da_host', 'da_port', 'da_username', 'da_password', 'target_domain', 'mail_transport', 'CRON_SECRET_KEY']; // CRON_SECRET_KEY 不在数据库，但作为示例
            
            if (in_array($key_to_delete, $protected_keys)) {
                 $_SESSION['flash_message'] = ['text' => "❌ 操作不允许：无法删除核心设置项 “{$key_to_delete}”。请通过<a href='settings.php'>核心站点设置</a>页面修改。", 'type' => 'error'];
            } elseif (!empty($key_to_delete)) {
                 try {
                    $stmt_delete = $pdo->prepare("DELETE FROM settings WHERE setting_key = ?");
                    $stmt_delete->execute([$key_to_delete]);
                    if ($stmt_delete->rowCount() > 0) {
                        $_SESSION['flash_message'] = ['text' => "🗑️ 成功删除设置项 “{$key_to_delete}”！", 'type' => 'success'];
                    } else {
                         $_SESSION['flash_message'] = ['text' => "⚠️ 删除失败：未找到设置项 “{$key_to_delete}”。", 'type' => 'warning']; // 使用 warning 类型
                    }
                } catch (PDOException $e) {
                     $_SESSION['flash_message'] = ['text' => '数据库错误: ' . $e->getMessage(), 'type' => 'error'];
                }
            } else {
                 $_SESSION['flash_message'] = ['text' => '错误：缺少要删除的设置键。', 'type' => 'error'];
            }
             header('Location: dictionary.php'); // 重定向回当前页面
             exit;
        }

        // --- (未来可以添加更新逻辑，但 INSERT OR REPLACE 已涵盖) ---

    } // --- POST 处理结束 ---

    // --- 获取所有 settings 表条目 (GET 请求时) ---
    $stmt_select = $pdo->query("SELECT setting_key, setting_value FROM settings ORDER BY setting_key ASC");
    $settings_entries = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // 捕获数据库连接等其他错误
    $message = "数据库操作失败: " . $e->getMessage();
    $message_type = 'error';
}
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">➕ 添加/更新设置项</h2>
        <p class="card-subtitle">在此处添加新的配置键值对，或更新已存在的键的值。</p>
    </div>

    <?php if ($message && $message_type === 'error'): // 只在页面加载时显示错误 ?>
        <div class="alert alert-danger" style="margin-bottom: 1.5rem;"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if ($message && ($message_type === 'success' || $message_type === 'warning')): // 显示成功或警告消息 ?>
         <div class="alert <?php echo $message_type === 'success' ? 'badge-success' : 'badge-warning'; ?>" style="color: white; margin-bottom: 1.5rem;"><?php echo $message; // 允许 HTML for link ?></div>
    <?php endif; ?>


    <form method="POST" action="dictionary.php">
        <input type="hidden" name="action" value="add_setting">
        <div class="grid-form" style="grid-template-columns: 1fr; gap: 1rem;">
            <div class="form-group">
                <label for="setting_key">设置键 (Key)</label>
                <input type="text" id="setting_key" name="setting_key" required placeholder="例如：my_custom_api_key">
                <small>请使用字母、数字、下划线或点号。如果键已存在，则会更新其值。</small>
            </div>
            <div class="form-group">
                <label for="setting_value">设置值 (Value)</label>
                <textarea id="setting_value" name="setting_value" rows="3" placeholder="输入该设置项的值..."></textarea>
            </div>
        </div>
        <button type="submit" class="btn-primary" style="margin-top: 1rem;">
            💾 添加 / 更新
        </button>
    </form>
</div>


<div class="card">
    <div class="card-header">
        <h2 class="card-title">📋 现有 Settings 表条目</h2>
        <p class="card-subtitle">数据库 `settings` 表中存储的所有配置项。</p>
    </div>

    <?php if (empty($settings_entries) && !$message): // 仅在确实没有数据且没有错误时显示 ?>
        <p>Settings 表中还没有任何条目 (这不太可能发生)。</p>
    <?php elseif (!empty($settings_entries)): ?>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>设置键 (Key)</th>
                        <th>设置值 (Value)</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($settings_entries as $entry): ?>
                        <tr>
                            <td><code><?php echo htmlspecialchars($entry['setting_key']); ?></code></td>
                            <td>
                                <?php 
                                // 对密码等敏感字段进行部分隐藏 (可选)
                                if (strpos($entry['setting_key'], 'password') !== false || strpos($entry['setting_key'], 'pass') !== false || $entry['setting_key'] === 'da_password') {
                                    echo '******** (出于安全考虑已隐藏)';
                                } else {
                                    // 限制值的显示长度，防止过长内容撑破表格
                                    $display_value = htmlspecialchars($entry['setting_value']);
                                    if (mb_strlen($display_value) > 100) {
                                        echo mb_substr($display_value, 0, 100) . '...';
                                    } else {
                                        echo nl2br($display_value); // 保留换行符
                                    }
                                }
                                ?>
                            </td>
                            <td>
                                <button class="action-btn btn-edit" data-key="<?php echo htmlspecialchars($entry['setting_key']); ?>" data-value="<?php echo htmlspecialchars($entry['setting_value']); ?>">✏️ 编辑</button>
                                
                                <form method="POST" action="dictionary.php" style="display: inline-block; margin-left: 5px;" onsubmit="return confirm('确定要删除设置项 \'<?php echo htmlspecialchars($entry['setting_key']); ?>\' 吗？此操作可能导致系统异常！');">
                                     <input type="hidden" name="action" value="delete_setting">
                                     <input type="hidden" name="setting_key" value="<?php echo htmlspecialchars($entry['setting_key']); ?>">
                                     <button type="submit" class="action-btn btn-delete">🗑️ 删除</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<style>
/* 页面专属样式 */
textarea {
    resize: vertical; /* 允许垂直调整大小 */
}
/* 微调按钮样式 */
.action-btn.btn-edit { background-color: var(--primary-blue); }
.action-btn.btn-delete { background-color: var(--error-color); }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // --- 编辑功能：点击编辑按钮填充上方表单 ---
    const addForm = document.querySelector('form[action="dictionary.php"]'); // 获取添加/更新表单
    const keyInput = document.getElementById('setting_key');
    const valueInput = document.getElementById('setting_value');
    
    document.querySelectorAll('.btn-edit').forEach(button => {
        button.addEventListener('click', function() {
            const key = this.dataset.key;
            const value = this.dataset.value;
            
            // 将数据填充到添加/更新表单
            keyInput.value = key;
            valueInput.value = value;
            
            // 滚动到表单位置并高亮输入框
            addForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
            keyInput.focus(); 
            // 可选：添加简单的视觉提示
             addForm.style.transition = 'background-color 0.5s ease';
             addForm.style.backgroundColor = '#e7f3ff'; // 淡蓝色背景
             setTimeout(() => { addForm.style.backgroundColor = 'transparent'; }, 1000);
        });
    });
});
</script>

<?php require_once __DIR__ . '/partials/footer.php'; ?>