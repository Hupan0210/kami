<?php
// admin\keys.php
// v1.2 更新：
// - 新增批量导入卡密功能
// - 新增批量提取卡密功能
require_once __DIR__ . '/../config.php';
$page_title = '卡密管理';
require_once __DIR__ . '/partials/header.php'; // header.php 包含 auth.php 和 session_start()

$message = '';
$message_type = '';
$extracted_keys_list = null; // 用于存储提取结果

// 🎯 升级 v1.2：处理 Flash 消息
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message']['text'];
    $message_type = $_SESSION['flash_message']['type'];
    unset($_SESSION['flash_message']);
}

// 🎯 升级 v1.2：处理 Session 中的提取结果
if (isset($_SESSION['extracted_keys'])) {
    $extracted_keys_list = $_SESSION['extracted_keys'];
    unset($_SESSION['extracted_keys']);
}


// --- POST 请求处理 ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    // --- 批量生成功能 ---
    if ($_POST['action'] === 'generate_keys') {
        $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 1000]]);
        if ($amount === false) {
            $_SESSION['flash_message'] = ['text' => '请输入一个介于 1 到 1000 之间的有效数字。', 'type' => 'error'];
        } else {
            try {
                $pdo_gen = new PDO('sqlite:' . DB_PATH);
                $pdo_gen->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $pdo_gen->beginTransaction();
                $stmt_gen = $pdo_gen->prepare("INSERT INTO keys (card_key, status) VALUES (?, 'pristine')");
                $generated_count = 0;
                for ($i = 0; $i < $amount; $i++) {
                    $new_key = strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(bin2hex(random_bytes(3))) . '-' . strtoupper(bin2hex(random_bytes(3)));
                    // 尝试插入，忽略可能的重复键错误（虽然理论上随机生成重复概率极低）
                    try {
                        $stmt_gen->execute([$new_key]);
                        $generated_count++;
                    } catch (PDOException $e) {
                         if ($e->getCode() == 23000 || $e->getCode() == 19) { // SQLite unique constraint
                             continue; // 跳过重复
                         } else {
                             throw $e; // 重新抛出其他错误
                         }
                    }
                }
                $pdo_gen->commit();
                $_SESSION['flash_message'] = ['text' => "成功生成了 {$generated_count} 个新的卡密！", 'type' => 'success'];
            } catch (Exception $e) {
                if (isset($pdo_gen) && $pdo_gen->inTransaction()) $pdo_gen->rollBack();
                $_SESSION['flash_message'] = ['text' => '生成卡密时发生数据库错误: ' . $e->getMessage(), 'type' => 'error'];
            }
        }
        header('Location: keys.php?view=pristine'); // 生成后跳转回未使用页面
        exit;
    }

    // --- 🎯 升级 v1.2：批量导入功能 ---
    elseif ($_POST['action'] === 'import_keys') {
        $keys_list_raw = $_POST['keys_list'] ?? '';
        // 1. 清洗输入: 按行分割 -> 去除首尾空格 -> 转大写 -> 过滤空行 -> 去重
        $keys_to_import = array_unique(array_filter(array_map('strtoupper', array_map('trim', preg_split('/\r\n|\r|\n/', $keys_list_raw)))));

        if (empty($keys_to_import)) {
            $_SESSION['flash_message'] = ['text' => '导入列表为空或格式不正确。', 'type' => 'error'];
        } else {
            $imported_count = 0;
            $skipped_count = 0;
            try {
                $pdo_imp = new PDO('sqlite:' . DB_PATH);
                $pdo_imp->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $pdo_imp->beginTransaction();
                $stmt_imp = $pdo_imp->prepare("INSERT INTO keys (card_key, status) VALUES (?, 'pristine')");

                foreach ($keys_to_import as $key) {
                    // 再次验证格式 (可选，但推荐)
                    if (!preg_match('/^[A-Z0-9]{6}-[A-Z0-9]{6}-[A-Z0-9]{6}$/', $key)) {
                        $skipped_count++; // 格式错误也算跳过
                        continue;
                    }
                    try {
                        $stmt_imp->execute([$key]);
                        $imported_count++;
                    } catch (PDOException $e) {
                        if ($e->getCode() == 23000 || $e->getCode() == 19) { // SQLite unique constraint
                            $skipped_count++; // 捕获重复键错误
                        } else {
                            throw $e; // 重新抛出其他数据库错误
                        }
                    }
                }
                $pdo_imp->commit();
                $_SESSION['flash_message'] = ['text' => "导入完成！成功导入 {$imported_count} 个卡密，跳过 {$skipped_count} 个（重复或格式错误）。", 'type' => 'success'];
            } catch (Exception $e) {
                if (isset($pdo_imp) && $pdo_imp->inTransaction()) $pdo_imp->rollBack();
                $_SESSION['flash_message'] = ['text' => '导入卡密时发生数据库错误: ' . $e->getMessage(), 'type' => 'error'];
            }
        }
        header('Location: keys.php?view=pristine'); // 导入后跳转回未使用页面
        exit;
    }

    // --- 🎯 升级 v1.2：批量提取功能 ---
    elseif ($_POST['action'] === 'extract_keys') {
        $extract_amount = filter_input(INPUT_POST, 'extract_amount', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 1000]]);
        if ($extract_amount === false) {
             $_SESSION['flash_message'] = ['text' => '请输入一个介于 1 到 1000 之间的有效提取数量。', 'type' => 'error'];
        } else {
            try {
                $pdo_ext = new PDO('sqlite:' . DB_PATH);
                $pdo_ext->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $pdo_ext->beginTransaction();

                // 1. 查询足够数量的未使用卡密
                $stmt_select = $pdo_ext->prepare("SELECT id, card_key FROM keys WHERE status = 'pristine' ORDER BY id ASC LIMIT ?");
                $stmt_select->execute([$extract_amount]);
                $keys_to_extract = $stmt_select->fetchAll(PDO::FETCH_ASSOC);

                if (count($keys_to_extract) < $extract_amount) {
                    $pdo_ext->rollBack(); // 回滚事务
                    $_SESSION['flash_message'] = ['text' => "提取失败：当前仅剩 " . count($keys_to_extract) . " 个未使用卡密，不足 {$extract_amount} 个。", 'type' => 'error'];
                } else {
                    // 2. 更新这些卡密的状态
                    $stmt_update = $pdo_ext->prepare("UPDATE keys SET status = 'distributed', distributed_at = datetime('now', 'localtime') WHERE id = ?");
                    $extracted_keys_values = [];
                    foreach ($keys_to_extract as $key_data) {
                        $stmt_update->execute([$key_data['id']]);
                        $extracted_keys_values[] = $key_data['card_key'];
                    }

                    // 3. 将结果存入 Session
                    $_SESSION['extracted_keys'] = $extracted_keys_values;
                    $_SESSION['flash_message'] = ['text' => "成功提取 {$extract_amount} 个卡密！请复制下方结果。", 'type' => 'success'];
                    $pdo_ext->commit();
                }
            } catch (Exception $e) {
                if (isset($pdo_ext) && $pdo_ext->inTransaction()) $pdo_ext->rollBack();
                 $_SESSION['flash_message'] = ['text' => '提取卡密时发生数据库错误: ' . $e->getMessage(), 'type' => 'error'];
            }
        }
         header('Location: keys.php?view=pristine'); // 提取后保持在未使用页面
         exit;
    }

} // --- POST 请求处理结束 ---


// --- 页面核心逻辑 (GET) ---
try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $valid_views = ['pristine', 'distributed', 'redeemed'];
    $view = isset($_GET['view']) && in_array($_GET['view'], $valid_views) ? $_GET['view'] : 'pristine';
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    if ($page < 1) $page = 1;
    $items_per_page = 10;
    $offset = ($page - 1) * $items_per_page;
    
    // 获取计数
    $counts = ['pristine' => 0, 'distributed' => 0, 'redeemed' => 0];
    $count_stmt = $pdo->query("SELECT status, COUNT(*) as count FROM keys GROUP BY status");
    while ($row = $count_stmt->fetch(PDO::FETCH_ASSOC)) {
        if (array_key_exists($row['status'], $counts)) $counts[$row['status']] = $row['count'];
    }
    
    // 获取当前视图的卡密数据
    $total_items = $counts[$view];
    $total_pages = $total_items > 0 ? ceil($total_items / $items_per_page) : 1; // 修正无数据时的分页
    $keys_stmt = $pdo->prepare("SELECT * FROM keys WHERE status = ? ORDER BY id DESC LIMIT ? OFFSET ?");
    $keys_stmt->execute([$view, $items_per_page, $offset]);
    $keys = $keys_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $error_message = "数据库错误: " . $e->getMessage();
}
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">🔑 卡密管理</h2>
        <p class="card-subtitle">在这里管理、生成、导入和提取您的所有卡密。</p>
    </div>

    <?php if ($message): ?>
        <div class="alert <?php echo $message_type === 'success' ? 'badge-success' : 'alert-danger'; ?>" style="color: white; margin-bottom: 1.5rem;"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php if ($extracted_keys_list): ?>
    <div class="card" id="extracted-keys-card" style="margin-bottom: 1.5rem; border-color: var(--success-color);">
        <div class="card-header">
            <h3 class="card-title" style="color: var(--success-color);">✅ 提取结果 (<?php echo count($extracted_keys_list); ?> 个)</h3>
        </div>
        <textarea id="extracted-keys-textarea" readonly rows="10" style="width: 100%; font-family: monospace; resize: vertical;"><?php echo htmlspecialchars(implode("\n", $extracted_keys_list)); ?></textarea>
        <button id="copy-extracted-btn" class="btn-success" style="margin-top: 1rem;">📋 一键复制</button>
    </div>
    <?php endif; ?>


    <div class="grid-form" style="margin-bottom: 1.5rem; background-color: var(--bg-color); padding: 1.5rem; border-radius: 8px;">
        <form method="POST" action="keys.php">
            <input type="hidden" name="action" value="generate_keys">
            <h4 style="margin-top:0;">批量生成卡密</h4>
            <div style="display: flex; align-items: flex-end; gap: 1rem; flex-wrap: wrap;">
                <div style="flex-grow: 1;">
                    <label for="amount" style="display: block; font-weight: 500; margin-bottom: 0.5rem;">生成数量 (1-1000)</label>
                    <input type="number" name="amount" id="amount" value="10" min="1" max="1000" required>
                </div>
                <div><button type="submit" class="btn-primary">生成</button></div>
            </div>
        </form>

        <form method="POST" action="keys.php">
             <input type="hidden" name="action" value="import_keys">
             <h4 style="margin-top: 1.5rem;">批量导入卡密</h4>
             <div class="form-group">
                 <label for="keys_list">卡密列表 (每行一个)</label>
                 <textarea name="keys_list" id="keys_list" rows="5" placeholder="例如:&#10;ABCDEF-123456-UVWXYZ&#10;GHIJKL-789012-MNOPQR" required></textarea>
             </div>
             <button type="submit" class="btn-secondary">导入</button>
        </form>

        <form method="POST" action="keys.php">
             <input type="hidden" name="action" value="extract_keys">
             <h4 style="margin-top: 1.5rem;">批量提取卡密 (从未分发提取)</h4>
             <div style="display: flex; align-items: flex-end; gap: 1rem; flex-wrap: wrap;">
                 <div style="flex-grow: 1;">
                     <label for="extract_amount" style="display: block; font-weight: 500; margin-bottom: 0.5rem;">提取数量 (1-1000)</label>
                     <input type="number" name="extract_amount" id="extract_amount" value="10" min="1" max="1000" required>
                 </div>
                 <div><button type="submit" class="btn-success">提取</button></div>
             </div>
        </form>
    </div>


    <div class="nav-tabs">
        <a href="?view=pristine" class="<?php echo $view === 'pristine' ? 'active' : ''; ?>">未使用 (<?php echo $counts['pristine']; ?>)</a>
        <a href="?view=distributed" class="<?php echo $view === 'distributed' ? 'active' : ''; ?>">已分发 (<?php echo $counts['distributed']; ?>)</a>
        <a href="?view=redeemed" class="<?php echo $view === 'redeemed' ? 'active' : ''; ?>">已兑换 (<?php echo $counts['redeemed']; ?>)</a>
    </div>

    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
    <?php elseif (empty($keys)): ?>
        <p>此分类下没有卡密。</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>卡密</th><th>状态</th>
                        <?php if ($view === 'pristine'): ?><th>操作</th>
                        <?php elseif ($view === 'distributed'): ?><th>分发时间</th><th>操作</th>
                        <?php elseif ($view === 'redeemed'): ?><th>兑换邮箱</th><th>兑换时间</th><th>IP地址</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($keys as $key): ?>
                        <tr id="key-row-<?php echo $key['id']; ?>">
                            <td><code><?php echo htmlspecialchars($key['card_key']); ?></code></td>
                            <td>
                                <?php if ($key['status'] === 'redeemed'): ?><span class="badge badge-warning">已兑换</span>
                                <?php elseif ($key['status'] === 'distributed'): ?><span class="badge badge-distributed">已分发</span>
                                <?php else: ?><span class="badge badge-success">未使用</span><?php endif; ?>
                            </td>
                            <?php if ($view === 'pristine'): ?>
                                <td><button class="copy-btn" data-key-id="<?php echo $key['id']; ?>" data-key-value="<?php echo htmlspecialchars($key['card_key']); ?>">📋 一键复制</button></td>
                            <?php elseif ($view === 'distributed'): ?>
                                <td><?php echo htmlspecialchars($key['distributed_at'] ?? 'N/A'); ?></td>
                                <td><button class="reclaim-btn" data-key-id="<?php echo $key['id']; ?>">🔄 收回</button></td>
                            <?php elseif ($view === 'redeemed'): ?>
                                <td><?php echo htmlspecialchars($key['used_by_email'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($key['used_at'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($key['used_ip'] ?? 'N/A'); ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?><a href="?view=<?php echo $view; ?>&page=<?php echo $page - 1; ?>">« 上一页</a><?php else: ?><span class="disabled">« 上一页</span><?php endif; ?>
            <span class="current">第 <?php echo $page; ?> / <?php echo $total_pages; ?> 页</span>
            <?php if ($page < $total_pages): ?><a href="?view=<?php echo $view; ?>&page=<?php echo $page + 1; ?>">下一页 »</a><?php else: ?><span class="disabled">下一页 »</span><?php endif; ?>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script src="../assets/js/keys.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const copyExtractedBtn = document.getElementById('copy-extracted-btn');
    const extractedKeysTextarea = document.getElementById('extracted-keys-textarea');

    if (copyExtractedBtn && extractedKeysTextarea) {
        copyExtractedBtn.addEventListener('click', async function() {
            const textToCopy = extractedKeysTextarea.value;
            const originalText = this.textContent;
            try {
                await navigator.clipboard.writeText(textToCopy);
                this.textContent = '✅ 已复制!';
                this.disabled = true;
                setTimeout(() => {
                    this.textContent = originalText;
                    this.disabled = false;
                }, 2000);
            } catch (err) {
                alert('复制失败，您的浏览器可能不支持此功能。请手动复制。');
            }
        });
        
        // 提取结果卡片出现时，自动滚动到视图
        const extractedCard = document.getElementById('extracted-keys-card');
        if(extractedCard) {
            extractedCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
});
</script>


<style>
/* 确保表格行的淡出效果能够顺利执行 */
[id^="key-row-"] { transition: opacity 0.5s ease; }

/* 确保批量操作区域的输入框/文本域宽度 */
input[type="number"],
textarea {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    box-sizing: border-box;
}
textarea {
    resize: vertical; /* 允许垂直调整大小 */
    font-family: monospace; /* 方便查看卡密 */
}
/* 微调表单组之间的间距 */
.grid-form form + form {
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid var(--border-color);
}
.grid-form h4 {
    margin-bottom: 1rem;
}
</style>

<?php require_once __DIR__ . '/partials/footer.php'; ?>