<?php
// settings.php (admin\settings.php)
require_once __DIR__ . '/../config.php';
$page_title = '站点设置';
require_once __DIR__ . '/partials/header.php';

$message = '';
$message_type = '';

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $pdo->beginTransaction();
        $stmt_main = $pdo->prepare("INSERT OR REPLACE INTO settings (setting_key, setting_value) VALUES (?, ?)");
        
        // 🎯 升级 v1.2.1：将 "邮件方式" 也纳入安全验证
        $current_admin_pass = $_POST['current_admin_password'] ?? '';
        if (in_array($_POST['action'], ['update_system_settings', 'update_transport_settings', 'update_smtp_settings', 'update_password'])) {
             $stmt_hash = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'admin_password_hash'");
             $current_hash = $stmt_hash->fetchColumn();
             if (!password_verify($current_admin_pass, $current_hash)) {
                 throw new Exception('安全验证失败：当前管理员密码不正确。');
             }
        }

        if ($_POST['action'] === 'update_content_settings') {
            $settings_to_update = ['login_url','promo_url','server_config','contact_1_label','contact_1_value','contact_2_label','contact_2_value','footer_link_1_text','footer_link_1_url','footer_link_2_text','footer_link_2_url'];
            foreach ($settings_to_update as $key) { $stmt_main->execute([$key, trim($_POST[$key] ?? '')]); }
            $show_footer = isset($_POST['show_footer_info']) && $_POST['show_footer_info'] === '1' ? '1' : '0';
            $stmt_main->execute(['show_footer_info', $show_footer]);
            $message = '外观与内容设置已更新！'; $message_type = 'success';
        }

        if ($_POST['action'] === 'update_system_settings') {
            $system_settings_to_update = ['da_host', 'da_port', 'da_username', 'da_password', 'target_domain'];
            foreach ($system_settings_to_update as $key) {
                if (!isset($_POST[$key])) throw new Exception("缺少核心参数: {$key}");
                $stmt_main->execute([$key, trim($_POST[$key])]);
            }
            $message = '核心系统设置已成功更新！'; $message_type = 'success';
        }
        
        // 🎯 升级 v1.2.1：新增邮件发送方式保存逻辑
        if ($_POST['action'] === 'update_transport_settings') {
            $transport = $_POST['mail_transport'] ?? 'php_mail';
            if (!in_array($transport, ['php_mail', 'smtp'])) {
                $transport = 'php_mail'; // 安全回退
            }
            $stmt_main->execute(['mail_transport', $transport]);
            $message = '邮件发送方式已更新！'; $message_type = 'success';
        }
        
        if ($_POST['action'] === 'update_smtp_settings') {
            $smtp_settings_to_update = ['smtp_host', 'smtp_port', 'smtp_secure', 'smtp_user', 'smtp_pass'];
            foreach ($smtp_settings_to_update as $key) {
                if ($key === 'smtp_pass' && empty($_POST[$key])) {
                    // 密码留空，不更新
                } else {
                    $stmt_main->execute([$key, trim($_POST[$key] ?? '')]);
                }
            }
            $message = 'SMTP 邮件发送设置已更新！'; $message_type = 'success';
        }


        if ($_POST['action'] === 'update_password') {
            $new_pass = $_POST['new_password']; $confirm_pass = $_POST['confirm_password'];
            if (empty($new_pass) || empty($confirm_pass)) throw new Exception('新密码和确认密码不能为空。');
            if ($new_pass !== $confirm_pass) throw new Exception('新密码和确认密码不匹配。');
            $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $updateStmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'admin_password_hash'");
            $updateStmt->execute([$new_hash]);
            $message = '管理员密码已成功修改！'; $message_type = 'success';
        }
        $pdo->commit();
    }
    
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    $message = '操作失败: ' . $e->getMessage(); $message_type = 'error';
    if (!isset($settings)) {
         $stmt_fallback = $pdo->query("SELECT setting_key, setting_value FROM settings");
         $settings = $stmt_fallback->fetchAll(PDO::FETCH_KEY_PAIR);
    }
}
?>
<?php if ($message): ?>
    <div class="alert <?php echo $message_type === 'success' ? 'badge-success' : 'alert-danger'; ?>" style="color: white; margin-bottom: 1.5rem;"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h2 class="card-title">🎨 外观与内容</h2><p class="card-subtitle">管理所有面向用户的显示信息。</p></div>
    <form method="POST" action="settings.php" id="contentSettingsForm">
        <input type="hidden" name="action" value="update_content_settings">
        <h4>通用内容</h4>
        <div class="grid-form">
            <div class="form-group"><label for="login_url">登录地址</label><input type="text" id="login_url" name="login_url" value="<?php echo htmlspecialchars($settings['login_url'] ?? ''); ?>"></div>
            <div class="form-group"><label for="promo_url">优惠平台链接</label><input type="text" id="promo_url" name="promo_url" value="<?php echo htmlspecialchars($settings['promo_url'] ?? ''); ?>"></div>
            <div class="form-group"><label for="server_config">邮箱配置信息</label><input type="text" id="server_config" name="server_config" value="<?php echo htmlspecialchars($settings['server_config'] ?? ''); ?>"></div>
        </div>
        <hr class="form-divider">
        <h4>页脚信息</h4>
        <div class="form-group"><label>前端页脚信息展示</label><div class="toggle-switch"><input type="radio" id="show_footer_on" name="show_footer_info" value="1" <?php echo ($settings['show_footer_info'] ?? '1') === '1' ? 'checked' : ''; ?>><label for="show_footer_on">开启</label><input type="radio" id="show_footer_off" name="show_footer_info" value="0" <?php echo ($settings['show_footer_info'] ?? '1') === '0' ? 'checked' : ''; ?>><label for="show_footer_off">关闭</label></div></div>
        <div class="grid-form">
            <div class="form-group"><label for="contact_1_label">联系方式 #1 标签</label><input type="text" id="contact_1_label" name="contact_1_label" value="<?php echo htmlspecialchars($settings['contact_1_label'] ?? '微信号'); ?>" placeholder="例如: 微信号, Telegram"></div>
            <div class="form-group"><label for="contact_1_value">联系方式 #1 内容</label><input type="text" id="contact_1_value" name="contact_1_value" value="<?php echo htmlspecialchars($settings['contact_1_value'] ?? ''); ?>" placeholder="例如: my_wechat_id, https://t.me/..."></div>
            <div class="form-group"><label for="contact_2_label">联系方式 #2 标签</label><input type="text" id="contact_2_label" name="contact_2_label" value="<?php echo htmlspecialchars($settings['contact_2_label'] ?? '联系电话'); ?>" placeholder="例如: 联系电话, 支持邮箱"></div>
            <div class="form-group"><label for="contact_2_value">联系方式 #2 内容</label><input type="text" id="contact_2_value" name="contact_2_value" value="<?php echo htmlspecialchars($settings['contact_2_value'] ?? ''); ?>" placeholder="例如: 138..., mailto:..."></div>
            <div class="form-group"><label for="footer_link_1_text">友情链接 #1 文字</label><input type="text" id="footer_link_1_text" name="footer_link_1_text" value="<?php echo htmlspecialchars($settings['footer_link_1_text'] ?? ''); ?>"></div>
            <div class="form-group"><label for="footer_link_1_url">友情链接 #1 URL</label><input type="text" id="footer_link_1_url" name="footer_link_1_url" value="<?php echo htmlspecialchars($settings['footer_link_1_url'] ?? ''); ?>"></div>
            <div class="form-group"><label for="footer_link_2_text">友情链接 #2 文字</label><input type="text" id="footer_link_2_text" name="footer_link_2_text" value="<?php echo htmlspecialchars($settings['footer_link_2_text'] ?? ''); ?>"></div>
            <div class="form-group"><label for="footer_link_2_url">友情链接 #2 URL</label><input type="text" id="footer_link_2_url" name="footer_link_2_url" value="<?php echo htmlspecialchars($settings['footer_link_2_url'] ?? ''); ?>"></div>
        </div>
        <button type="submit" class="btn-primary">保存设置</button>
    </form>
</div>

<div class="card">
    <div class="card-header"><h2 class="card-title">⚙️ 核心系统</h2><p class="card-subtitle" style="color: var(--error-color);"><b>警告:</b> 更改这些设置可能会导致邮件创建功能中断，请谨慎操作。</p></div>
    <form method="POST" action="settings.php" id="systemSettingsForm">
        <input type="hidden" name="action" value="update_system_settings">
        <div class="grid-form">
            <div class="form-group"><label for="da_host">DA 服务器地址</label><input type="text" id="da_host" name="da_host" value="<?php echo htmlspecialchars($settings['da_host'] ?? ''); ?>" required><small>无需 https:// 或端口</small></div>
            <div class="form-group"><label for="da_port">DA 端口</label><input type="number" id="da_port" name="da_port" value="<?php echo htmlspecialchars($settings['da_port'] ?? ''); ?>" required></div>
            <div class="form-group"><label for="da_username">DA 用户名</label><input type="text" id="da_username" name="da_username" value="<?php echo htmlspecialchars($settings['da_username'] ?? ''); ?>" required></div>
            <div class="form-group"><label for="da_password">DA 登录密钥</label><input type="text" id="da_password" name="da_password" value="<?php echo htmlspecialchars($settings['da_password'] ?? ''); ?>" required><small>强烈建议使用专用的 API 密钥</small></div>
            <div class="form-group"><label for="target_domain">目标邮箱域名</label><input type="text" id="target_domain" name="target_domain" value="<?php echo htmlspecialchars($settings['target_domain'] ?? ''); ?>" required><small>例如: eebu.edu.pl</small></div>
        </div>
        <div style="display: flex; gap: 1rem; align-items: center; flex-wrap: wrap; margin-top: 1.5rem;">
             <button type="submit" class="btn-primary">保存核心设置</button>
             <button type="button" id="testDaConnectionBtn" class="btn-secondary">测试 DA 连接</button>
        </div>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">📬 邮件发送方式</h2>
        <p class="card-subtitle">选择“群发邮件”功能使用何种方式发送邮件。</p>
    </div>
    <form method="POST" action="settings.php" id="transportSettingsForm">
        <input type="hidden" name="action" value="update_transport_settings">
        <div class="form-group">
            <?php $current_transport = $settings['mail_transport'] ?? 'php_mail'; ?>
            <div class="toggle-switch" style="width: 100%; max-width: 400px;">
                <input type="radio" id="transport_php" name="mail_transport" value="php_mail" <?php echo $current_transport === 'php_mail' ? 'checked' : ''; ?>>
                <label for="transport_php">PHP mail() (不推荐)</label>
                
                <input type="radio" id="transport_smtp" name="mail_transport" value="smtp" <?php echo $current_transport === 'smtp' ? 'checked' : ''; ?>>
                <label for="transport_smtp">SMTP (推荐)</label>
            </div>
            <small style="margin-top: 0.5rem;">
                <?php if ($current_transport === 'php_mail'): ?>
                    当前使用 `PHP mail()` 函数，送达率低且易被视为垃圾邮件。
                <?php else: ?>
                    当前使用 <b>SMTP</b>。请确保下方 SMTP 凭据配置正确。
                <?php endif; ?>
            </small>
        </div>
        <button type="submit" class="btn-primary" style="margin-top: 1.5rem;">保存发送方式</button>
    </form>
</div>


<div class="card">
    <div class="card-header">
        <h2 class="card-title">✉️ SMTP 邮件发送设置</h2>
        <p class="card-subtitle">
            用于“群发邮件”功能。推荐使用专业的邮件服务 (如 Mailgun, SendGrid) 的凭据。
        </p>
    </div>
    <form method="POST" action="settings.php" id="smtpSettingsForm">
        <input type="hidden" name="action" value="update_smtp_settings">
        <div class="grid-form">
            <div class="form-group">
                <label for="smtp_host">SMTP 服务器地址</label>
                <input type="text" id="smtp_host" name="smtp_host" value="<?php echo htmlspecialchars($settings['smtp_host'] ?? ''); ?>" placeholder="例如: smtp.mailgun.org">
            </div>
            <div class="form-group">
                <label for="smtp_port">SMTP 端口</label>
                <input type="number" id="smtp_port" name="smtp_port" value="<?php echo htmlspecialchars($settings['smtp_port'] ?? '465'); ?>" placeholder="例如: 465, 587">
            </div>
            <div class="form-group">
                <label for="smtp_secure">加密方式</label>
                <select id="smtp_secure" name="smtp_secure" class="form-select">
                    <option value="ssl" <?php echo ($settings['smtp_secure'] ?? 'ssl') === 'ssl' ? 'selected' : ''; ?>>SSL (端口 465)</option>
                    <option value="tls" <?php echo ($settings['smtp_secure'] ?? '') === 'tls' ? 'selected' : ''; ?>>TLS (端口 587)</option>
                    <option value="none" <?php echo ($settings['smtp_secure'] ?? '') === 'none' ? 'selected' : ''; ?>>无加密 (不推荐)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="smtp_user">SMTP 用户名</label>
                <input type="text" id="smtp_user" name="smtp_user" value="<?php echo htmlspecialchars($settings['smtp_user'] ?? ''); ?>" placeholder="例如: postmaster@your-domain.com">
            </div>
            <div class="form-group">
                <label for="smtp_pass">SMTP 密码</label>
                <input type="password" id="smtp_pass" name="smtp_pass" value="" placeholder="输入新密码以更新">
                <small>如不更改，请留空。</small>
            </div>
        </div>
        <button type="submit" class="btn-primary" style="margin-top: 1.5rem;">保存 SMTP 设置</button>
    </form>
</div>
<div class="card">
    <div class="card-header"><h2 class="card-title">🛡️ 安全中心</h2><p class="card-subtitle">定期修改您的后台登录密码以增强安全性。</p></div>
    <form method="POST" action="settings.php" id="passwordSettingsForm" style="max-width: 400px;">
        <input type="hidden" name="action" value="update_password">
        <div class="form-group">
            <label for="new_password">新密码</label>
            <input type="password" id="new_password" name="new_password" required>
        </div>
        <div class="form-group">
            <label for="confirm_password">确认新密码</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>
        <button type="submit" class="btn-success">修改密码</button>
    </form>
</div>

<script src="../assets/js/settings.js"></script>

<style>
/* 局部样式保留：仅保留 toggle-switch 和 form-group 细节，以确保兼容性 */
.form-group label{display:block;font-weight:500;margin-bottom:.5rem}
.form-group small{color:var(--secondary-text-color);font-size:.8rem;margin-top:.25rem;display:block}
.toggle-switch{display:flex;border:1px solid var(--border-color);border-radius:8px;overflow:hidden;width:fit-content}
.toggle-switch label{padding:.5rem 1rem;cursor:pointer;background-color:var(--bg-color);color:var(--secondary-text-color);flex-grow: 1; text-align: center;}
.toggle-switch input{display:none}
.toggle-switch input:checked+label{background-color:var(--primary-blue);color:#fff}
.form-divider{margin:2rem 0;border:0;border-top:1px solid var(--border-color)}
/* 🎯 升级 v1.2：为 select 标签添加样式 */
.form-select { 
    width: 100%; 
    padding: 0.75rem; 
    border: 1px solid var(--border-color); 
    border-radius: 8px; 
    font-size: 1rem; 
    box-sizing: border-box; 
    background-color: var(--card-bg-color);
}
</style>

<?php require_once __DIR__ . '/partials/footer.php'; ?>