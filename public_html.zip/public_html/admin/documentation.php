<?php
// admin/documentation.php - 项目使用文档
require_once __DIR__ . '/../config.php';
$page_title = '📚 项目使用文档';
require_once __DIR__ . '/partials/header.php'; // 包含 auth.php 和 session_start()

// 尝试读取 Cron 密钥用于文档示例
$cron_key_example = defined('CRON_SECRET_KEY') && CRON_SECRET_KEY !== 'YOUR_STRONG_SECRET_KEY_HERE' 
    ? CRON_SECRET_KEY 
    : '[请在 config.php 中设置]';

// 尝试获取当前域名用于示例 URL
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$domain_name = $_SERVER['HTTP_HOST'] ?? 'your.domain.com';
$base_path = dirname($_SERVER['PHP_SELF'], 2); // 获取 /public_html 对应的 Web 路径
$base_url = rtrim($protocol . $domain_name . $base_path, '/');
$cron_url_example = $base_url . '/cron/process_queue.php?key=' . urlencode($cron_key_example);
$cron_command_example = 'wget -q -O- "' . $cron_url_example . '" > /dev/null 2>&1';

?>

<style>
    /* 文档页面专属样式 */
    .doc-section { margin-bottom: 2.5rem; }
    .doc-section h3 { 
        border-bottom: 2px solid var(--primary-blue); 
        padding-bottom: 0.5rem; 
        margin-top: 0;
        margin-bottom: 1rem;
        font-size: 1.3rem;
    }
    .doc-section h4 {
        margin-top: 1.5rem;
        margin-bottom: 0.5rem;
        font-size: 1.1rem;
        color: var(--primary-blue);
    }
    .doc-section p, .doc-section li { line-height: 1.7; }
    .doc-section code { 
        background-color: var(--bg-color); 
        padding: 0.2em 0.4em; 
        border-radius: 4px; 
        font-family: "SF Mono", Menlo, monospace;
        font-size: 0.9em;
        word-break: break-all;
    }
    .doc-section strong { color: var(--text-color); }
    .doc-section ul { padding-left: 25px; }
    .doc-section .badge { margin-left: 5px; } /* 微调徽章间距 */
    .security-note {
        border-left: 4px solid var(--error-color);
        padding: 1rem;
        background-color: rgba(220, 53, 69, 0.05);
        margin-top: 1rem;
    }
    .security-note strong { color: var(--error-color); }
</style>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"><?php echo $page_title; ?></h2>
        <p class="card-subtitle">学生邮箱自助开通平台 v1.2 使用指南</p>
    </div>

    <section class="doc-section">
        <h3>🚀 1. 项目概述</h3>
        <p>本项目旨在提供一个全自动化的学生邮箱自助开通服务。用户通过输入有效的卡密，即可自助选择邮箱前缀并开通邮箱账户。管理员则拥有强大的后台管理功能，包括卡密管理、邮箱账户管理、邮件群发等。</p>
        <h4>核心功能：</h4>
        <ul>
            <li>✨ 用户前台: 卡密验证、邮箱前缀可用性检查、自助开通账户。</li>
            <li>🔑 卡密管理: 批量生成、批量导入、批量提取、状态跟踪（未使用/已分发/已兑换）。</li>
            <li>📧 邮箱管理: 列表查看（带缓存加速）、模拟登录 (需 RoundCube 支持)、修改密码、删除账户。</li>
            <li>➕ 手动创建: 管理员可手动为用户创建邮箱账户。</li>
            <li>📬 邮件群发: 创建邮件队列，支持向所有已兑换用户或指定用户发送，由 Cron Job 自动后台处理。</li>
            <li>🤖 Cron 控制面板: 辅助设置 Cron Job、手动触发队列、监控队列状态和失败日志。</li>
            <li>📖 术语词典: 管理后台数据库术语及其解释。</li>
            <li>⚙️ 系统设置: 配置站点外观、联系方式、DirectAdmin API、邮件发送方式 (PHP Mail/SMTP) 及 SMTP 凭据。</li>
            <li>📱 PWA 支持: 可将后台添加至手机主屏幕，方便访问。</li>
        </ul>
    </section>

    <section class="doc-section">
        <h3>🔧 2. 安装与配置</h3>
        <h4>首次安装</h4>
        <ol>
            <li>将项目文件上传至服务器 public_html 目录。</li>
            <li>确保服务器环境满足要求（PHP >= 7.4, PDO SQLite 扩展）。</li>
            <li>确保 public_html 目录本身具有写入权限（用于创建 database 和 cache 目录）。</li>
            <li>通过浏览器访问 https://<?php echo $domain_name . $base_path; ?>/setup.php 并按照向导完成数据库创建和核心配置。</li>
            <li>安装完成后，访问 admin/reset_admin_pass.php 获取初始管理员密码，并立即登录后台修改。</li>
            <li>（极其重要） 登录成功后，必须立即删除服务器上的 setup.php 和 admin/reset_admin_pass.php 文件！</li>
        </ol>
        <h4>核心配置文件 (config.php)</h4>
        <ul>
            <li><code>DB_PATH</code>: 定义 SQLite 数据库文件的路径，由 setup.php 创建，通常无需修改。</li>
            <li><code>CRON_SECRET_KEY</code>: 必须手动设置一个长且随机的安全密钥。此密钥用于保护 cron/process_queue.php 脚本不被未授权访问。您可以在 <a href="cron_manager.php">Cron Job 控制面板</a> 查看当前设置并获取 Cron 命令。</li>
        </ul>
        <h4>后台设置 (admin/settings.php)</h4>
        <p>后台的“核心站点设置”页面提供了对系统关键参数的图形化管理界面：</p>
        <ul>
            <li>外观与内容: 配置前台显示的登录地址、联系方式、页脚链接等。</li>
            <li>核心系统: 配置 DirectAdmin API 连接信息和目标邮箱域名。修改这些设置需要输入当前管理员密码。</li>
            <li>邮件发送方式: 选择使用服务器 PHP mail() 函数（不推荐）还是外部 SMTP 服务器。修改此设置需要密码。</li>
            <li>SMTP 设置: 如果选择 SMTP 方式，在此配置 SMTP 服务器的详细信息（主机、端口、用户、密码、加密）。修改此设置需要密码。</li>
            <li>安全中心: 修改管理员登录密码。修改此设置需要输入当前管理员密码。</li>
        </ul>
    </section>
    
    <section class="doc-section">
        <h3>👤 3. 前台用户流程 (index.php)</h3>
        <p>最终用户（学生）访问网站首页 https://<?php echo $domain_name . $base_path; ?>/index.php 进行自助开通：</p>
        <ol>
            <li><strong>验证卡密:</strong> 用户输入管理员分发的卡密。系统通过 api/verify_key.php 验证卡密是否有效（状态为 pristine 或 distributed）。</li>
            <li><strong>选择前缀:</strong> 验证通过后，用户输入期望的邮箱前缀（例如 zhangsan）。系统通过 api/check_username.php 实时检查该前缀在 DirectAdmin 上是否可用。</li>
            <li><strong>创建账户:</strong> 用户点击创建按钮。系统通过 api/create_account.php 调用 DirectAdmin API 创建邮箱账户，并将卡密状态更新为 redeemed。</li>
            <li><strong>获取信息:</strong> 页面显示新创建的邮箱地址、初始密码、登录链接等信息。</li>
        </ol>
     </section>

    <section class="doc-section">
        <h3>🛠️ 4. 后台管理模块 (admin/)</h3>
        <p>管理员登录后 (admin/index.php)，可以通过侧边栏访问以下模块：</p>
        
        <h4>📊 数据查看仪表 (dashboard.php)</h4>
        <ul>
            <li>实时显示卡密统计：今日兑换、未使用、已分发、已兑换总数。</li>
            <li>数据每 5 秒自动刷新。</li>
        </ul>

        <h4>🔑 卡密管理中心 (keys.php)</h4>
        <ul>
            <li><strong>查看:</strong> 按状态（未使用/已分发/已兑换）分页查看卡密列表。</li>
            <li><strong>生成:</strong> 在线批量生成指定数量的新卡密。</li>
            <li><strong>导入:</strong> 粘贴卡密列表（每行一个）批量导入。</li>
            <li><strong>提取:</strong> 指定数量，将未使用卡密批量标记为“已分发”并显示列表供复制。</li>
            <li><strong>操作 (未使用):</strong> <span class="badge badge-primary">一键复制</span> - 复制卡密及使用说明，同时将状态更新为“已分发”。</li>
            <li><strong>操作 (已分发):</strong> <span class="badge badge-warning">收回</span> - 将状态改回“未使用”（仅当未被兑换时）。</li>
        </ul>

        <h4>📧 邮箱管理中心 (mailboxes.php)</h4>
        <ul>
            <li><strong>列表与缓存:</strong> 显示 DirectAdmin 上的所有邮箱账户及其状态、容量使用情况。首次加载可能较慢，之后会使用缓存（cache/da_usage.json）实现快速加载。</li>
            <li><strong>搜索:</strong> 按邮箱前缀进行筛选。</li>
            <li><span class="badge badge-success">刷新列表</span>: 点击此按钮会强制清除缓存并从 DirectAdmin 重新获取最新数据。</li>
            <li><span class="badge badge-primary">登录</span>: （需 Webmail 支持）在新标签页尝试模拟登录该邮箱账户。</li>
            <li><span class="badge badge-primary">改密</span>: 强制重置指定邮箱账户的密码（需输入新密码）。</li>
            <li><span class="badge badge-danger">删除</span>: 从 DirectAdmin 删除该邮箱账户（操作不可逆）。</li>
            <li>*注意：删除、改密操作成功后会自动清除缓存*。</li>
        </ul>

        <h4>➕ 手动创建邮箱 (create_email.php)</h4>
        <ul>
            <li>允许管理员直接输入邮箱前缀、选择配额和发送限制，手动创建邮箱账户。</li>
            <li>密码将使用“核心站点设置” 中配置的 default_email_password。</li>
            <li>创建成功后会显示包含账号信息的复制模板。</li>
        </ul>

        <h4>✉️ 群发邮件管理 (send_mail.php)</h4>
        <ul>
            <li>选择发件人（必须是 SMTP 账户有权发送的地址）。</li>
            <li>选择收件人：<span class="badge badge-info">所有已兑换邮箱</span> (从 keys 表 获取) 或 <span class="badge badge-info">指定邮箱</span> (手动输入)。</li>
            <li>输入邮件主题和内容（支持 HTML）。</li>
            <li>点击 <span class="badge badge-primary">创建邮件队列</span>，任务将被添加到 mail_queue 表。</li>
            <li>之后由服务器设置的 Cron Job 自动调用 cron/process_queue.php 在后台发送。</li>
        </ul>

        <h4>🤖 Cron Job 控制面板 (cron_manager.php)</h4>
        <ul>
            <li><strong>设置助手:</strong> 显示当前的 CRON_SECRET_KEY，自动生成 Cron 命令，并提供 DirectAdmin 设置步骤。</li>
            <li><strong>手动触发:</strong> 允许管理员立即运行一次邮件处理脚本，并查看实时日志输出。</li>
            <li><strong>状态监控:</strong> 显示队列中待处理、已发送、已失败的邮件数量。</li>
            <li><strong>失败日志:</strong> 列出发送失败的邮件及失败原因（来自 PHPMailer 或 mail() 函数）。</li>
            <li><strong>错误排查:</strong> 提供设置 Cron Job 时的常见问题及解决方案。</li>
        </ul>
        
         <h4>📖 数据库编辑器 (dictionary.php)</h4>
         <ul>
             <li>添加新的数据库字符及其对应的中文解释到数据库表。</li>
             <li>查看当前数据库中已存在的所有词条。</li>
         </ul>

        <h4>📱 快捷方式安装 (install.php)</h4>
        <ul>
            <li>提供在 iOS 和 Android 设备上将后台管理界面添加到主屏幕的操作指南。</li>
            <li>如果浏览器支持 PWA，会显示“一键安装”按钮。</li>
            <li>需要确保 assets/img/ 目录下存在 app-icon-192.png 和 app-icon-512.png 文件。</li>
        </ul>
         
        <h4>⚙️ 核心站点设置 (settings.php)</h4>
         <ul>
             <li>见上方“安装与配置”部分的说明。</li>
         </ul>

    </section>
    
    <section class="doc-section">
        <h3>🕰️ 5. Cron Job (cron/process_queue.php)</h3>
        <p>这是实现邮件队列“真”异步发送的核心。</p>
        <ul>
            <li><strong>安全性:</strong> 必须通过 URL 参数传递正确的 ?key= 值才能运行。此密钥在 config.php 中定义。</li>
            <li><strong>执行方式:</strong> 应由服务器的 Cron Job (定时任务) 定期（推荐每 5 分钟）通过 wget 或 curl 访问其 URL 来触发。</li>
            <li><strong>功能:</strong> 每次运行时，它会从数据库 mail_queue 表 中取出少量（默认 5 封） 待发送的邮件，根据 admin/settings.php 中配置的方式（PHP Mail 或 SMTP） 尝试发送，并更新邮件状态（sent 或 failed）。</li>
            <li><strong>日志:</strong> 执行结果会以纯文本形式输出，方便在 Cron Job 管理界面查看或调试。</li>
            <li><strong>配置:</strong> 请参考 <a href="cron_manager.php">Cron Job 控制面板</a> 获取详细的设置命令和步骤。</li>
        </ul>
    </section>

    <section class="doc-section">
        <h3>🛡️ 6. 安全注意事项</h3>
        <div class="security-note">
            <p><strong>极其重要：</strong></p>
            <ul>
                <li>完成首次安装后，必须立即删除服务器根目录下的 <code>setup.php</code> 文件！</li>
                <li>使用 <code>admin/reset_admin_pass.php</code> 获取初始密码后，必须立即删除该文件！</li>
            </ul>
        </div>
        <ul>
            <li><strong>管理员密码:</strong> 首次登录后，请务必在“核心站点设置” 中修改为您自己的强密码。</li>
            <li><strong>Cron 密钥:</strong> 务必在 <code>config.php</code> 中设置一个长且随机的 <code>CRON_SECRET_KEY</code>，并确保 Cron Job 命令 使用了正确的密钥。不要泄露此密钥。</li>
            <li><strong>DirectAdmin 密钥:</strong> 在 setup.php 或后台设置 中，强烈建议使用 DirectAdmin 的“登录密钥 (Login Key)”功能创建一个仅具有 CMD_API_POP 权限的专用密钥，而不是直接使用您的 DA 主密码。</li>
            <li><strong>文件权限:</strong> 确保只有 database 和 cache 目录需要服务器写入权限。其他 PHP 文件应设置为只读权限（例如 644）。</li>
            <li>HTTPS: 强烈建议为网站启用 HTTPS，以保护登录凭据和 API 通信不被窃听。</li>
            
        </ul>
    </section>

</div>

<script>
    // 为文档页面添加简单的代码复制功能 (可选)
    document.querySelectorAll('.doc-section code').forEach(codeBlock => {
        codeBlock.style.cursor = 'pointer';
        codeBlock.title = '点击复制';
        codeBlock.addEventListener('click', async (e) => {
            const textToCopy = e.target.innerText;
            try {
                await navigator.clipboard.writeText(textToCopy);
                // 可以在此处添加一个短暂的“已复制”提示
                e.target.style.backgroundColor = 'var(--success-color)';
                e.target.style.color = 'white';
                setTimeout(() => {
                    e.target.style.backgroundColor = 'var(--bg-color)';
                     e.target.style.color = 'inherit';
                }, 1000);
            } catch (err) {
                console.error('无法复制:', err);
            }
        });
    });
</script>

<?php require_once __DIR__ . '/partials/footer.php'; ?>