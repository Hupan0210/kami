<?php
// =================================================================
// 临时数据库更新脚本：添加邮件队列表 (请在运行后立即删除!)
// =================================================================
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
header('Content-Type: text/plain; charset=utf-8');

echo "🚀 开始更新数据库结构...\n";
echo "========================================\n\n";

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "✅ 数据库连接成功。\n";

    $sql = "
        -- 邮件发送队列表
        CREATE TABLE IF NOT EXISTS mail_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipient_email TEXT NOT NULL,
            subject TEXT NOT NULL,
            body TEXT NOT NULL,
            sender TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending', -- pending, sending, sent, failed
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            sent_at TEXT NULL,
            error_message TEXT NULL
        );
    ";
    
    $pdo->exec($sql);
    echo "✅ mail_queue 表创建成功（如果已存在则跳过）。\n\n";
    
    echo "🎉🎉🎉 数据库更新完成！ 🎉🎉🎉\n";
    echo "🛡️ 请立即从服务器上删除 `update_db_for_mail.php` 文件！\n";

} catch (PDOException $e) {
    echo "❌ 致命错误: 数据库操作失败: " . $e->getMessage() . "\n";
}
?>