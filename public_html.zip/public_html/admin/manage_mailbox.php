<?php
// =================================================================
// 邮箱管理中心 API - manage_mailbox.php (admin\manage_mailbox.php)

// =================================================================
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/auth.php'; 
require_once __DIR__ . '/../includes/DirectAdmin.class.php'; 

function sendJsonResponse(array $data, int $http_code = 200): void
{
    header('Content-Type: application/json');
    http_response_code($http_code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!isset($_SESSION['is_admin_logged_in']) || $_SESSION['is_admin_logged_in'] !== true) {
    sendJsonResponse(['success' => false, 'message' => 'Unauthorized access. (未登录)'], 401);
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $da = new DirectAdmin($pdo);

    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    $domain = $da->getTargetDomain();
    
    if (empty($domain)) {
        sendJsonResponse(['success' => false, 'message' => 'Target domain is not configured.'], 500);
    }
    
    // 🎯 升级 v1.1：预先获取 Webmail 登录地址
    $stmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'login_url'");
    $login_url = $stmt->fetchColumn() ?: '#';


    // -----------------------------------------------------------------
    // 4. 请求路由
    // -----------------------------------------------------------------
    switch ($action) {
        
        // ------------------
        // 4.1 列表请求 (GET) - 使用缓存
        // ------------------
        case 'list':
            $search = trim($_GET['search'] ?? '');
            $page = max(1, (int)($_GET['page'] ?? 1));
            $limit = max(10, min(100, (int)($_GET['limit'] ?? 20)));
            
            // 🎯 升级 v1.1：此方法现在会自动读取缓存
            $api_result = $da->getEmailsAndUsage($domain);

            if (!$api_result['success']) {
                sendJsonResponse(['success' => false, 'message' => $api_result['message']], 500);
            }
            
            $all_data = $api_result['data'];
            
            // 处理搜索过滤 (按邮箱前缀)
            if (!empty($search)) {
                $search = strtolower($search);
                $all_data = array_filter($all_data, function($item) use ($search) {
                    return strpos(strtolower($item['username']), $search) !== false;
                });
                $all_data = array_values($all_data); // 重置数组键
            }
            
            // 处理分页
            $total_items = count($all_data);
            $total_pages = $total_items > 0 ? (int)ceil($total_items / $limit) : 1;
            $start_index = ($page - 1) * $limit;
            
            $paginated_data = array_slice($all_data, $start_index, $limit);
            
            sendJsonResponse([
                'success' => true,
                'data' => $paginated_data,
                'pagination' => [
                    'total_items' => $total_items,
                    'total_pages' => $total_pages,
                    'current_page' => $page,
                    'per_page' => $limit
                ],
                // 🎯 升级 v1.1：返回登录地址
                'login_url' => $login_url
            ]);
        
        // ------------------
        // 4.2 🎯 升级 v1.1：刷新缓存请求 (POST)
        // ------------------
        case 'refresh_cache':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                sendJsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
            }
            
            // 步骤 1: 清除缓存
            $da->clearUsageCache();
            
            // 步骤 2: 重建缓存
            $api_result = $da->getEmailsAndUsage($domain);
            
            if (!$api_result['success']) {
                sendJsonResponse(['success' => false, 'message' => '缓存重建失败: ' . $api_result['message']], 500);
            }
            $all_data = $api_result['data'];

            // 步骤 3: 从 POST 获取参数（因为这是 POST 请求）
            $search = trim($_POST['search'] ?? '');
            $page = max(1, (int)($_POST['page'] ?? 1));
            $limit = max(10, min(100, (int)($_POST['limit'] ?? 20)));

            // 步骤 4: (同 'list') 处理搜索过滤
            if (!empty($search)) {
                $search = strtolower($search);
                $all_data = array_filter($all_data, function($item) use ($search) {
                    return strpos(strtolower($item['username']), $search) !== false;
                });
                $all_data = array_values($all_data); // 重置数组键
            }
            
            // 步骤 5: (同 'list') 处理分页
            $total_items = count($all_data);
            $total_pages = $total_items > 0 ? (int)ceil($total_items / $limit) : 1;
            $start_index = ($page - 1) * $limit;
            $paginated_data = array_slice($all_data, $start_index, $limit);

            // 步骤 6: 返回新数据
            sendJsonResponse([
                'success' => true,
                'data' => $paginated_data,
                'pagination' => [
                    'total_items' => $total_items,
                    'total_pages' => $total_pages,
                    'current_page' => $page,
                    'per_page' => $limit
                ],
                'login_url' => $login_url
            ]);

        // ------------------
        // 4.3 账户控制请求 (POST) - 仅保留删除
        // ------------------
        case 'delete':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                sendJsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
            }
            $username = trim($_POST['username'] ?? '');
            if (empty($username)) {
                sendJsonResponse(['success' => false, 'message' => 'Username is required.'], 400);
            }
            
            $users_to_act = [$username];
            $action_method = $action . 'Emails'; 
            
            $api_result = $da->$action_method($users_to_act, $domain);
            
            // 🎯 升级 v1.1：操作成功后清除缓存
            if ($api_result['success']) {
                $da->clearUsageCache();
            }
            
            sendJsonResponse($api_result);

        // ------------------
        // 4.4 强制改密请求 (POST)
        // ------------------
        case 'change_password':
             if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                sendJsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
            }
            $username = trim($_POST['username'] ?? '');
            $new_password = $_POST['new_password'] ?? '';
            
            if (empty($username) || empty($new_password)) {
                sendJsonResponse(['success' => false, 'message' => 'Username and new password are required.'], 400);
            }
            $api_result = $da->changeEmailPassword($username, $new_password, $domain);
            
            // 🎯 升级 v1.1：操作成功后清除缓存
            if ($api_result['success']) {
                $da->clearUsageCache();
            }
            
            sendJsonResponse($api_result);

        // ------------------
        // 4.5 默认/错误处理
        // ------------------
        default:
            sendJsonResponse(['success' => false, 'message' => 'Invalid or missing API action.'], 400);
    }
    
} catch (Exception $e) {
    sendJsonResponse(['success' => false, 'message' => 'Internal server error: ' . $e->getMessage()], 500);
}