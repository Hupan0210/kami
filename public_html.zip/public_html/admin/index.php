<?php
// 纯净版 index.php (后台登录 v4 - 增加“记住我”功能)
session_start();
// 引入位于上一级目录的 config.php
require_once __DIR__ . '/../config.php';

// --- 核心功能: 检查持久化登录状态 ---
function check_persistent_login(PDO $pdo): bool {
    // 检查是否存在记住我的 Cookie
    if (!isset($_COOKIE['admin_remember_me'])) {
        return false;
    }
    
    // Cookie 的值存储的是用户名
    $remembered_username = $_COOKIE['admin_remember_me'];

    // 从数据库获取用户的密码哈希进行二次验证（虽然这里只验证用户名，但这是最简单的持久化方案）
    // 实际项目中，通常会使用一个加密的、与数据库绑定的token，但出于项目简化，我们只使用用户名。
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'admin_username'");
    $stmt->execute();
    $admin_user_from_db = $stmt->fetchColumn();

    if ($remembered_username === $admin_user_from_db) {
        // 自动登录成功，重建 Session
        $_SESSION['is_admin_logged_in'] = true;
        session_regenerate_id(true);
        return true;
    }
    
    // Cookie 无效，清除它
    setcookie('admin_remember_me', '', time() - 3600, '/');
    return false;
}
// --- 核心功能结束 ---


// 如果已登录（通过 Session 或 Cookie），直接跳转到仪表盘
if (isset($_SESSION['is_admin_logged_in']) && $_SESSION['is_admin_logged_in'] === true) {
    header('Location: dashboard.php');
    exit;
}

$error_message = '';
// 检查表单是否已提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = new PDO('sqlite:' . DB_PATH);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // --- 尝试进行常规登录 ---
        $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key = 'admin_username' OR setting_key = 'admin_password_hash'");
        $stmt->execute();
        $creds = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        $admin_user_from_db = $creds['admin_username'] ?? '';
        $admin_pass_hash_from_db = $creds['admin_password_hash'] ?? '';

        $submitted_user = $_POST['username'] ?? '';
        $submitted_pass = $_POST['password'] ?? '';
        $remember_me = isset($_POST['remember_me']); // 检查“记住我”是否被勾选

        if (!empty($admin_user_from_db) && $submitted_user === $admin_user_from_db && password_verify($submitted_pass, $admin_pass_hash_from_db)) {
            // 登录成功
            $_SESSION['is_admin_logged_in'] = true;
            session_regenerate_id(true);

            // 🎯 核心逻辑：设置持久化登录 Cookie (30 天)
            if ($remember_me) {
                // 有效期 = 当前时间 + 30 天 (30 * 24 * 3600 秒)
                $expiry_time = time() + (30 * 24 * 3600);
                // 使用 HttpOnly 确保 Cookie 无法通过客户端脚本访问，增强安全性
                // Cookie 路径 '/' 确保在整个域下可用
                setcookie('admin_remember_me', $admin_user_from_db, $expiry_time, '/', '', false, true);
            } else {
                // 如果未勾选，清除旧的持久化 Cookie
                setcookie('admin_remember_me', '', time() - 3600, '/', '', false, true);
            }

            header('Location: dashboard.php');
            exit;
        } else {
            // 登录失败
            $error_message = '用户名或密码错误。';
        }
    } catch (PDOException $e) {
        // 如果数据库连接失败，显示通用错误
        $error_message = '系统错误：无法连接到配置数据库。';
    }
} else {
    // 首次访问或 GET 请求时，尝试通过 Cookie 自动登录
    try {
        $pdo = new PDO('sqlite:' . DB_PATH);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        if (check_persistent_login($pdo)) {
            header('Location: dashboard.php');
            exit;
        }
    } catch (PDOException $e) { /* 忽略，继续显示登录表单 */ }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理后台登录</title>
    <link rel="stylesheet" href="../assets/css/admin_style.css"> 
    <style>
        /* 针对登录页面的特定微调 */
        html, body { height: 100%; }
        body { display: flex; align-items: center; justify-content: center; padding: 1rem; }
        .login-card { max-width: 400px; width: 100%;}
        .form-group { margin-bottom: 1.25rem; }
        .form-group label { display:block; font-weight: 500; margin-bottom: 0.5rem; color: var(--secondary-text-color); }
        .form-group input { 
            width: 100%; 
            padding: 0.75rem; 
            border: 1px solid var(--border-color); 
            border-radius: 8px; 
            font-size: 1rem;
            box-sizing: border-box; /* 确保输入框在设置 padding 后宽度仍为 100% */
        }
        .error-message {
            color: #d93025; 
            background-color: #fce8e6; 
            padding: 0.75rem; 
            border-radius: 8px; 
            margin-bottom: 1.25rem;
            text-align: center;
        }
        .submit-btn {
            width: 100%; 
            padding: 0.8rem; 
            /* 沿用 admin_style.css 中的按钮样式 */
            background-color: var(--primary-blue); 
            color: white; 
            border: none; 
            border-radius: 8px; 
            font-size: 1rem; 
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        .submit-btn:hover { background-color: var(--primary-blue-hover, #0066cc); }
        
        /* 🎯 新增: 记住我 复选框样式 */
        .checkbox-group {
            display: flex;
            align-items: center;
            margin-top: -0.75rem; /* 抵消上面 form-group 的 margin-bottom */
            margin-bottom: 1.5rem;
        }
        .checkbox-group input {
            width: auto;
            margin-right: 0.5rem;
        }
        .checkbox-group label {
            margin: 0;
            font-weight: 400;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="card login-card">
        <div class="card-header" style="text-align: center;">
            <h2 class="card-title">🔐 管理后台登录</h2>
        </div>
        <form method="POST" action="index.php">
            <div class="form-group">
                <label for="username">用户名</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">密码</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="checkbox-group">
                <input type="checkbox" id="remember_me" name="remember_me" value="1">
                <label for="remember_me">保持登录 30 天</label>
            </div>
            <?php if ($error_message): ?>
                <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>
            <button type="submit" class="submit-btn">登录</button>
        </form>
    </div>
</body>
</html>