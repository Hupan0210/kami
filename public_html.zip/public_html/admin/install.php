<?php
// 纯净版 install.php (v1.1 - 增加 PWA 一键安装按钮)
require_once __DIR__ . '/../config.php';
$page_title = '📱 快捷方式安装';
require_once __DIR__ . '/partials/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">🚀 后台快捷方式安装指南</h2>
        <p class="card-subtitle">将此管理后台像原生应用一样固定到您的手机主屏幕。</p>
    </div>
    
    <div style="margin: 1.5rem 0; text-align: center;">
        <button id="install-button" class="btn btn-primary" style="display: none; width: 100%; max-width: 300px; font-size: 1.1rem; padding: 0.75rem 1.5rem;">
            一键安装到主屏幕 ✨
        </button>
        <p id="install-message" style="margin-top: 0.5rem; color: var(--text-color-secondary);">
            此功能仅在支持 PWA 的浏览器 (如 Chrome, Edge) 中可见。
        </p>
    </div>
    <div style="text-align: center; margin-bottom: 2rem;">
        <img src="../assets/img/app-icon-192.png" alt="App Icon" style="width: 96px; height: 96px; border-radius: 20%; box-shadow: 0 4px 12px rgba(0,0,0,0.1); margin-bottom: 1rem; border: 1px solid var(--border-color);">
        <p style="font-weight: 600;">应用名称: 学生邮箱管理中心</p>
    </div>

    <h3 style="margin-top: 0;">🛠️ 关键步骤：在 iOS/Safari 上</h3>
    <ol style="padding-left: 20px;">
        <li>在 Safari 浏览器中，访问此管理后台的登录页面。</li>
        <li>点击底部的 **共享** (或**分享**) 图标 (<code style="font-size: 1.1em;">⬆️</code>)。</li>
        <li>在弹出的菜单中，选择 **“添加到主屏幕”**。</li>
        <li>确认名称后，点击 **“添加”** 即可完成。</li>
    </ol>

    <h3 style="margin-top: 2rem;">🤖 关键步骤：在 Android/Chrome 上</h3>
    <ol style="padding-left: 20px;">
        <li>在 Chrome 浏览器中，访问此管理后台的登录页面。</li>
        <li>点击右上角的 **菜单** 图标 (<code style="font-size: 1.1em;">⋮</code>)。</li>
        <li>选择 **“安装应用”** 或 **“添加到主屏幕”**。</li>
        <li>点击 **“添加”** 即可完成。</li>
    </ol>

    <div class="alert alert-danger" style="margin-top: 2rem;">
        <p style="font-weight: 600; color: var(--error-color);">⚠️ 图标文件缺失警告:</p>
        <p>为了让快捷方式显示专业的图标，请确保以下图片文件已存在于您的服务器上：</p>
        <ul style="padding-left: 20px; list-style-type: none;">
            <li>📁 <code>/public_html/assets/img/app-icon-192.png</code> (192x192 像素)</li>
            <li>📁 <code>/public_html/assets/img/app-icon-512.png</code> (512x512 像素)</li>
        </ul>
        <p>如果文件缺失，系统将使用默认图标。</p>
    </div>
</div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>