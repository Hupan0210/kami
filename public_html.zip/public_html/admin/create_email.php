<?php
// 纯净版 create_email.php (v2.0 - 强制默认密码与成功复制模板)
require_once __DIR__ . '/../config.php';
$page_title = '➕ 手动创建邮箱';
require_once __DIR__ . '/partials/header.php';
require_once __DIR__ . '/../includes/DirectAdmin.class.php';

$message = '';
$message_type = '';
$target_domain = '';
$creation_success_data = null; // 用于存储成功创建后的信息

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $da = new DirectAdmin($pdo);
    
    // 🎯 核心修正：一次性获取所有配置信息
    $settingsStmt = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('target_domain', 'default_email_password', 'login_url', 'server_config')");
    $settings = $settingsStmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    $target_domain = $settings['target_domain'] ?? 'domain.com';
    $default_password = $settings['default_email_password'] ?? 'Abc123'; // 默认密码来自数据库

    // 表单提交处理
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_email') {
        
        $username = trim($_POST['username'] ?? '');
        $quota = (int)($_POST['quota'] ?? 0);
        $limit = (int)($_POST['limit'] ?? 0);
        // 🎯 修正：强制使用系统默认密码，忽略用户输入的密码
        $password = $default_password; 

        if (empty($username)) {
            $message = '用户名不能为空。';
            $message_type = 'error';
        } elseif (!preg_match('/^[a-z0-9._\-]{3,20}$/', $username)) {
            $message = '邮箱前缀格式错误 (3-20位, 仅限小写字母/数字/._-)。';
            $message_type = 'error';
        } else {
            // 检查 DA 是否已存在
            if ($da->emailExists($username, $target_domain)) {
                 $message = "❌ 邮箱前缀 '{$username}' 已被占用。";
                 $message_type = 'error';
            } else {
                 // 尝试创建邮箱
                 $result = $da->createEmail($username, $target_domain, $password, $quota, $limit);

                 if ($result['success']) {
                    $full_email = "{$username}@{$target_domain}";
                    
                    // 🎯 存储成功信息，用于显示复制模板
                    $creation_success_data = [
                        'email' => $full_email,
                        'password' => $password,
                        'login_url' => $settings['login_url'] ?? '#',
                        'server_config' => $settings['server_config'] ?? 'N/A'
                    ];

                    $message = "✅ 邮箱创建成功: {$full_email}。";
                    $message_type = 'success';
                 } else {
                    $message = '❌ 邮箱服务器创建失败: ' . ($result['message'] ?? '未知错误');
                    $message_type = 'error';
                 }
            }
        }
    }

} catch (Exception $e) {
    $message = '数据库或 DirectAdmin 初始化失败: ' . $e->getMessage();
    $message_type = 'error';
}
?>

<?php if ($message): ?>
    <div class="alert <?php echo $message_type === 'success' ? 'badge-success' : 'alert-danger'; ?>" style="color: white; margin-bottom: 1.5rem;"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<?php if ($creation_success_data): ?>
    <div class="card" id="success-copy-card">
        <div class="card-header"><h2 class="card-title">🎉 邮箱创建成功！</h2></div>
        
        <p>请将以下信息复制并发送给用户：</p>
        
        <div style="background-color: var(--bg-color); padding: 1rem; border-radius: 8px; margin-bottom: 1rem; font-size: 0.95rem;">
            <p><strong>邮箱账号:</strong> <code id="created-email"><?php echo htmlspecialchars($creation_success_data['email']); ?></code></p>
            <p><strong>初始密码:</strong> <code id="created-password" style="color: var(--error-color); font-weight: bold;"><?php echo htmlspecialchars($creation_success_data['password']); ?></code></p>
            <p><strong>登录地址:</strong> <a href="<?php echo htmlspecialchars($creation_success_data['login_url']); ?>" target="_blank"><?php echo htmlspecialchars($creation_success_data['login_url']); ?></a></p>
            <p><strong>服务器配置:</strong> <span><?php echo htmlspecialchars($creation_success_data['server_config']); ?></span></p>
            <p style="color: var(--warning-color); font-weight: 500;">⚠️ 请牢记并提醒用户及时修改密码！</p>
        </div>
        
        <button type="button" class="btn-primary" id="copy-info-btn" style="width: 100%;">
            📋 一键复制完整信息
        </button>
    </div>
<?php endif; ?>

<div class="card" id="creation-form-card">
    <div class="card-header"><h2 class="card-title">📝 创建新的邮箱账户</h2></div>
    
    <form method="POST" action="create_email.php">
        <input type="hidden" name="action" value="create_email">
        
        <div class="grid-form" style="grid-template-columns: 1fr; gap: 1rem;">

            <div class="input-group addon">
                <input type="text" id="username" name="username" placeholder="邮箱前缀 (例如：testuser)" required pattern="[a-z0-9._\-]{3,20}">
                <div class="input-addon">@<?php echo htmlspecialchars($target_domain); ?></div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-top: 1rem;">
                <div class="form-group">
                    <label for="quota">邮箱配额 (MB)</label>
                    <select id="quota" name="quota" class="form-select">
                        <option value="50">50 MB</option>
                        <option value="100">100 MB</option>
                        <option value="250">250 MB</option>
                        <option value="0">无限制 (Unlimited)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="limit">每日发送限制 (封)</label>
                    <select id="limit" name="limit" class="form-select">
                        <option value="100">100 封</option>
                        <option value="200">200 封</option>
                        <option value="500">500 封</option>
                        <option value="0">无限制 (Unlimited)</option>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn-primary" style="margin-top: 1rem;">
                ➕ 创建邮箱 (默认密码: <?php echo htmlspecialchars($default_password); ?>)
            </button>
        </div>
    </form>
</div>

<style>
/* 确保 select 样式与 input 一致 */
.form-select { 
    width: 100%; 
    padding: 0.75rem; 
    border: 1px solid var(--border-color); 
    border-radius: 8px; 
    font-size: 1rem; 
    box-sizing: border-box; 
    background-color: var(--card-bg-color);
}

.input-group.addon {
    display: flex;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    overflow: hidden;
}

.input-group.addon input {
    border: none;
    flex-grow: 1;
    padding: 0.75rem;
    font-size: 1rem;
}

.input-group.addon .input-addon {
    padding: 0 12px;
    background-color: var(--bg-color);
    border-left: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    color: var(--secondary-text-color);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const copyBtn = document.getElementById('copy-info-btn');
    const successCard = document.getElementById('success-copy-card');

    if (copyBtn && successCard) {
        copyBtn.addEventListener('click', async function() {
            const email = document.getElementById('created-email').textContent;
            const password = document.getElementById('created-password').textContent;
            const loginUrl = successCard.querySelector('a').href;
            const serverConfig = successCard.querySelector('span').textContent;

            // 构建复制的文本内容
            const textToCopy = 
                `您好！您的邮箱已成功创建！\n` + 
                `登录地址：${loginUrl}\n` + 
                `邮箱账号：${email}\n` + 
                `初始密码：${password}\n` + 
                `服务器配置：${serverConfig}\n` +
                `请及时修改密码！`;

            try {
                await navigator.clipboard.writeText(textToCopy);
                this.textContent = '✅ 已复制！';
                this.style.backgroundColor = 'var(--success-color)';
            } catch (err) {
                alert('复制失败，请手动复制。');
                this.textContent = '❌ 复制失败';
                this.style.backgroundColor = 'var(--error-color)';
            }
            
            setTimeout(() => {
                this.textContent = '📋 一键复制完整信息';
                this.style.backgroundColor = 'var(--primary-blue)';
            }, 3000);
        });
        
        // 成功后滚动到顶部，确保看到复制卡片
        successCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
});
</script>

<?php require_once __DIR__ . '/partials/footer.php'; ?>