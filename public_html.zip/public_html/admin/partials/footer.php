<?php
// 纯净版 footer.php (v6 - 结构与样式优化版)
// 文件路径: /public_html/admin/partials/footer.php
?>
        </div> <footer class="footer">
            <p>
                需要帮助？联系我们: 
                <a href="mailto:hupan0210@gmail.com">hupan0210@gmail.com</a>
            </p>
            <p>
                <a href="https://112583.xyz/" target="_blank" rel="noopener noreferrer">支持一下</a>
                |
                <a href="https://090110.xyz/" target="_blank" rel="noopener noreferrer">再支持一下</a>
            </p>
        </footer>

    </main> </div> </body>
</html>