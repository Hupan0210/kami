<?php
// 文件路径: /public_html/admin/partials/header.php
// 版本: v12 (PWA Meta + 结构优化)

// 关键安全步骤: 首先引入“安全门卫”，确保未登录用户无法访问
require_once __DIR__ . '/../auth.php'; 
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title><?php echo htmlspecialchars($page_title ?? '管理中心'); ?></title>
    
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="application-name" content="学生邮箱管理中心">
    <meta name="apple-mobile-web-app-title" content="邮箱管理">
    <meta name="theme-color" content="#007aff">
    
    <link rel="apple-touch-icon" href="../../assets/img/app-icon-192.png">
    <link rel="icon" type="image/png" sizes="192x192" href="../../assets/img/app-icon-192.png">
    <link rel="icon" type="image/png" sizes="512x512" href="../../assets/img/app-icon-512.png">
    <link rel="manifest" href="./manifest.json">

    <link rel="stylesheet" href="../../assets/css/admin_style.css">
    
    <script defer src="../../assets/js/admin_app.js"></script>
</head>
<body>
<div class="admin-wrapper">

    <header class="header">
        <div class="header-content">
            <button id="sidebar-toggle" class="sidebar-toggle-btn" aria-label="Toggle Navigation">
                <span class="icon">☰</span>
            </button>
            <h1 class="header-title"><?php echo htmlspecialchars($page_title ?? '管理中心'); ?></h1>
        </div>
    </header>
    
    <?php 
    // 引入侧边栏导航模块 (从 v10 整合)
    require_once __DIR__ . '/sidebar.php'; 
    ?>

    <main class="main-content">
        <div class="main-container">