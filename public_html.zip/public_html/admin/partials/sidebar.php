<?php
//  sidebar.php (public_html/admin/partials)

// 获取当前正在执行的 PHP 脚本的文件名，例如 "dashboard.php"
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar">
    <nav class="sidebar-nav">
        <ul>
            <li>
                <a href="dashboard.php" class="<?php echo ($current_page === 'dashboard.php') ? 'active' : ''; ?>">
                    📊 数据查看仪表
                </a>
            </li>
            
            <li>
                <a href="keys.php" class="<?php echo ($current_page === 'keys.php') ? 'active' : ''; ?>">
                    🔑 卡密管理中心
                </a>
            </li>
            
            <li>
                <a href="mailboxes.php" class="<?php echo ($current_page === 'mailboxes.php') ? 'active' : ''; ?>">
                    📧 邮箱管理中心
                </a>
            </li>

            <li>
                <a href="create_email.php" class="<?php echo ($current_page === 'create_email.php') ? 'active' : ''; ?>">
                    ➕ 手动创建邮箱
                </a>
            </li>

            <li>
                <a href="send_mail.php" class="<?php echo ($current_page === 'send_mail.php') ? 'active' : ''; ?>">
                    ✉️ 群发邮件管理
                </a>
            </li>
            <li>
                <a href="install.php" class="<?php echo ($current_page === 'install.php') ? 'active' : ''; ?>">
                    📱 快捷方式安装
                </a>
            </li>
            <li>
                <a href="settings.php" class="<?php echo ($current_page === 'settings.php') ? 'active' : ''; ?>">
                    ⚙️ 核心站点设置
                </a>
            </li>
            <li>
                <a href="dictionary.php" class="<?php echo ($current_page === 'dictionary.php') ? 'active' : ''; ?>">
                    📖 数据库编辑器
                </a>
            </li>
            <li>
                <a href="cron_manager.php" class="<?php echo ($current_page === 'cron_manager.php') ? 'active' : ''; ?>">
                    🤖 自动控制面板
                </a>
            </li>
            <li>
                <a href="documentation.php" class="<?php echo ($current_page === 'documentation.php') ? 'active' : ''; ?>">
                    📚 项目使用文档
                </a>
            </li>
            <li>
                <a href="logout.php">
                    🚪 退出登录状态
                </a>
            </li>
        </ul>
    </nav>
</aside>