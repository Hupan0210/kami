<?php
// =================================================================
// 终极错误显示脚本 (v1.0)
// =================================================================

// 关键步骤 1: 强制开启所有错误显示，这是我们的“透视镜”
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// 关键步骤 2: 模拟一个已登录的环境，这样 auth.php 就不会重定向我们
session_start();
$_SESSION['is_admin_logged_in'] = true;

// 关键步骤 3: 使用 try...catch 块来捕获任何类型的致命错误 (包括ParseError)
try {
    // 我们现在尝试像一个正常的页面一样，去加载 dashboard.php
    // 如果 dashboard.php 或其包含的任何文件有任何问题，都会在这里被捕获
    require_once __DIR__ . '/dashboard.php';

} catch (Throwable $e) {
    // 如果捕获到错误，以最清晰的方式打印出来
    header('Content-Type: text/plain; charset=utf-8');
    echo "❌❌❌ 捕获到致命错误！ ❌❌❌\n";
    echo "========================================\n";
    echo "错误类型: " . get_class($e) . "\n";
    echo "错误信息: " . $e->getMessage() . "\n";
    echo "错误文件: " . $e->getFile() . "\n";
    echo "错误行号: " . $e->getLine() . "\n";
    echo "========================================\n";
    // 停止执行
    exit;
}

// 如果代码能执行到这里，说明 dashboard.php 本身没有致命错误
echo "✅ 诊断脚本成功加载并执行了 dashboard.php，没有捕获到致命错误。";