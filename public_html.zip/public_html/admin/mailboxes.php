<?php
// =================================================================
// 邮箱账户管理中心 - mailboxes.php (V3.1 - 优化初始加载提示)
// =================================================================
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
$page_title = '📧 邮箱管理中心';
require_once __DIR__ . '/partials/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">📧 邮箱账户管理</h2>
        <p class="card-subtitle">管理、监控和控制通过 DirectAdmin 建立的所有邮箱账户。</p>
    </div>

    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; gap: 1rem;">
        <div style="flex-grow: 1;">
            <input type="text" id="search-input" placeholder="按邮箱前缀搜索 (例如：user1)">
        </div>
        <button id="search-button" class="btn-primary" style="padding: 0.75rem 1.5rem;">
            🔍 搜索
        </button>
        <button id="refresh-button" class="btn-success" style="padding: 0.75rem 1.5rem;">
            🔄 刷新列表
        </button>
    </div>

    <div id="message-container" style="margin-bottom: 1rem;"></div>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>邮箱账户</th>
                    <th>状态</th> 
                    <th>操作</th>
                </tr>
            </thead>
            <tbody id="mailbox-list">
                <tr><td colspan="3" style="text-align: center;">加载中...</td></tr>
            </tbody>
        </table>
    </div>
    
    <div id="pagination-controls" class="pagination" style="margin-top: 1.5rem; justify-content: center;">
        </div>
</div>

<div id="password-modal" style="display:none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 10% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 400px; border-radius: 8px;">
        <h3 style="margin-top: 0;">重置密码: <span id="modal-email"></span></h3>
        <div class="form-group">
            <label for="new-password-input">新密码</label>
            <input type="text" id="new-password-input" placeholder="请输入新密码">
        </div>
        <div style="display: flex; justify-content: flex-end; gap: 10px;">
            <button id="modal-cancel" class="btn-secondary">取消</button>
            <button id="modal-confirm" class="btn-primary">确认修改</button>
        </div>
    </div>
</div>

<script src="../../assets/js/mailboxes.js"></script>

<style>
/* 局部样式保留：确保输入框和按钮使用全局样式 */
#search-input { width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 8px; box-sizing: border-box; }
.form-group input { width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 8px; box-sizing: border-box; }
.action-btn { margin: 2px 0; } /* 保留用于微调按钮间距 */
</style>

<?php require_once __DIR__ . '/partials/footer.php'; ?>