<?php
// 纯净版 dashboard.php (v3.1 - 清理版)
require_once __DIR__ . '/../config.php';

// --- “自分布式” API 逻辑 (保持不变) ---
if (isset($_GET['json']) && $_GET['json'] === 'true') {
    header('Content-Type: application/json');
    try {
        $pdo = new PDO('sqlite:' . DB_PATH);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        // 1. 获取所有状态的计数
        $stats = ['pristine' => 0, 'distributed' => 0, 'redeemed' => 0];
        $count_stmt = $pdo->query("SELECT status, COUNT(*) as count FROM keys GROUP BY status");
        while ($row = $count_stmt->fetch(PDO::FETCH_ASSOC)) {
            if (array_key_exists($row['status'], $stats)) {
                $stats[$row['status']] = (int)$row['count'];
            }
        }

        // 2. 查询今日兑换量
        $today_start = date('Y-m-d H:i:s', strtotime('today midnight'));
        $today_stmt = $pdo->prepare("SELECT COUNT(*) FROM keys WHERE status = 'redeemed' AND used_at >= ?");
        $today_stmt->execute([$today_start]);
        $stats['redeemed_today'] = (int)$today_stmt->fetchColumn();

        // 3. 获取系统核心信息
        $system_info_stmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'target_domain'");
        $system_info['target_domain'] = $system_info_stmt->fetchColumn();

        echo json_encode(['success' => true, 'stats' => $stats, 'system' => $system_info]);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// --- 正常的页面加载逻辑 ---
$page_title = '仪表盘';
require_once __DIR__ . '/partials/header.php';

// 页面首次加载时，获取一次初始数据 (用于占位和 SEO)
$initial_stats = ['pristine' => '...', 'distributed' => '...', 'redeemed' => '...', 'redeemed_today' => '...'];
$initial_system_info = ['target_domain' => '...'];
try {
    $pdo_init = new PDO('sqlite:' . DB_PATH);
    $pdo_init->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $count_stmt_init = $pdo_init->query("SELECT status, COUNT(*) as count FROM keys GROUP BY status");
    while ($row = $count_stmt_init->fetch(PDO::FETCH_ASSOC)) {
        if (array_key_exists($row['status'], $initial_stats)) $initial_stats[$row['status']] = $row['count'];
    }
    $today_start_init = date('Y-m-d H:i:s', strtotime('today midnight'));
    $today_stmt_init = $pdo_init->prepare("SELECT COUNT(*) FROM keys WHERE status = 'redeemed' AND used_at >= ?");
    $today_stmt_init->execute([$today_start_init]);
    $initial_stats['redeemed_today'] = $today_stmt_init->fetchColumn();
    $initial_system_info['target_domain'] = $pdo_init->query("SELECT setting_value FROM settings WHERE setting_key = 'target_domain'")->fetchColumn();
} catch (PDOException $e) { /* 保持 '...' 占位符 */ }
?>
<div class="card">
    <div class="card-header">
        <h2 class="card-title">🚀 欢迎回来！</h2>
        <p class="card-subtitle">
            系统状态实时概览 (每 5 秒自动刷新) | 当前服务域名: 
            <code id="system-target-domain"><?php echo htmlspecialchars($initial_system_info['target_domain']); ?></code>
        </p>
    </div>
    <div class="grid-form">
        
        <div class="stat-card">
            <h3 id="stat-redeemed-today" class="stat-number" style="color: var(--primary-blue);"><?php echo htmlspecialchars((string)$initial_stats['redeemed_today']); ?></h3>
            <p class="stat-label">📈 今日兑换</p>
        </div>
        
        <div class="stat-card">
            <h3 id="stat-pristine" class="stat-number" style="color: var(--success-color);"><?php echo htmlspecialchars((string)$initial_stats['pristine']); ?></h3>
            <p class="stat-label">📦 未使用库存</p>
        </div>
        
        <div class="stat-card">
            <h3 id="stat-distributed" class="stat-number" style="color: var(--distributed-color);"><?php echo htmlspecialchars((string)$initial_stats['distributed']); ?></h3>
            <p class="stat-label">🚚 已分发 (在途)</p>
        </div>
        
        <div class="stat-card">
            <h3 id="stat-redeemed" class="stat-number" style="color: var(--warning-color);"><?php echo htmlspecialchars((string)$initial_stats['redeemed']); ?></h3>
            <p class="stat-label">🗄️ 已兑换 (总计)</p>
        </div>
      
    </div>
</div>

<script src="../../assets/js/dashboard.js"></script>

<?php require_once __DIR__ . '/partials/footer.php'; ?>