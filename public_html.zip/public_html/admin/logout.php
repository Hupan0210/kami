<?php
// 纯净版 logout.php (v4 - 增加清除“记住我”Cookie)
session_start();

// 步骤 1: 清空所有 session 变量
$_SESSION = [];

// 步骤 2: 删除 Session ID 的 Cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 步骤 3: 🎯 新增: 清除持久化登录 Cookie
if (isset($_COOKIE['admin_remember_me'])) {
    // 设置过期时间到过去，强制浏览器删除 Cookie
    setcookie('admin_remember_me', '', time() - 3600, '/', '', false, true);
}

// 步骤 4: 彻底销毁 session
session_destroy();

// 步骤 5: 重定向到登录页面
header('Location: index.php');
exit;