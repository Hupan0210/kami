<?php
// admin\reset_admin_pass.php
declare(strict_types=1);

// 引入核心配置文件以获取数据库路径
require_once __DIR__ . '/../config.php';

// --- 定义高强度的新密码 ---
$new_password = 'AdminPassReset123!';

// 初始化结果变量
$success = false;
$message = '🚀 正在尝试重置管理员密码...';
$error = null;

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 步骤 1: 将新密码进行安全的哈希处理
    $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);

    // 步骤 2: 将新的密码哈希更新到数据库的 settings 表中
    $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = 'admin_password_hash'");
    $success = $stmt->execute([$new_password_hash]);

    if ($success) {
        $message = '🎉 密码重置成功！';
    } else {
        $error = '❌ 数据库更新失败！请检查数据库是否已创建。';
        $message = '重置失败';
    }

} catch (PDOException $e) {
    $error = '❌ 致命错误: ' . $e->getMessage();
    $message = '重置失败';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员密码重置</title>
    <style>
        /* Apple 风格 CSS */
        :root {
            --primary-blue: #007aff;
            --success-green: #34c759;
            --error-red: #ff3b30;
            --background-color: #f2f2f7;
            --card-background: #ffffff;
            --text-color: #1c1c1e;
            --secondary-text-color: #6a6a6a;
            --shadow-color: rgba(0, 0, 0, 0.08);
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: var(--background-color);
            color: var(--text-color);
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        .card {
            background-color: var(--card-background);
            padding: 2rem;
            border-radius: 12px; /* iOS-like large radius */
            box-shadow: 0 4px 16px var(--shadow-color);
            text-align: left;
            margin-bottom: 2rem;
        }
        .card h1 {
            color: var(--primary-blue);
            font-size: 1.5rem;
            font-weight: 600;
            margin-top: 0;
            display: flex;
            align-items: center;
        }
        .card h1 svg {
            margin-right: 10px;
        }
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-top: 1.5rem;
            font-weight: 500;
        }
        .alert.success {
            background-color: rgba(52, 199, 89, 0.1);
            color: var(--success-green);
        }
        .alert.error {
            background-color: rgba(255, 59, 48, 0.1);
            color: var(--error-red);
        }
        .password-box {
            background-color: var(--background-color);
            border-radius: 8px;
            padding: 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: 1rem 0;
            font-size: 1.1rem;
            font-weight: bold;
            overflow-x: auto;
        }
        #new-password {
            color: var(--error-red); /* 突出新密码 */
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background-color: var(--primary-blue);
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s, box-shadow 0.2s;
            text-decoration: none;
            box-shadow: 0 2px 4px var(--shadow-color);
            margin-top: 1rem;
            min-width: 150px;
        }
        .btn:hover {
            background-color: #0063ce;
        }
        .btn.copy-btn {
            background-color: var(--success-green);
            min-width: unset;
            padding: 8px 15px;
            margin-left: 10px;
        }
        .btn.copy-btn:hover {
            background-color: #2b9a4c;
        }
        .security-note {
            font-size: 0.9rem;
            color: var(--secondary-text-color);
            margin-top: 2rem;
            border-top: 1px solid #e0e0e0;
            padding-top: 1rem;
        }

        /* 移动端优化 */
        @media (max-width: 600px) {
            body { padding: 10px; }
            .card { padding: 1.5rem; }
            .card h1 { font-size: 1.3rem; }
            .password-box { flex-direction: column; align-items: flex-start; }
            .btn.copy-btn { margin-left: 0; margin-top: 10px; width: 100%; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>
                <?php if ($success): ?>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--success-green)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                <?php else: ?>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--error-red)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                <?php endif; ?>
                <?= htmlspecialchars($message) ?>
            </h1>

            <?php if ($error): ?>
                <div class="alert error"><?= htmlspecialchars($error) ?></div>
            <?php else: ?>
                <div class="alert success">
                    请使用以下一次性密码登录。登录后立即在设置中修改！
                </div>

                <p><strong>管理员用户名：</strong> <code>admin</code> (或您安装时设置的用户名)</p>
                <p><strong>一次性新密码：</strong></p>
                
                <div class="password-box">
                    <span id="new-password"><?= htmlspecialchars($new_password) ?></span>
                    <button class="btn copy-btn" id="copy-button">
                        <span id="copy-text">复制密码</span>
                    </button>
                </div>
                
                <a href="./" class="btn">前往后台登录页面</a>
                
                <div class="security-note">
                    <p>🛡️ **安全提示:** 成功登录后，请立即从服务器上彻底删除 <code>reset_admin_pass.php</code> 这个文件，以避免密码被恶意重置！</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.getElementById('copy-button').addEventListener('click', function() {
            const passwordText = document.getElementById('new-password').textContent;
            const copyTextSpan = document.getElementById('copy-text');
            
            // 使用 Clipboard API 复制文本
            navigator.clipboard.writeText(passwordText).then(() => {
                // 成功反馈
                const originalText = copyTextSpan.textContent;
                copyTextSpan.textContent = '✅ 已复制!';
                
                // 2秒后恢复原文本
                setTimeout(() => {
                    copyTextSpan.textContent = originalText;
                }, 2000);
            }).catch(err => {
                // 失败反馈
                console.error('无法复制文本: ', err);
                copyTextSpan.textContent = '❌ 复制失败';
            });
        });
    </script>
</body>
</html>