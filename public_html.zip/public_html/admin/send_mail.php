<?php
// send_mail.php (admin\send_mail.php)
// v1.2 更新：
// - 移除了所有前端 JS 进度条、日志和发送逻辑
// - UI 简化为“即发即忘”模式，依赖 Cron Job 在后台处理
require_once __DIR__ . '/../config.php';
$page_title = '✍️ 发送自定义邮件';
require_once __DIR__ . '/partials/header.php';

// 引入 DirectAdmin 类获取发件人列表
require_once __DIR__ . '/../includes/DirectAdmin.class.php';

$message = '';
$message_type = '';
$email_accounts = [];

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 实例化 DA
    $da = new DirectAdmin($pdo);
    $domain = $da->getTargetDomain();

    // 🎯 优化：使用新的轻量级方法 getEmailsList()
    $api_result = $da->getEmailsList($domain);
    if ($api_result['success']) {
        $email_accounts = $api_result['data'];
    }
    
    // 确保 DA 用户邮箱可以作为发件人
    $stmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key IN ('da_username')");
    $da_username = $stmt->fetchColumn();
    
    $da_full_email = $da_username . '@' . $domain;
    if (!in_array($da_full_email, $email_accounts) && !empty($da_username) && !empty($domain)) {
        array_unshift($email_accounts, $da_full_email);
    }
    
    if (empty($email_accounts) && !empty($da_username) && !empty($domain)) {
        $email_accounts[] = $da_full_email;
    }

} catch (Exception $e) {
    $message = '数据库或 DirectAdmin 初始化失败: ' . $e->getMessage();
    $message_type = 'error';
}

// 🎯 升级 v1.2：处理来自 create_mail_queue.php 的提交反馈
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message']['text'];
    $message_type = $_SESSION['flash_message']['type'];
    unset($_SESSION['flash_message']);
}
?>

<?php if ($message): ?>
    <div class="alert <?php echo $message_type === 'success' ? 'badge-success' : 'alert-danger'; ?>" style="color: white; margin-bottom: 1.5rem;"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">✍️ 发送自定义邮件</h2>
        <p class="card-subtitle">创建邮件任务队列。系统将采用 Cron Job (定时任务) 异步发送，无需保持页面打开。</p>
    </div>

    <form id="mail-queue-form" method="POST" action="api/create_mail_queue.php">
        <div class="form-group">
            <label for="sender">发件人</label>
            <select id="sender" name="sender" class="form-select" required>
                <?php if (empty($email_accounts)): ?>
                    <option value="">请先配置或创建邮箱账户</option>
                <?php else: ?>
                    <?php foreach ($email_accounts as $email): ?>
                        <option value="<?php echo htmlspecialchars($email); ?>"><?php echo htmlspecialchars($email); ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
            <small class="form-text">
                注意：如果使用 SMTP，此发件人必须是 SMTP 认证账户有权发送的地址。
            </small>
        </div>
        
        <div class="form-group">
            <label>收件人</label>
            <div style="display: flex; gap: 1.5rem; margin-top: 0.5rem;">
                <label><input type="radio" name="recipient_type" value="all" checked> 👨‍🎓 所有已兑换邮箱</label>
                <label><input type="radio" name="recipient_type" value="specific"> 👤 指定邮箱</label>
            </div>
        </div>
        
        <div class="form-group" id="specific-recipients-group" style="display: none;">
            <label for="specific_recipients">指定邮箱地址 (每行一个，或用逗号分隔)</label>
            <textarea id="specific_recipients" name="specific_recipients" rows="4" placeholder="例如：user1@domain.com, user2@domain.com"></textarea>
            <small class="form-text">仅在选择“指定邮箱”时生效。</small>
        </div>

        <div class="form-group">
            <label for="subject">邮件主题</label>
            <input type="text" id="subject" name="subject" required>
        </div>

        <div class="form-group">
            <label for="body">邮件内容 (支持 HTML)</label>
            <textarea id="body" name="body" rows="10" placeholder="支持输入纯文本或 HTML 代码来设计邮件格式。" required></textarea>
            <small class="form-text">您可以输入 HTML 代码来设计邮件格式。</small>
        </div>
        
        <button type="submit" class="btn-primary">
            📨 创建邮件队列
        </button>
    </form>
</div>

<style>
/* 页面专属样式 */
.form-select { width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 8px; font-size: 1rem; box-sizing: border-box; }
.form-text { color: var(--secondary-text-color); font-size: 0.85rem; margin-top: 0.25rem; display: block; }
#specific-recipients-group textarea { resize: vertical; }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const specificRecipientsGroup = document.getElementById('specific-recipients-group');
    const recipientTypeRadios = document.getElementsByName('recipient_type');

    // 切换收件人类型
    recipientTypeRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            specificRecipientsGroup.style.display = radio.value === 'specific' ? 'block' : 'none';
        });
    });
});
</script>

<?php require_once __DIR__ . '/partials/footer.php'; ?>