<?php
// 纯净版 debug_da_api.php (v1.0 - 终极诊断探针)
declare(strict_types=1);

// 强制显示所有错误
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

// 引入核心文件
require_once __DIR__ . '/../config.php';
// 关键安全步骤: 确保只有登录的管理员才能运行此脚本
require_once __DIR__ . '/auth.php';

header('Content-Type: text/plain; charset=utf-8');

echo "🚀 DirectAdmin API 终极诊断探针\n";
echo "========================================\n\n";

try {
    echo "1. 正在连接数据库...\n";
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "   ✅ 数据库连接成功。\n\n";

    echo "2. 正在从数据库获取当前保存的 DA 凭据...\n";
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key LIKE 'da_%'");
    $stmt->execute();
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    $host = $settings['da_host'] ?? null;
    $port = $settings['da_port'] ?? null;
    $username = $settings['da_username'] ?? null;
    $password = $settings['da_password'] ?? null;

    if (!$host || !$port || !$username || !$password) {
        die("   ❌ 致命错误: 未能从数据库完整获取 DA 凭据！请检查站点设置页面是否已保存。\n");
    }
    echo "   ✅ 凭据获取成功。\n\n";
    
    echo "3. 准备执行 cURL API 请求...\n";
    $params = http_build_query(['json' => 'yes', 'action' => 'exists', 'domain' => 'anydomain.com', 'user' => 'api-test-' . time()]);
    $url = "https://{$host}:{$port}/CMD_API_POP?{$params}";
    echo "   请求 URL: " . $url . "\n\n";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_USERPWD, "{$username}:{$password}");
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

    $response_body = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    echo "4. cURL 请求执行完毕。\n";
    echo "----------------------------------------\n";
    if ($curl_error) {
        echo "   ❌ cURL 自身发生错误: " . $curl_error . "\n";
    } else {
        echo "   ✅ cURL 成功连接并收到服务器响应。\n\n";
        echo "🔍 服务器返回的【原始数据】如下:\n";
        var_dump($response_body);
        echo "\n";
        
        echo "🔍 将原始数据进行 JSON 解码后的【数组结构】如下:\n";
        $decoded_data = json_decode($response_body, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            print_r($decoded_data);
        } else {
            echo "   无法将响应解码为 JSON！这通常意味着认证失败，服务器返回了 HTML 登录页面。\n";
        }
    }
    echo "----------------------------------------\n";

} catch (Exception $e) {
    echo "❌ 在诊断过程中捕获到 PHP 致命错误: " . $e->getMessage() . "\n";
}

echo "\n\n🛡️ 诊断完成。请将以上【全部】输出内容发给我进行分析。\n";