<?php
// 纯净版 auth.php (v4 - 增加持久化登录检查)
session_start();

// 1. 检查 Session 中是否存在登录标志并且为 true
if (isset($_SESSION['is_admin_logged_in']) && $_SESSION['is_admin_logged_in'] === true) {
    // Session 活跃，允许访问
    return; 
}

// 2. 🎯 Session 已过期或丢失，尝试通过持久化 Cookie 自动登录
if (isset($_COOKIE['admin_remember_me'])) {
    // 引入配置和数据库连接（如果需要）
    require_once __DIR__ . '/../config.php';

    try {
        $pdo = new PDO('sqlite:' . DB_PATH);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $remembered_username = $_COOKIE['admin_remember_me'];

        // 从数据库获取用户名进行验证
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'admin_username'");
        $stmt->execute();
        $admin_user_from_db = $stmt->fetchColumn();

        if ($remembered_username === $admin_user_from_db) {
            // Cookie 有效，重建 Session 登录状态
            $_SESSION['is_admin_logged_in'] = true;
            session_regenerate_id(true);
            return; // 自动登录成功，允许访问
        }
        
        // Cookie 无效，清除它
        setcookie('admin_remember_me', '', time() - 3600, '/', '', false, true);

    } catch (PDOException $e) { 
        // 数据库连接失败，无法验证 Cookie，继续重定向到登录页
    }
}

// 3. Session 和 Cookie 均无效，重定向到登录页面
header('Location: index.php');
exit;