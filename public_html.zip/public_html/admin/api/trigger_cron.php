<?php
// admin/api/trigger_cron.php - 手动触发 Cron Job 队列处理
// v1.1 更新：使用 cURL 模拟 HTTP 请求，替代被禁用的 shell_exec()
declare(strict_types=1);

require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../auth.php'; // 包含 session_start() 和登录验证

// --- 安全与环境设置 ---
header('Content-Type: text/plain; charset=utf-8'); // 返回纯文本日志
set_time_limit(300); // 允许脚本运行 5 分钟
ignore_user_abort(true);

// 1. 验证请求方法 (应该是 POST)
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die("Error: Method Not Allowed.");
}

// 2. 验证 CSRF Token (将在 【任务组 5】 中实现)
// TODO: 添加 CSRF Token 验证逻辑

// 3. 检查 Cron 密钥是否已配置
if (!defined('CRON_SECRET_KEY') || CRON_SECRET_KEY === 'YOUR_STRONG_SECRET_KEY_HERE') {
    http_response_code(500);
    die("Error: CRON_SECRET_KEY 未在 config.php 中正确配置。");
}

// 4. 检查 cURL 扩展是否可用
if (!function_exists('curl_init')) {
    http_response_code(500);
    die("Error: 服务器未启用 PHP cURL 扩展，无法模拟 HTTP 请求。");
}

// 5. 构建目标 URL
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$domain_name = $_SERVER['HTTP_HOST'];
// 获取相对于 public_html 的路径，避免依赖 __DIR__ 可能产生的 CLI/Web 差异
$script_path_relative_to_root = dirname($_SERVER['PHP_SELF'], 3); // 从 /admin/api/ 退三级到 /
$cron_url = rtrim($protocol . $domain_name . $script_path_relative_to_root, '/') . '/cron/process_queue.php?key=' . urlencode(CRON_SECRET_KEY);

// 6. 执行 cURL 请求并捕获输出
echo "--- 开始手动触发邮件队列处理 ---\n";
echo "执行时间: " . date('Y-m-d H:i:s') . "\n";
echo "请求 URL: " . $protocol . $domain_name . rtrim($script_path_relative_to_root, '/') . '/cron/process_queue.php?key=***SECRET***' . "\n"; // 不显示完整 URL 以策安全
echo "---------------------------------\n\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $cron_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // 返回响应内容而不是直接输出
curl_setopt($ch, CURLOPT_TIMEOUT, 290);    // 设置超时 (略小于 set_time_limit)
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 在某些环境中可能需要忽略 SSL 验证
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // 同上

$output = curl_exec($ch);
$curl_error = curl_error($ch);
curl_close($ch);

// 7. 输出结果
if ($curl_error) {
    echo "!!! cURL 请求失败 !!!\n";
    echo "错误信息: " . $curl_error . "\n";
} elseif ($output === false) {
    echo "!!! 请求执行了，但 cURL 未能获取响应内容 !!!\n";
    echo "请检查 process_queue.php 脚本是否能被 Web 服务器正常访问。\n";
} elseif (trim($output) === '') {
     echo "脚本已执行，但没有输出。这可能意味着队列为空或脚本内部出错（请检查 PHP 错误日志）。\n";
} else {
    // 成功执行并获取到输出
    echo $output; // 直接输出 process_queue.php 的日志
}

echo "\n--- 手动触发完毕 ---";

exit; // 确保脚本干净地结束