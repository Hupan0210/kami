<?php
// admin\api\create_mail_queue.php
// v1.2 更新：
// - 从 JSON API 更改为处理标准 POST 表单。
// - 移除 JSON 响应，改为使用 Session Flash 消息并重定向回 send_mail.php。
declare(strict_types=1);

require_once __DIR__ . '/../../config.php';
require_once __DIR__ . '/../auth.php'; // auth.php 包含 session_start()

/**
 * 🎯 升级 v1.2：设置闪存消息并重定向回邮件发送页面
 *
 * @param string $message 消息内容
 * @param string $type 消息类型 ('success' 或 'error')
 */
function redirect_with_flash(string $message, string $type = 'error'): void
{
    $_SESSION['flash_message'] = ['text' => $message, 'type' => $type];
    header('Location: ../send_mail.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_with_flash('无效的请求方法。');
}

// 🎯 升级 v1.2：从 $_POST 获取数据，而不是 JSON
$input = $_POST;
$sender = trim($input['sender'] ?? '');
$recipient_type = $input['recipient_type'] ?? '';
$specific_recipients = trim($input['specific_recipients'] ?? '');
$subject = trim($input['subject'] ?? '');
$body = $input['body'] ?? ''; // 邮件内容保留 HTML

// --- 数据验证 ---
if (empty($sender) || empty($subject) || empty($body)) {
    redirect_with_flash('发件人、主题和内容不能为空。');
}
if ($recipient_type !== 'all' && $recipient_type !== 'specific') {
     redirect_with_flash('无效的收件人类型。');
}
if ($recipient_type === 'specific' && empty($specific_recipients)) {
     redirect_with_flash('选择“指定邮箱”时，收件人列表不能为空。');
}
// --- 验证结束 ---

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $recipients = [];

    if ($recipient_type === 'all') {
        // 从 keys 表中获取所有 'redeemed' 状态的邮箱
        $stmt = $pdo->query("SELECT used_by_email FROM keys WHERE status = 'redeemed' AND used_by_email IS NOT NULL");
        $all_emails = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $recipients = array_filter($all_emails, 'filter_var', FILTER_VALIDATE_EMAIL); // 过滤掉无效邮箱
        
    } elseif ($recipient_type === 'specific') {
        // 从 textarea 中解析指定邮箱
        $raw_emails = preg_split('/[,\s\n]+/', $specific_recipients, -1, PREG_SPLIT_NO_EMPTY);
        $recipients = array_filter($raw_emails, 'filter_var', FILTER_VALIDATE_EMAIL); // 过滤掉无效邮箱
    }

    if (empty($recipients)) {
        redirect_with_flash('未找到有效收件人。');
    }
    
    // --- 批量插入队列 ---
    $pdo->beginTransaction();
    $insert_stmt = $pdo->prepare("INSERT INTO mail_queue (recipient_email, subject, body, sender) VALUES (?, ?, ?, ?)");
    $total_count = 0;

    foreach ($recipients as $email) {
        $insert_stmt->execute([$email, $subject, $body, $sender]);
        $total_count++;
    }
    
    $pdo->commit();

    // 🎯 升级 v1.2：重定向并返回成功消息
    redirect_with_flash("✅ 队列创建成功！共 {$total_count} 封邮件待发送。系统 Cron Job 将在后台处理。", 'success');

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    // 🎯 升级 v1.2：重定向并返回错误消息
    redirect_with_flash('数据库错误: ' . $e->getMessage());
}