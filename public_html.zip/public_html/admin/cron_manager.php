<?php
// admin/cron_manager.php - Cron Job 控制面板
require_once __DIR__ . '/../config.php';
$page_title = '🤖 Cron Job 控制面板';
require_once __DIR__ . '/partials/header.php'; // 包含 auth.php 和 session_start()

$message = '';
$message_type = '';
$cron_key = defined('CRON_SECRET_KEY') ? CRON_SECRET_KEY : null; // 读取 config.php 定义的常量
$cron_command = '';
$queue_stats = ['pending' => 0, 'sent' => 0, 'failed' => 0];
$failed_jobs = [];

// --- 自动生成 Cron 命令 ---
if ($cron_key && $cron_key !== 'YOUR_STRONG_SECRET_KEY_HERE') { // 确保密钥已被设置
    // 尝试自动获取当前域名和协议
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $domain_name = $_SERVER['HTTP_HOST'];
    $script_path = dirname($_SERVER['PHP_SELF'], 2); // 获取 /public_html 对应的 Web 路径
    $cron_url = rtrim($protocol . $domain_name . $script_path, '/') . '/cron/process_queue.php?key=' . urlencode($cron_key);
    
    // 生成 wget 命令
    $cron_command = 'wget -q -O- "' . $cron_url . '" > /dev/null 2>&1';
} else {
    $message = '警告：未在 config.php 中正确设置 CRON_SECRET_KEY！Cron Job 功能将无法安全运行。';
    $message_type = 'error';
}

// --- 获取队列统计信息 ---
try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 查询统计
    $stmt_stats = $pdo->query("SELECT status, COUNT(*) as count FROM mail_queue GROUP BY status");
    while ($row = $stmt_stats->fetch(PDO::FETCH_ASSOC)) {
        if (isset($queue_stats[$row['status']])) {
            $queue_stats[$row['status']] = (int)$row['count'];
        }
    }

    // 查询失败的任务 (最多显示最近 50 条)
    $stmt_failed = $pdo->query("SELECT recipient_email, error_message, sent_at FROM mail_queue WHERE status = 'failed' ORDER BY id DESC LIMIT 50");
    $failed_jobs = $stmt_failed->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $message = "数据库查询失败: " . $e->getMessage();
    $message_type = 'error';
}

?>

<?php if ($message): ?>
    <div class="alert <?php echo $message_type === 'success' ? 'badge-success' : 'alert-danger'; ?>" style="color: <?php echo $message_type === 'success' ? 'white' : 'inherit'; ?>; margin-bottom: 1.5rem;"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">⚙️ Cron Job 设置助手</h2>
        <p class="card-subtitle">设置服务器定时任务以自动处理邮件队列。</p>
    </div>

    <p>为了让系统能够自动在后台发送邮件队列，您需要设置一个定时任务（Cron Job）来定期运行邮件处理脚本。这样，即使您关闭了浏览器，邮件也会继续发送。</p>
    <p><strong>推荐频率：</strong> 我们推荐您设置 Cron Job <strong>每 5 分钟</strong>运行一次 (<code>*/5 * * * *</code>)。</p>

    <div class="form-group">
        <label>🔑 您的 Cron 安全密钥 (CRON_SECRET_KEY)</label>
        <?php if ($cron_key && $cron_key !== 'YOUR_STRONG_SECRET_KEY_HERE'): ?>
            <input type="text" readonly value="<?php echo htmlspecialchars($cron_key); ?>" style="background-color: var(--bg-color);">
            <small>此密钥定义在项目根目录下的 <code>config.php</code> 文件中。您需要手动编辑该文件来设置或更改它。</small>
        <?php else: ?>
            <div class="alert alert-danger">错误：未在 <code>config.php</code> 中找到或设置有效的 <code>CRON_SECRET_KEY</code>！请立即编辑该文件进行设置。</div>
        <?php endif; ?>
    </div>

    <?php if ($cron_command): ?>
    <div class="form-group">
        <label for="cron_command_display">📋 自动生成的 Cron 命令</label>
        <textarea id="cron_command_display" readonly rows="3" style="width: 100%; font-family: monospace; resize: none;"><?php echo htmlspecialchars($cron_command); ?></textarea>
        <button id="copy-cron-cmd-btn" class="btn-primary" style="margin-top: 0.5rem;">📋 一键复制命令</button>
    </div>
    <?php endif; ?>

    <h4>⚙️ DirectAdmin 设置步骤</h4>
    <ol style="padding-left: 20px; line-height: 1.6;">
        <li>登录您的 DirectAdmin 面板。</li>
        <li>导航至 <strong>高级功能 (Advanced Features)</strong> -> <strong>定时任务 (Cronjobs)</strong>。</li>
        <li>点击 <strong>创建定时任务 (Create Cron Job)</strong>。</li>
        <li>在 <strong>时间设置 (Time Settings)</strong> 部分，将 <strong>分钟 (Minute)</strong> 设置为 <code>*/5</code>，其他（小时、日、月、星期）保持为 <code>*</code>。</li>
        <li>在 <strong>命令 (Command)</strong> 输入框中，粘贴上方自动生成的 <code>wget ...</code> 命令。</li>
        <li><strong>（可选）</strong> 为了避免每次运行时都收到邮件通知，可以将 <strong>阻止邮件 (Prevent Email)</strong> 选项设置为 <strong>是 (Yes)</strong>。</li>
        <li>点击 <strong>创建 (Create)</strong> 或 <strong>保存 (Save)</strong>。</li>
    </ol>
     <p><strong>✅ 验证：</strong> 设置完成后，您可以观察下方的‘队列状态监控’。如果‘待处理’邮件数量在几分钟后开始减少，则说明 Cron Job 已成功运行。</p>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">⚠️ 常见错误排查</h2>
        <p class="card-subtitle">Cron Job 设置或运行中可能遇到的问题及解决方案。</p>
    </div>
    <ul>
        <li><strong>密钥错误:</strong> Cron Job 运行但队列无变化，或邮件提示 "Forbidden: Invalid or missing security key."？
            <br><em>解决方案:</em> 请确保粘贴到 DirectAdmin 命令框中 <code>?key=</code> 后面的密钥 与上方显示的 <strong>您的 Cron 安全密钥</strong> 完全一致。</li>
        <li><strong>URL 路径错误:</strong> Cron Job 错误邮件提示 "404 Not Found"？
            <br><em>解决方案:</em> 检查 Cron 命令中的 URL 是否确实是 <code>process_queue.php</code> 文件 的正确网址。</li>
        <li><strong>`wget` 命令不可用:</strong> 错误邮件提示 "wget: command not found"？
            <br><em>解决方案:</em> 尝试将 Cron 命令替换为 <code>curl -s "YOUR_CRON_URL_HERE" > /dev/null 2>&1</code> (替换 URL 和密钥)。如果 curl 也不可用，请联系主机商。</li>
        <li><strong>PHP 脚本内部错误 (无错误邮件):</strong> Cron Job 运行但队列无变化？
            <br><em>解决方案:</em> 临时编辑 Cron Job，移除命令末尾的 <code>> /dev/null 2>&1</code>，让错误输出发送到邮箱。根据错误修复后务必加回此部分。</li>
        <li><strong>SMTP 配置错误:</strong> 队列状态显示“失败”增加，且下方日志有 SMTP 错误？
            <br><em>解决方案:</em> 返回 <strong>站点设置 -> SMTP 邮件发送设置</strong> 检查 SMTP 凭据是否准确。</li>
    </ul>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">▶️ 手动触发</h2>
        <p class="card-subtitle">立即运行一次邮件队列处理脚本，用于测试或紧急处理。</p>
    </div>
    <button id="manual-trigger-btn" class="btn-success" disabled>▶️ 立即执行一次 (功能待实现)</button>
    <div id="manual-trigger-log" style="margin-top: 1rem; max-height: 200px; overflow-y: auto; background-color: var(--bg-color); padding: 10px; border-radius: 8px; display: none;">
        </div>
</div>

<div class="card">
     <div class="card-header">
        <h2 class="card-title">📊 队列状态监控</h2>
        <p class="card-subtitle">当前邮件队列的整体情况。</p>
    </div>
    <div class="grid-form" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));">
        <div class="stat-card" style="border-color: var(--primary-blue);">
            <h3 class="stat-number" style="color: var(--primary-blue);"><?php echo $queue_stats['pending']; ?></h3>
            <p class="stat-label">⏳ 待处理</p>
        </div>
         <div class="stat-card" style="border-color: var(--success-color);">
            <h3 class="stat-number" style="color: var(--success-color);"><?php echo $queue_stats['sent']; ?></h3>
            <p class="stat-label">✅ 已发送</p>
        </div>
         <div class="stat-card" style="border-color: var(--error-color);">
            <h3 class="stat-number" style="color: var(--error-color);"><?php echo $queue_stats['failed']; ?></h3>
            <p class="stat-label">❌ 已失败</p>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">📋 失败日志查看</h2>
        <p class="card-subtitle">最近 <?php echo count($failed_jobs); ?> 条发送失败的记录。</p>
    </div>
    <?php if (empty($failed_jobs)): ?>
        <p>目前没有发送失败的记录。</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>收件邮箱</th>
                        <th>失败原因</th>
                        <th>失败时间</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($failed_jobs as $job): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($job['recipient_email']); ?></td>
                            <td style="color: var(--error-color);"><?php echo htmlspecialchars($job['error_message'] ?? '未知错误'); ?></td>
                            <td><?php echo htmlspecialchars($job['sent_at'] ?? 'N/A'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // --- 复制 Cron 命令 ---
    const copyBtn = document.getElementById('copy-cron-cmd-btn');
    const commandTextarea = document.getElementById('cron_command_display');

    if (copyBtn && commandTextarea) {
        copyBtn.addEventListener('click', async function() {
            const commandToCopy = commandTextarea.value;
            const originalText = this.textContent;
            try {
                await navigator.clipboard.writeText(commandToCopy);
                this.textContent = '✅ 已复制!';
                this.disabled = true;
                setTimeout(() => {
                    this.textContent = originalText;
                    this.disabled = false;
                }, 2000);
            } catch (err) {
                alert('复制失败，您的浏览器可能不支持此功能。请手动复制。');
            }
        });
    }

    // --- 🎯 升级 v1.2：手动触发功能实现 ---
    const manualTriggerBtn = document.getElementById('manual-trigger-btn');
    const manualTriggerLog = document.getElementById('manual-trigger-log');
    
    if (manualTriggerBtn) {
        // 只有在 Cron Key 有效时才启用按钮
        const cronKeyInput = document.querySelector('input[type="text"][readonly]');
        if (cronKeyInput && cronKeyInput.value && cronKeyInput.value !== 'YOUR_STRONG_SECRET_KEY_HERE') {
            manualTriggerBtn.disabled = false; 
            manualTriggerBtn.textContent = '▶️ 立即执行一次'; // 更新按钮文本
        } else {
             manualTriggerBtn.textContent = '▶️ (请先配置密钥)'; // 提示用户
        }

        manualTriggerBtn.addEventListener('click', async function() {
            this.textContent = '执行中...';
            this.disabled = true;
            manualTriggerLog.style.display = 'block';
            manualTriggerLog.innerHTML = '<p>正在请求服务器执行 Cron 脚本...</p>';
            
            try {
                // 调用新创建的 API 端点
                // TODO: 在 【任务组 5】 中添加 CSRF Token 到 headers 或 body
                const response = await fetch('api/trigger_cron.php', { 
                    method: 'POST' 
                    // headers: { 'X-CSRF-Token': 'YOUR_TOKEN_HERE' } // CSRF Token 示例
                });
                
                // 检查 HTTP 状态码
                if (!response.ok) {
                    throw new Error(`服务器错误: ${response.status} ${response.statusText}`);
                }
                
                // 获取纯文本响应
                const result = await response.text(); 
                
                // 使用 <pre> 标签显示日志，以保留换行和格式
                manualTriggerLog.innerHTML = `<pre>${result}</pre>`; 

            } catch (error) {
                manualTriggerLog.innerHTML = `<p style="color: var(--error-color);">请求失败: ${error.message}</p>`;
            } finally {
                this.textContent = '▶️ 再次执行'; // 更新按钮文本
                this.disabled = false; // 允许再次触发
            }
        });
    }

});
</script>
<style>
/* 页面专属样式 */
.stat-card { text-align: center; }
.stat-number { font-size: 2rem; margin: 0; font-weight: 600; }
.stat-label { margin: 0.25rem 0 0; color: var(--secondary-text-color); font-size: 0.9rem; }
li strong { display: inline-block; min-width: 120px; }
li em { font-style: normal; color: var(--secondary-text-color); }
pre { white-space: pre-wrap; word-wrap: break-word; } /* 用于显示日志 */
</style>


<?php require_once __DIR__ . '/partials/footer.php'; ?>