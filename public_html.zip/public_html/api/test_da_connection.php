<?php
// 纯净版 test_da_connection.php (v1.2 - 最终修正版)
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../admin/auth.php';

header('Content-Type: application/json');

function send_test_response(bool $success, string $message): void
{
    echo json_encode(['success' => $success, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_test_response(false, '无效的请求方法。');
}

$input = json_decode(file_get_contents('php://input'), true);
$host = $input['host'] ?? '';
$port = $input['port'] ?? '';
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';

if (empty($host) || empty($port) || empty($username) || empty($password)) {
    send_test_response(false, '所有连接参数都不能为空。');
}

$params = http_build_query(['json' => 'yes', 'action' => 'exists', 'domain' => 'anydomain.com', 'user' => 'api-test-' . time()]);
$url = "https://{$host}:{$port}/CMD_API_POP?{$params}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 15);
curl_setopt($ch, CURLOPT_USERPWD, "{$username}:{$password}");
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

$response_body = curl_exec($ch);
$curl_error = curl_error($ch);
curl_close($ch);

if ($curl_error) {
    send_test_response(false, '连接失败: ' . $curl_error);
}

$response_data = json_decode($response_body, true);

if ($response_data === null) {
    send_test_response(false, '连接失败: 服务器返回了无效的响应 (非 JSON)。');
}

// --- ❗️❗️❗️ 关键逻辑升级: 更智能的错误判断 ❗️❗️❗️ ---
if (isset($response_data['error']) && $response_data['error'] != 0) {
    $error_details = $response_data['details'] ?? $response_data['result'] ?? $response_data['text'] ?? '未知 API 错误';

    // 只要错误信息是关于“域名”的，都说明我们的认证和连接是成功的！
    if (strpos(strtolower($error_details), 'domain') !== false) {
        send_test_response(true, '连接成功！服务器已正确响应。');
    } else {
        // 其他错误，如 "Not logged in"，则如实报告
        send_test_response(false, '连接失败: ' . $error_details);
    }
} else {
    // 任何没有错误的响应，都代表成功
    send_test_response(true, '连接成功！');
}