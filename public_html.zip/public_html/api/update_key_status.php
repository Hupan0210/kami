<?php
// 纯净版 update_key_status.php (v1.0)
declare(strict_types=1);

// 引入核心文件
require_once __DIR__ . '/../config.php';
// ❗️❗️❗️ 关键安全步骤: 确保只有登录的管理员才能调用此 API ❗️❗️❗️
require_once __DIR__ . '/../admin/auth.php';

header('Content-Type: application/json');

function send_api_response(bool $success, string $message = ''): void
{
    echo json_encode(['success' => $success, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_api_response(false, '无效的请求方法。');
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? null;
$key_id = isset($input['key_id']) ? filter_var($input['key_id'], FILTER_VALIDATE_INT) : null;

if (!$action || !$key_id) {
    send_api_response(false, '缺少必要参数 (action 或 key_id)。');
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    switch ($action) {
        // "一键复制" 后的状态变更操作
        case 'distribute':
            $stmt = $pdo->prepare(
                "UPDATE keys 
                 SET status = 'distributed', distributed_at = datetime('now', 'localtime') 
                 WHERE id = ? AND status = 'pristine'"
            );
            $stmt->execute([$key_id]);
            // rowCount() 会返回受影响的行数，如果是 1 则代表更新成功
            if ($stmt->rowCount() > 0) {
                send_api_response(true, '卡密状态已更新为“已分发”。');
            } else {
                send_api_response(false, '更新失败，可能卡密已被操作或不存在。');
            }
            break;

        // "收回" 操作
        case 'reclaim':
            $stmt = $pdo->prepare(
                "UPDATE keys 
                 SET status = 'pristine', distributed_at = NULL 
                 WHERE id = ? AND status = 'distributed'"
            );
            $stmt->execute([$key_id]);
            if ($stmt->rowCount() > 0) {
                send_api_response(true, '卡密已成功收回至“未使用”状态。');
            } else {
                send_api_response(false, '收回失败，可能卡密已被兑换或不存在。');
            }
            break;

        default:
            send_api_response(false, '未知的操作类型。');
            break;
    }

} catch (Exception $e) {
    // error_log('API Update Key Status Error: ' . $e->getMessage());
    send_api_response(false, '数据库操作失败：' . $e->getMessage());
}