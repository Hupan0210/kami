<?php
// 纯净版 verify_key.php (v4.0 - 支持三态系统)
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

function send_response(bool $success, string $message, array $data = []): void
{
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_response(false, '无效的请求方法。');
}

$input = json_decode(file_get_contents('php://input'), true);
$card_key = $input['card_key'] ?? '';
$card_key = trim(strtoupper($card_key));

if (empty($card_key)) {
    send_response(false, '卡密不能为空。');
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare("SELECT status FROM keys WHERE card_key = ?");
    $stmt->execute([$card_key]);
    $key_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$key_data) {
        send_response(false, '您输入的卡密无效。');
    }

    // --- ❗️❗️❗️ 关键逻辑升级 ❗️❗️❗️ ---
    // 只要卡密状态是 'pristine' (未使用) 或 'distributed' (已分发)，都视为有效
    if (in_array($key_data['status'], ['pristine', 'distributed'])) {
        send_response(true, '卡密有效！', ['card_key' => $card_key]);
    } 
    // 如果状态是 'redeemed' (已兑换)，则明确告知已使用
    elseif ($key_data['status'] === 'redeemed') {
        send_response(false, '此卡密已被使用。');
    } 
    // 任何其他情况，才属于真正的状态异常
    else {
        send_response(false, '卡密状态异常。');
    }

} catch (PDOException $e) {
    send_response(false, '数据库查询时发生错误，请稍后再试。');
}