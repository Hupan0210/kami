<?php
// 纯净版 create_account.php (v3.1 - 状态迁移)
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/DirectAdmin.class.php';

header('Content-Type: application/json');

function send_creation_response(bool $success, string $message, array $data = []): void
{
    echo json_encode(['success' => $success, 'message' => $message, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_creation_response(false, '无效的请求方法。');
}

$input = json_decode(file_get_contents('php://input'), true);
$card_key = $input['card_key'] ?? '';
$username = $input['username'] ?? '';

$card_key = trim(strtoupper($card_key));
$username = strtolower(trim($username));

if (empty($card_key) || empty($username)) {
    send_creation_response(false, '关键信息缺失，请返回重试。');
}
if (!preg_match('/^[a-z0-9._\-]{3,20}$/', $username)) {
    send_creation_response(false, '邮箱前缀格式不符合要求。');
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // --- 事务性检查 ---
    $stmt = $pdo->prepare("SELECT status FROM keys WHERE card_key = ?");
    $stmt->execute([$card_key]);
    $key_data = $stmt->fetch(PDO::FETCH_ASSOC);

    // 现在，卡密可以是 'pristine' 或 'distributed' 状态才能被兑换
    if (!$key_data || !in_array($key_data['status'], ['pristine', 'distributed'])) {
        send_creation_response(false, '卡密无效或已被使用，请返回第一步。');
    }

    $settingsStmt = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('target_domain', 'default_email_password', 'login_url', 'promo_url', 'server_config')");
    $settings = $settingsStmt->fetchAll(PDO::FETCH_KEY_PAIR);
    $target_domain = $settings['target_domain'] ?? null;
    $default_password = $settings['default_email_password'] ?? null;
    if (empty($target_domain) || empty($default_password)) {
        send_creation_response(false, '系统错误：域名或默认密码未在数据库中配置。');
    }

    $da = new DirectAdmin($pdo);
    if ($da->emailExists($username, $target_domain)) {
        send_creation_response(false, '非常抱歉，该邮箱前缀刚刚被注册了，请返回上一步更换一个。');
    }

    // --- 执行创建 ---
    $result = $da->createEmail($username, $target_domain, $default_password);

    if (!$result['success']) {
        send_creation_response(false, '邮箱服务器创建账户失败，请联系管理员。错误: ' . $result['message']);
    }

    // --- ❗️❗️❗️ 关键更新 ❗️❗️❗️ ---
    // 将最终状态从 'used' 更新为 'redeemed'
    $full_email = $username . '@' . $target_domain;
    $client_ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $updateStmt = $pdo->prepare(
        "UPDATE keys SET status = 'redeemed', used_by_email = ?, used_at = datetime('now', 'localtime'), used_ip = ? WHERE card_key = ?"
    );
    $updateSuccess = $updateStmt->execute([$full_email, $client_ip, $card_key]);

    if (!$updateSuccess) {
        send_creation_response(false, '系统状态更新失败，请立即联系管理员并提供您的卡密！');
    }
    
    // --- 准备成功数据并返回 ---
    $success_data = [
        'email' => $full_email,
        'password' => $default_password,
        'login_url' => $settings['login_url'] ?? '#',
        'promo_url' => $settings['promo_url'] ?? '#',
        'server_config' => $settings['server_config'] ?? 'N/A',
    ];

    send_creation_response(true, '邮箱账户已成功开通！', $success_data);

} catch (Exception $e) {
    send_creation_response(false, '系统发生未知错误，请稍后再试或联系管理员。');
}