<?php
// 纯净版 check_username.php (v3 - 数据库驱动)
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/DirectAdmin.class.php';

header('Content-Type: application/json');

function send_check_response(bool $is_available, string $message): void
{
    echo json_encode(['available' => $is_available, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_check_response(false, '无效的请求方法。');
}

$input = json_decode(file_get_contents('php://input'), true);
$username = $input['username'] ?? '';
$username = strtolower(trim($username));

// 正则表达式验证 (修复了兼容性问题)
if (!preg_match('/^[a-z0-9._\-]{3,20}$/', $username)) {
    send_check_response(false, '格式错误 (3-20位, 仅限小写字母/数字/._-)');
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 从数据库获取目标域名
    $domainStmt = $pdo->query("SELECT setting_value FROM settings WHERE setting_key = 'target_domain'");
    $target_domain = $domainStmt->fetchColumn();

    if (empty($target_domain)) {
        send_check_response(false, '系统错误：未在数据库中配置目标域名。');
    }

    // 实例化数据库驱动的 DirectAdmin 类
    $da = new DirectAdmin($pdo);
    
    if ($da->emailExists($username, $target_domain)) {
        send_check_response(false, '😭 该前缀已被占用，换一个试试吧！');
    } else {
        send_check_response(true, '✅ 恭喜！该前缀可以使用。');
    }

} catch (Exception $e) {
    // 捕获所有可能的错误 (数据库连接、DA API 连接等)
    // error_log('API Check Username Error: ' . $e->getMessage());
    send_check_response(false, '无法连接到服务器进行验证，请稍后再试。');
}