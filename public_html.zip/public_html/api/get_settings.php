<?php
// 纯净版 get_settings.php (v3.2 - 支持灵活联系方式)
declare(strict_types=1);
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json');

function send_public_response(bool $success, array $data = []): void {
    echo json_encode(['success' => $success, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = new PDO('sqlite:' . DB_PATH);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 升级查询: 获取所有前端需要的、灵活的字段
    $stmt = $pdo->query("
        SELECT setting_key, setting_value FROM settings 
        WHERE setting_key LIKE 'contact_%_label' 
           OR setting_key LIKE 'contact_%_value' 
           OR setting_key LIKE 'footer_link_%' 
           OR setting_key = 'show_footer_info'
           OR setting_key = 'target_domain'
    ");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    send_public_response(true, $settings);
} catch (PDOException $e) {
    send_public_response(false);
}