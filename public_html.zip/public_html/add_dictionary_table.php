<?php
// /public_html/add_dictionary_table.php (临时脚本)
declare(strict_types=1);
require_once __DIR__ . '/config.php'; // 引入配置以获取数据库路径

header('Content-Type: text/plain; charset=utf-8');
echo "🚀 正在尝试向数据库添加 'dictionary' 表...\n";

try {
    $pdo = new PDO('sqlite:' . DB_PATH); // 使用 config.php 定义的路径连接
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 核心 SQL 语句
    $sql = "
        CREATE TABLE IF NOT EXISTS dictionary (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            term TEXT NOT NULL UNIQUE,
            explanation TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_dictionary_term ON dictionary (term);
    ";

    $pdo->exec($sql);
    echo "✅ 操作成功！'dictionary' 表已创建 (如果它尚不存在)。\n";

} catch (PDOException $e) {
    echo "❌ 数据库操作失败: " . $e->getMessage() . "\n";
} catch (Exception $e) {
    echo "❌ 发生未知错误: " . $e->getMessage() . "\n";
}

echo "\n🛡️ 请在确认成功后立即删除此脚本 (add_dictionary_table.php)！";
?>