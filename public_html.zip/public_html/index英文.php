<?php
// Clean version index.php (Frontend v3)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Email Self-Service</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script defer src="assets/js/app.js"></script>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>Student Email Self-Service</h1>
        </header>

        <div id="step1" class="step-card active">
            <h2>🔐 Step 1: Verify Your Activation Key</h2>
            <p>Please enter the activation key you received to set up your exclusive student email.</p>
            <form id="verifyKeyForm">
                <div class="input-group">
                    <label for="card_key_input">Enter Activation Key</label>
                    <input type="text" id="card_key_input" name="card_key" placeholder="Example: EA73DD-063E5C-FE6287" required>
                </div>
                <button type="submit" class="btn">Verify Key</button>
            </form>
        </div>

        <div id="step2" class="step-card">
            <h2>✨ Step 2: Set Your Email Prefix</h2>
            <p>Your activation key <strong id="verifiedKeyDisplay"></strong> has been verified!</p>
            <p>Now, please set up your desired email prefix.</p>
            <form id="createAccountForm">
                <div class="input-group addon">
                    <input type="text" id="username_input" name="username" placeholder="Email Prefix" required pattern="[a-z0-9._\-]{3,20}" title="3-20 characters, lowercase letters, numbers, and ._- only">
                    <span id="domainAddon" class="input-addon">@...</span>
                </div>
                <div id="usernameCheckResult" class="validation-message"></div>
                <button type="submit" class="btn" disabled>Activate Now</button>
            </form>
        </div>

        <div id="step3" class="step-card">
            <h2>🎉 Activation Successful!</h2>
            <p>Your exclusive student email has been successfully created. Please keep the following information safe:</p>
            <div id="successInfo" class="success-info">
                <div class="info-item"><span>📧 Email Account:</span> <strong id="infoEmail"></strong></div>
                <div class="info-item"><span>🔑 Initial Password:</span> <strong id="infoPassword"></strong></div>
                <div class="info-item"><span>🌐 Login URL:</span> <a id="infoLoginUrl" href="#" target="_blank"></a></div>
                <div class="info-item"><span>🎁 Discount Platform:</span> <a id="infoPromoUrl" href="#" target="_blank"></a></div>
                <div class="info-item"><span>⚙️ Email Configuration:</span> <code id="infoServerConfig"></code></div>
            </div>
            <p class="warning">⚠️ For your account security, please log in and change your initial password immediately!</p>
            <div class="actions">
                <button id="copyAllBtn" class="btn">📋 Copy All Information</button>
                <a id="loginNowBtn" href="#" class="btn btn-secondary" target="_blank">🚀 Log In to Email Now</a>
            </div>
        </div>
        
        <div id="messageArea" class="message-area"></div>
        
        <footer id="footer" class="footer" style="display: none;">
            <p>
                <span>Contact Us:</span>
                <span id="contactWechat"></span> | 
                <span id="contactPhone"></span>
            </p>
            <p>
                <a id="footerLink1" href="#" target="_blank"></a> | 
                <a id="footerLink2" href="#" target="_blank"></a>
            </p>
        </footer>
    </div>
</body>
</html>